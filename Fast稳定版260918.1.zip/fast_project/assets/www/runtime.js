/* 积木应用运行时 v1.2：渲染界面（含坐标/样式）+ 执行积木生成的 JS */
(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };

  var project = null, isPreview = false;
  var stack = [], current = null;
  var clickMap = {}, itemClickMap = {}, startHandlers = [], firstStartHandlers = [], selected = {}, changeMap = {};
  // “当页面首次启动时”只在本次运行进程内记录；杀掉后台/重新打开 App（页面重新加载）会重新执行
  var firstFired = Object.create(null);
  // 页面渲染代号：每次 render 自增。启动事件改为渲染完成后的异步任务，跳转离开后旧任务作废
  var renderGen = 0;
  // 循环跳转保护：每个页面的积木只在该页面被打开（渲染）时执行。
  // 判定方式：在“启动事件引发的连续自动跳转”里（含等待后才跳的慢循环——整个 async 事件都算自动流程），
  // 同一页面的“当页面启动时”第 3 次触发，即说明存在由启动事件驱动的死循环（如两个页面互跳），静默刹车。
  // 不再弹提示框（原黑框 toast 已按需求移除）；“首次启动”积木只执行一次，照常执行。
  // 不会误拦：线性流程（每页只开一次）、“当页面首次启动时”（仅一次）、用户点按钮/返回等手势（会重置计数）。
  var autoBurst = Object.create(null);
  // 当前导航由谁发起：'auto'=页面启动事件（含其 await 之后的延续）；'user'=点击/滑块/列表项/返回等手势。
  // 自动导航只“替换”栈顶（启动链上的中转页不该进返回栈，否则按返回会被启动积木弹回、退不出去）；
  // 用户主动跳转才压栈。
  var navKind = 'auto';
  function refillNavBudget() { autoBurst = Object.create(null); }   // 用户操作=新流程
  function userGesture() { navKind = 'user'; refillNavBudget(); }

  function mode() { return (window.Native && Native.getMode) ? Native.getMode() : 'editor'; }

  /* 参考设计画布尺寸；优先用编辑器在真机捕获的 project.design（与本机可用区同宽高比），
     等比缩放后恰好铺满，上下左右严格对齐，不再出现“布局碰底、运行留缝”。 */
  var DESIGN = { portrait: { w: 390, h: 827 }, landscape: { w: 827, h: 390 } };
  function designSize() {
    var o = (current && current.orientation) || (project && project.orientation) || 'portrait';
    var base = (o === 'landscape') ? DESIGN.landscape : DESIGN.portrait;
    var p = project && project.design;
    if (p && p.orientation === o &&
        typeof p.w === 'number' && isFinite(p.w) && typeof p.h === 'number' && isFinite(p.h) &&
        p.w >= 240 && p.h >= 240) {
      return { w: Math.round(p.w), h: Math.round(p.h) };
    }
    return base;
  }
  // 设计画布整体等比缩放（contain）完整居中显示在安全区内，边缘留白用与画布相同的底色延伸（不是黑边）。
  // 这样与编辑器“拖动布局”舞台的映射完全一致：顶部不会上溢、底部不会莫名留空。
  function fitScreen() {
    var sc = $('#screen'); if (!sc || !project) return;
    var vw = window.innerWidth, vh = window.innerHeight;
    // 与编辑器布局舞台一致：screen 直接铺满窗口，不缩放，坐标用真实像素
    sc.style.width = vw + 'px';
    sc.style.height = vh + 'px';
    sc.style.transform = 'none';
    sc.style.transformOrigin = 'top left';
  }
  window.addEventListener('resize', fitScreen);
  window.addEventListener('orientationchange', function () { setTimeout(fitScreen, 60); setTimeout(fitScreen, 260); });

  function loadProject() {
    var raw = null;
    try {
      var pv = localStorage.getItem('__previewProject');
      if (pv) { raw = pv; isPreview = true; }
      else if (mode() === 'shell' && window.Native) { raw = Native.getProject(); }
    } catch (e) { raw = null; }
    if (!raw) { $('#screen').innerHTML = '<div class="text">项目数据缺失，无法运行。</div>'; return; }
    try { project = JSON.parse(raw); } catch (e) {
      $('#screen').innerHTML = '<div class="text">项目数据损坏：' + e.message + '</div>'; return;
    }
    // 运行时横竖屏为页面级：直接按起始页方向锁定，避免先竖屏再转横屏的闪烁
    var startId = project.startScreen || (project.screens[0] && project.screens[0].id);
    var previewStart = null;
    try { previewStart = localStorage.getItem('__previewStartScreen'); } catch (e) { previewStart = null; }
    if (isPreview && previewStart && screenById(previewStart)) startId = previewStart;
    try { localStorage.removeItem('__previewStartScreen'); } catch (e) {}
    var startSc = screenById(startId);
    if (window.Native && Native.setOrientation) Native.setOrientation((startSc && startSc.orientation) || 'portrait');
    if (window.Native && Native.setStatusBar) Native.setStatusBar(!startSc || startSc.showStatusBar !== false);
    fitScreen();
    setTimeout(fitScreen, 120); setTimeout(fitScreen, 400);   // 物理旋转是异步的，旋转后再校准
    if (isPreview || mode() === 'editor') $('#exitpreview').classList.add('show');
    navigate(startId, true);
  }

  function screenById(id) {
    for (var i = 0; i < project.screens.length; i++) if (project.screens[i].id === id) return project.screens[i];
    return null;
  }
  function resolveScreen(name) {
    if (!name) return null;
    var s = screenById(name); if (s) return s;
    for (var i = 0; i < project.screens.length; i++) {
      var x = project.screens[i]; if (x.name === name || x.title === name) return x;
    }
    return null;
  }
  function navigate(id, isStart) {
    var sc = screenById(id); if (!sc) return;
    if (!isStart) {
      // 跳到当前正在显示的页面：无操作，避免“页面启动时又跳自己”这类自循环
      if (current && current.id === sc.id) return;
    }
    if (isStart) stack = [id];
    else if (navKind === 'auto') {
      // 启动事件（含等待后的延续）引发的自动跳转：替换栈顶。
      // 启动链 A→B→C 结束后，返回栈里只有 [来源页, C]，按一次返回就回来源页，
      // 不会落到中转页 B 又被它的“页面启动时”弹回 C。
      if (stack.length) stack[stack.length - 1] = id;
      else stack.push(id);
    } else {
      stack.push(id);
      if (stack.length > 48) stack.splice(1, stack.length - 48);   // 安全上限，防止异常流程无限压栈
    }
    render(sc);
  }
  function goBack() {
    userGesture();   // 返回属于用户操作：按用户导航处理，并重置循环保护
    if (stack.length > 1) { stack.pop(); render(screenById(stack[stack.length - 1])); return true; }
    return false;
  }

  /* ---------------- 渲染 ---------------- */
  function el(tag, cls, text) {
    var e = document.createElement(tag); if (cls) e.className = cls;
    if (text != null) e.textContent = text; return e;
  }

  function render(sc) {
    current = sc; clickMap = {}; itemClickMap = {}; changeMap = {};
    startHandlers = []; firstStartHandlers = [];
    renderGen++;
    // 按当前页面的设置锁定屏幕方向与通知栏（页面级，不再全局）
    if (window.Native && Native.setOrientation) Native.setOrientation(sc.orientation || 'portrait');
    if (window.Native && Native.setStatusBar) Native.setStatusBar(sc.showStatusBar !== false);
    fitScreen();
    var root = $('#screen'); root.innerHTML = '';
    // #flow 承载自动排列组件（padding/gap 与编辑器拖动布局的测量层完全一致）；
    // 绝对定位组件直接挂到 #screen，坐标原点是画布边框(0,0)，与编辑器舞台一一对应，
    // 不再因 #screen 的 16px padding 产生“布局放好的位置运行时偏移”。
    var flow = el('div'); flow.id = 'flow'; root.appendChild(flow);
    var comps = sc.components || [];
    // 自动排列（流式）组件：保持数组顺序，index 0 在流程最上方
    comps.forEach(function (c) {
      if (!(validNum(c.x) || validNum(c.y))) flow.appendChild(renderComp(c));
    });
    // 绝对定位组件：倒序渲染，使设计页列表最上方（index 0）对应运行时最顶层
    comps.slice().reverse().forEach(function (c) {
      if (validNum(c.x) || validNum(c.y)) root.appendChild(renderComp(c));
    });
    runCode(sc);
    root.scrollTop = 0;
  }

  // 只有“有限数字”才算有效参数；null/undefined/''/NaN 一律按“未设置”，绝不拖垮整个组件
  function validNum(v) { return typeof v === 'number' && isFinite(v); }
  function px(v) { return validNum(v) ? (v + 'px') : null; }

  /* 绝对定位且未填宽高时的默认尺寸（必须与编辑器拖动布局的 defaultSize 完全一致，保证所见即所得） */
  function defaultBox(c) {
    switch (c.type) {
      case 'button': return { w: 220, h: 48 };
      case 'input': return { w: 220, h: 52 };
      case 'list': return { w: 240, h: 170 };
      case 'image': return { w: 160, h: 120 };
      case 'switch': return { w: 220, h: 40 };
      case 'checkbox': return { w: 220, h: 40 };
      case 'slider': return { w: 220, h: 40 };
      case 'progress': return { w: 220, h: 12 };
      case 'video': return { w: 240, h: 135 };
      case 'audio': return { w: 280, h: 40 };
      case 'web': return { w: 320, h: 240 };
      case 'text':
      default: return { w: 220, h: 40 };
    }
  }

  /* 把编辑器里设置的位置/大小落到节点上：每个参数独立生效，留空的轴自动处理 */
  function applyLayout(wrap, c) {
    var hasX = validNum(c.x), hasY = validNum(c.y),
        hasW = validNum(c.w), hasH = validNum(c.h);
    if (hasX || hasY) {                 // 只填 X 或只填 Y 也生效，缺省轴按 0（画布边缘），与编辑器一致
      wrap.classList.add('absolute');
      wrap.style.position = 'absolute';
      wrap.style.left = hasX ? px(c.x) : '0px';
      wrap.style.top = hasY ? px(c.y) : '0px';
      var db = defaultBox(c);           // 绝对定位时缺省宽高用统一默认值，与编辑器一致
      wrap.style.width = px(hasW ? c.w : db.w);
      wrap.style.height = px(hasH ? c.h : db.h);
    } else {                            // 自动排列：宽度默认占满，仅在用户填写时覆盖
      if (hasW) wrap.style.width = px(c.w);
      if (hasH) wrap.style.height = px(c.h);
    }
  }
  function applyTextStyle(node, c, defaultSize) {
    if (validNum(c.fs)) node.style.fontSize = px(c.fs);
    else if (defaultSize) node.style.fontSize = defaultSize;
    if (c.color) node.style.color = c.color;
    if (c.bold) node.style.fontWeight = '700';
    if (c.align) node.style.textAlign = c.align;
  }

  function renderComp(c) {
    var wrap = el('div', 'comp ' + c.type);
    wrap.setAttribute('data-id', c.id);
    applyLayout(wrap, c);
    var abs = wrap.classList.contains('absolute');
    // 初始可见性 / 透明度
    if (c.visible === false) wrap.style.display = 'none';
    if (validNum(c.opacity)) wrap.style.opacity = (Math.max(0, Math.min(100, c.opacity)) / 100).toFixed(3);

    if (c.type === 'text') {
      var t = el('span', 'v-text', c.value != null ? c.value : (c.text || ''));
      applyTextStyle(t, c);
      if (c.align) wrap.style.textAlign = c.align; // span 是内联，对齐要设在块级父元素
      wrap.appendChild(t);
      wrap.classList.add('clickable');
      wrap.addEventListener('click', function () { var fn = clickMap[c.id]; if (fn) { userGesture(); safe(fn); } });
    } else if (c.type === 'button') {
      var b = el('button', 'matbtn');
      if (c.icon) { var ic = el('span', 'bicon', c.icon); b.appendChild(ic); }
      b.appendChild(el('span', 'v-text', c.text || '按钮'));
      applyTextStyle(b, c);
      if (c.bg) b.style.background = c.bg;
      if (validNum(c.radius)) b.style.borderRadius = px(c.radius);
      b.style.height = validNum(c.h) ? px(c.h) : (abs ? '100%' : '');  // 绝对定位时填满统一默认高度
      if (c.align) b.style.justifyContent = c.align === 'center' ? 'center' : (c.align === 'right' ? 'flex-end' : 'flex-start');
      b.addEventListener('click', function () { var fn = clickMap[c.id]; if (fn) { userGesture(); safe(fn); } });
      wrap.appendChild(b);
    } else if (c.type === 'input') {
      var inp = el('input'); inp.type = 'text';
      inp.placeholder = c.hint || '请输入';
      if (c.value) inp.value = c.value;
      if (validNum(c.fs)) inp.style.fontSize = px(c.fs);
      if (c.color) inp.style.color = c.color;                 // 修复：输入框文字颜色此前不生效
      if (c.bold) inp.style.fontWeight = '700';              // 修复：输入框加粗此前不生效
      if (c.bg) inp.style.background = c.bg;
      if (validNum(c.radius)) inp.style.borderRadius = px(c.radius);
      inp.style.height = validNum(c.h) ? px(c.h) : (abs ? '100%' : '');
      if (c.align) inp.style.textAlign = c.align;
      wrap.appendChild(inp);
    } else if (c.type === 'list') {
      var box = el('div', 'list');
      if (c.bg) box.style.background = c.bg;
      if (c.color) box.style.color = c.color;                // 修复：列表文字颜色此前不生效
      if (c.bold) box.style.fontWeight = '700';
      if (validNum(c.radius)) box.style.borderRadius = px(c.radius);
      if (abs) box.style.height = '100%';                    // 绝对定位填满统一默认高度
      if (validNum(c.h)) box.style.height = px(c.h);
      var ul = el('div', 'ul');
      if (validNum(c.fs)) ul.style.fontSize = px(c.fs);
      if (!abs) ul.style.maxHeight = '60vh'; else ul.style.maxHeight = '100%';
      box.appendChild(ul);
      var items = c.items || [];
      if (!items.length) ul.appendChild(el('div', 'empty', '（空列表）'));
      items.forEach(function (txt, i) { ul.appendChild(makeLi(c.id, txt, i, c)); });
      wrap.appendChild(box);
    } else if (c.type === 'image') {
      if (c.src) {
        var img = el('img'); img.src = c.src;
        img.style.width = '100%'; img.style.height = '100%'; img.style.objectFit = 'contain';
        if (validNum(c.radius)) img.style.borderRadius = px(c.radius);
        wrap.appendChild(img);
      } else {
        var ph = el('div', 'imgph', c.alt || '图片');
        if (validNum(c.radius)) ph.style.borderRadius = px(c.radius);
        wrap.appendChild(ph);
      }
      wrap.classList.add('clickable');
      wrap.addEventListener('click', function () { var fn = clickMap[c.id]; if (fn) { userGesture(); safe(fn); } });
    } else if (c.type === 'switch') {
      var srow = el('div', 'ctl-row sw-row');
      var slab = el('span', 'v-text', c.text || '开关'); applyTextStyle(slab, c);
      var sw = el('button', 'sw' + (c.checked ? ' on' : '')); sw.type = 'button';
      sw.appendChild(el('span', 'sw-knob'));
      srow.appendChild(slab); srow.appendChild(sw);
      wrap.__val = !!c.checked;
      function swToggle() {
        wrap.__val = !wrap.__val; sw.classList.toggle('on', wrap.__val);
        var fn = clickMap[c.id]; if (fn) { userGesture(); safe(fn); }
      }
      sw.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); swToggle(); });
      srow.addEventListener('click', function () { swToggle(); });
      if (c.align) srow.style.justifyContent = c.align === 'center' ? 'center' : (c.align === 'right' ? 'flex-end' : 'space-between');
      wrap.appendChild(srow);
    } else if (c.type === 'checkbox') {
      var crow = el('div', 'ctl-row ck-row');
      var ck = el('span', 'ck' + (c.checked ? ' on' : '')); ck.appendChild(el('span', 'ck-tick', '✓'));
      var clab = el('span', 'v-text', c.text || '复选项'); applyTextStyle(clab, c);
      crow.appendChild(ck); crow.appendChild(clab);
      wrap.__val = !!c.checked;
      function ckToggle() {
        wrap.__val = !wrap.__val; ck.classList.toggle('on', wrap.__val);
        var fn = clickMap[c.id]; if (fn) { userGesture(); safe(fn); }
      }
      crow.addEventListener('click', function (e) { e.preventDefault(); ckToggle(); });
      if (c.align) crow.style.justifyContent = c.align === 'center' ? 'center' : (c.align === 'right' ? 'flex-end' : 'flex-start');
      wrap.appendChild(crow);
    } else if (c.type === 'slider') {
      var rng = el('input'); rng.type = 'range'; rng.className = 'rng';
      rng.min = validNum(c.min) ? c.min : 0;
      rng.max = validNum(c.max) ? c.max : 100;
      rng.value = validNum(c.value) ? c.value : 0;
      if (c.bg) rng.style.accentColor = c.bg;
      if (c.color) rng.style.accentColor = c.color;
      wrap.__val = Number(rng.value);
      rng.addEventListener('input', function () {
        wrap.__val = Number(rng.value);
        var fn = changeMap[c.id]; if (fn) { userGesture(); safe(function () { fn(wrap.__val); }); }
      });
      wrap.appendChild(rng);
    } else if (c.type === 'progress') {
      var pmax = validNum(c.max) ? c.max : 100;
      var pv0 = Math.max(0, Math.min(pmax, validNum(c.value) ? c.value : 0));
      var track = el('div', 'prog');
      var pfill = el('div', 'prog-fill');
      if (c.bg) pfill.style.background = c.bg;
      if (validNum(c.radius)) { track.style.borderRadius = px(c.radius); pfill.style.borderRadius = px(c.radius); }
      track.appendChild(pfill);
      wrap.appendChild(track);
      wrap.__val = pv0; wrap.__max = pmax;
      pfill.style.width = (pmax ? (pv0 / pmax * 100) : 0) + '%';
    } else if (c.type === 'video') {
      var vid = el('video', 'rt-media'); vid.controls = false; vid.preload = 'metadata';
      vid.setAttribute('playsinline', '');
      if (c.src) vid.src = resolveMedia(c.src);
      vid.addEventListener('error', function () {});
      wrap.__media = vid;
      wrap.appendChild(vid);
    } else if (c.type === 'audio') {
      var aud = el('audio', 'rt-media'); aud.controls = true; aud.preload = 'none';
      if (c.src) aud.src = resolveMedia(c.src);
      wrap.__media = aud;
      wrap.appendChild(aud);
    } else if (c.type === 'web') {
      var frm = el('iframe', 'rt-web'); frm.setAttribute('sandbox', 'allow-scripts allow-same-origin');
      frm.setAttribute('allow', 'fullscreen');
      if (c.url) frm.src = c.url;
      wrap.__media = frm;
      wrap.appendChild(frm);
    }
    return wrap;
  }

  function makeLi(listId, txt, i, c) {
    var li = el('div', 'li', txt == null ? '' : String(txt));
    if (c && validNum(c.fs)) li.style.fontSize = px(c.fs);
    if (c && c.align) li.style.justifyContent = c.align === 'center' ? 'center' : (c.align === 'right' ? 'flex-end' : 'flex-start');
    li.addEventListener('click', function () {
      selected[listId] = { item: txt, index: i };
      var fn = itemClickMap[listId];
      if (fn) { userGesture(); safe(function () { fn(txt, i); }); }
    });
    return li;
  }

  function compRoot(id) { return document.querySelector('[data-id="' + id + '"]'); }
  function compRootMedia(id) { var r = compRoot(id); return r ? r.__media : null; }
  // media://xxx 引用：交由原生解析成可播放 file 地址（编辑器私有目录 / 导出 APK 的 assets）
  function resolveMedia(src) {
    if (src && src.indexOf('media://') === 0) {
      var name = src.slice(8);
      try { if (window.Native && Native.mediaUrl) { var u = Native.mediaUrl(name); if (u) return u; } } catch (e) {}
      return src;
    }
    return src;
  }

  /* ---------------- 云列表（SeaTable，支持一个作品接入多个云表格） ---------------- */
  function newCloudSlot() { return { cfg: null, jwt: null, uuid: null, gateway: null, meta: {} }; }
  var cloudPool = Object.create(null);
  var cloudLegacy = newCloudSlot();   // 旧版 cloudSetup 积木使用的默认连接
  function cloudSlot(id) {
    if (id && cloudPool[id]) return cloudPool[id];
    return cloudLegacy;
  }
  function cloudDefaultServer(p) {
    if (p === 'seatable-io') return 'https://cloud.seatable.io';
    return 'https://cloud.seatable.cn';
  }
  function sqlEscape(v) { return String(v == null ? '' : v).replace(/'/g, "''"); }
  // 统一解析：非 2xx 或业务错误都抛出带信息的 Error
  function cloudInterpret(status, txt) {
    var data = null; if (txt) { try { data = JSON.parse(txt); } catch (e) { data = null; } }
    var errMsg = data && (data.error_message || data.error_msg || data.detail || data.error);
    if (status < 200 || status >= 300 || errMsg) throw new Error(errMsg || ('云列表请求失败 HTTP ' + status));
    return data;
  }
  // 原生桥接 HTTP（App 内优先；绕过 WebView CORS，例如 SeaTable 网关重复 ACAO 头）
  var httpSeq = 0;
  window.__nativeHttpResolve = function (id, json) {
    var f = window.__httpPending && window.__httpPending[id];
    if (f) { try { delete window.__httpPending[id]; } catch (e) { window.__httpPending[id] = null; } f(json); }
  };
  function nativeHttp(method, url, headers, bodyText) {
    return new Promise(function (resolve, reject) {
      if (!(window.Native && Native.httpRequest)) { reject(new Error('NO_NATIVE')); return; }
      var id = 'h' + (++httpSeq) + '_' + Date.now();
      window.__httpPending = window.__httpPending || {};
      var done = false;
      var timer = setTimeout(function () {
        if (done) return; done = true; delete window.__httpPending[id]; reject(new Error('网络请求超时'));
      }, 25000);
      window.__httpPending[id] = function (payloadText) {
        if (done) return; done = true; clearTimeout(timer); delete window.__httpPending[id];
        var r = null; try { r = JSON.parse(payloadText); } catch (e) { reject(new Error('网络响应解析失败')); return; }
        resolve(r);
      };
      try { Native.httpRequest(id, method, url, JSON.stringify(headers || {}), bodyText || ''); }
      catch (e) { if (done) return; done = true; clearTimeout(timer); delete window.__httpPending[id]; reject(e); }
    });
  }
  function cloudHttp(method, url, body, token) {
    var h = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
    if (token) h['Authorization'] = 'Token ' + token;
    var bodyText = (body !== undefined && body !== null) ? JSON.stringify(body) : null;
    if (window.Native && Native.httpRequest) {
      return nativeHttp(method, url, h, bodyText).then(function (r) {
        if (r && r.error) throw new Error(r.error);
        return cloudInterpret((r && r.status) || 0, (r && r.body) || '');
      });
    }
    var opt = { method: method, headers: h };
    if (bodyText !== null) opt.body = bodyText;
    return fetch(url, opt).then(function (resp) {
      return resp.text().then(function (txt) { return cloudInterpret(resp.status, txt); });
    });
  }
  async function cloudAuth(slot, force) {
    if (!slot.cfg) throw new Error('请先在“云列表”分类里创建云表格（填写名称、UUID 和 API 密钥）');
    if (slot.jwt && !force) return slot;
    var d = await cloudHttp('GET', slot.cfg.server + '/api/v2.1/dtable/app-access-token/', null, slot.cfg.token);
    if (!d || !d.access_token) throw new Error('云表格鉴权失败，请检查 API 密钥');
    slot.jwt = d.access_token;
    slot.uuid = d.dtable_uuid || slot.cfg.uuid;
    slot.gateway = (d.dtable_server || (slot.cfg.server + '/api-gateway/')).replace(/\/+$/, '');
    return slot;
  }
  async function cloudGateway(slot, method, path, body, retrying) {
    var s = await cloudAuth(slot, false);
    // 路径里的 {uuid} 在鉴权完成后再替换（首次调用时 slot.uuid 尚未拿到）
    var realPath = String(path).replace('{uuid}', encodeURIComponent(s.uuid || ''));
    try {
      return await cloudHttp(method, s.gateway + realPath, body, s.jwt);
    } catch (e) {
      // token 过期（401/403）时强制重新鉴权重试一次
      if (!retrying && /HTTP (401|403)/.test(e.message)) {
        await cloudAuth(s, true);
        return cloudGateway(s, method, path, body, true);
      }
      throw e;
    }
  }
  // 取某表的 列key→列名 映射（GET rows 返回列 key，需要转回中文列名）
  async function cloudColumnMap(slot, table) {
    if (slot.meta[table]) return slot.meta[table];
    var d = await cloudGateway(slot, 'GET', '/api/v2/dtables/{uuid}' + '/metadata/', null);
    var map = {};
    ((d && d.metadata && d.metadata.tables) || []).forEach(function (t) {
      if (t.name !== table) return;
      (t.columns || []).forEach(function (col) { map[col.key] = col.name; });
    });
    slot.meta[table] = map;
    return map;
  }

  /* ---------------- 积木可调用的 RT API ---------------- */
  var RT = {
    on: function (evt, fn) {
      if (evt === 'start') startHandlers.push(fn);
      else if (evt === 'firstStart') firstStartHandlers.push(fn);
    },
    onClick: function (id, fn) { clickMap[id] = fn; },
    onItemClick: function (id, fn) { itemClickMap[id] = fn; },
    onChange: function (id, fn) { changeMap[id] = fn; },
    setText: function (id, v) {
      var root = compRoot(id); if (!root) return;
      var t = root.querySelector('.v-text'); if (t) t.textContent = (v == null ? '' : String(v));
      var inp = root.querySelector('input'); if (inp) inp.value = (v == null ? '' : String(v));
    },
    getText: function (id) {
      var root = compRoot(id); if (!root) return '';
      var inp = root.querySelector('input'); if (inp) return inp.value;
      var t = root.querySelector('.v-text'); return t ? t.textContent : '';
    },
    /* 设置输入框提示词（placeholder） */
    setHint: function (id, v) {
      var root = compRoot(id); if (!root) return;
      var inp = root.querySelector('input'); if (inp) inp.placeholder = (v == null ? '' : String(v));
    },
    toast: function (m) { showToast(String(m == null ? '' : m)); },
    gotoPage: function (name) { var s = resolveScreen(name); if (s) navigate(s.id, false); },
    back: function () { goBack(); },
    listAdd: function (id, v) {
      var root = compRoot(id), ul = root && root.querySelector('.ul'); if (!ul) return;
      var empty = ul.querySelector('.empty'); if (empty) empty.remove();
      var c = (current.components || []).filter(function (x) { return x.id === id; })[0];
      ul.appendChild(makeLi(id, v, ul.querySelectorAll('.li').length, c));
    },
    listClear: function (id) { var root = compRoot(id), ul = root && root.querySelector('.ul'); if (ul) ul.innerHTML = '<div class="empty">（空列表）</div>'; },
    listSet: function (id, arr) {
      var root = compRoot(id), ul = root && root.querySelector('.ul'); if (!ul) return;
      ul.innerHTML = '';
      var c = (current.components || []).filter(function (x) { return x.id === id; })[0];
      if (!arr || !arr.length) { ul.appendChild(el('div', 'empty', '（空列表）')); return; }
      arr.forEach(function (v, i) { ul.appendChild(makeLi(id, v, i, c)); });
    },
    selectedItem: function (id) { return selected[id] ? selected[id].item : ''; },
    selectedIndex: function (id) { return selected[id] ? selected[id].index : -1; },
    /* 显示 / 隐藏组件 */
    show: function (id) { var r = compRoot(id); if (r) r.style.display = ''; },
    hide: function (id) { var r = compRoot(id); if (r) r.style.display = 'none'; },
    setVisible: function (id, v) { var r = compRoot(id); if (r) r.style.display = v ? '' : 'none'; },
    /* 透明度 0~100 */
    setOpacity: function (id, v) {
      var r = compRoot(id); if (!r) return;
      var n = Number(v); if (!isFinite(n)) return;
      r.style.opacity = (Math.max(0, Math.min(100, n)) / 100).toFixed(3);
    },
    /* 震动：优先原生（WebView 多禁用 navigator.vibrate），回退网页振动 */
    vibrate: function (ms) {
      var n = Math.max(1, parseInt(ms, 10) || 30);
      try { if (window.Native && Native.vibrate) { Native.vibrate(n); return; } } catch (e) {}
      try { navigator.vibrate && navigator.vibrate(n); } catch (e) {}
    },
    /* 等待若干秒（在 async 事件里用 await 调用），界面不卡死 */
    wait: function (sec) {
      var n = Number(sec); if (!isFinite(n) || n < 0) n = 0;
      return new Promise(function (resolve) { setTimeout(resolve, n * 1000); });
    },
    /* 退出：试运行/编辑器内只退出试运行（返回编辑器）；导出的独立 App 才真正退出应用 */
    exit: function () {
      if (isPreview || mode() === 'editor') { try { history.back(); } catch (e) {} return; }
      try { if (window.Native && Native.exitApp) { Native.exitApp(); return; } } catch (e) {}
      showToast('已请求退出应用');
    },
    /* 开关 / 复选框：设置与读取布尔状态 */
    setChecked: function (id, v) {
      var r = compRoot(id); if (!r) return;
      var on = !!v; r.__val = on;
      var sw = r.querySelector('.sw'), ck = r.querySelector('.ck');
      if (sw) sw.classList.toggle('on', on);
      if (ck) ck.classList.toggle('on', on);
    },
    getChecked: function (id) { var r = compRoot(id); return r ? !!r.__val : false; },
    /* 滑块：设置与读取数值 */
    setSlider: function (id, v) {
      var r = compRoot(id), n = r && r.querySelector('.rng'); if (!n) return;
      var num = Number(v); if (!isFinite(num)) return;
      n.value = num; r.__val = Number(n.value);
    },
    getSlider: function (id) { var r = compRoot(id); return r ? Number(r.__val || 0) : 0; },
    /* 进度条：设置与读取进度（按最大值自动钳制） */
    setProgress: function (id, v) {
      var r = compRoot(id), f = r && r.querySelector('.prog-fill'); if (!f) return;
      var mx = r.__max || 100, n = Math.max(0, Math.min(mx, Number(v) || 0));
      r.__val = n; f.style.width = (mx ? (n / mx * 100) : 0) + '%';
    },
    getProgress: function (id) { var r = compRoot(id); return r ? Number(r.__val || 0) : 0; },
    /* 视频 / 音频：播放、暂停、切换地址 */
    videoPlay: function (id) { var m = compRootMedia(id); if (m && m.play) try { m.play(); } catch (e) {} },
    videoPause: function (id) { var m = compRootMedia(id); if (m && m.pause) try { m.pause(); } catch (e) {} },
    videoSeek: function (id, sec) { var m = compRootMedia(id); if (!m) return; var t = Number(sec); if (isFinite(t)) try { m.currentTime = Math.max(0, t); } catch (e) {} },
    videoSrc: function (id, url) { var r = compRoot(id); if (!r || !r.__media) return; r.__media.src = resolveMedia(String(url || '')); if (r.__media.play) { try { r.__media.load(); r.__media.play(); } catch (e) {} } },
    audioPlay: function (id) { var m = compRootMedia(id); if (m && m.play) try { m.play(); } catch (e) {} },
    audioPause: function (id) { var m = compRootMedia(id); if (m && m.pause) try { m.pause(); } catch (e) {} },
    audioSeek: function (id, sec) { var m = compRootMedia(id); if (!m) return; var t = Number(sec); if (isFinite(t)) try { m.currentTime = Math.max(0, t); } catch (e) {} },
    audioSrc: function (id, url) { var r = compRoot(id); if (!r || !r.__media) return; r.__media.src = resolveMedia(String(url || '')); if (r.__media.play) { try { r.__media.load(); r.__media.play(); } catch (e) {} } },
    /* 网页：加载网址 */
    webUrl: function (id, url) { var r = compRoot(id); if (!r || !r.__media) return; r.__media.src = String(url || ''); },
    /* 背景色 / 文字颜色：作用到组件的可见元素 */
    setBg: function (id, color) {
      var r = compRoot(id); if (!r || !color) return;
      var n = r.querySelector('.matbtn,input,.list,.imgph,.sw.on,.prog-fill,.rng') || r;
      if (n.classList && n.classList.contains('rng')) { n.style.accentColor = color; return; }
      n.style.background = color;
    },
    setFg: function (id, color) {
      var r = compRoot(id); if (!r || !color) return;
      var n = r.querySelector('.matbtn,input,.list,.v-text,.ck.on') || r;
      n.style.color = color;
    },
    /* ===== 云表格（SeaTable），每个云表格由编辑器分配 id ===== */
    // 登记一个云表格（代码生成时自动注入，同步执行）
    cloudRegister: function (id, cfg) {
      if (!id || !cfg) return;
      var provider = cfg.provider || 'seatable-cn';
      var srv = String(cfg.server || '').trim().replace(/\/+$/, '');
      if (provider !== 'seatable-custom' || !srv) srv = cloudDefaultServer(provider);
      cloudPool[id] = newCloudSlot();
      cloudPool[id].cfg = {
        provider: provider, server: srv,
        uuid: String(cfg.uuid == null ? '' : cfg.uuid).trim(),
        token: String(cfg.token == null ? '' : cfg.token).trim(),
        name: cfg.name || ''
      };
    },
    cloudTables: async function (cid) {
      var s = cloudSlot(cid);
      var d = await cloudGateway(s, 'GET', '/api/v2/dtables/{uuid}' + '/metadata/', null);
      return (d && d.metadata && d.metadata.tables || []).map(function (t) { return t.name; });
    },
    cloudRows: async function (cid, table) {
      var s = cloudSlot(cid), name = sqlEscape(table).replace(/`/g, '');
      var d = await cloudGateway(s, 'POST', '/api/v2/dtables/{uuid}' + '/sql/',
        { sql: 'SELECT * FROM `' + name + '`', convert_keys: true });
      return (d && d.results) || [];
    },
    cloudSql: async function (cid, sql) {
      var s = cloudSlot(cid);
      var d = await cloudGateway(s, 'POST', '/api/v2/dtables/{uuid}' + '/sql/',
        { sql: String(sql == null ? '' : sql), convert_keys: true });
      return (d && d.results) || [];
    },
    cloudRowCount: async function (cid, table) {
      var s = cloudSlot(cid), name = sqlEscape(table).replace(/`/g, '');
      var d = await cloudGateway(s, 'POST', '/api/v2/dtables/{uuid}' + '/sql/',
        { sql: 'SELECT COUNT(*) AS n FROM `' + name + '`', convert_keys: true });
      var rows = (d && d.results) || [];
      return rows[0] ? Number(rows[0].n || 0) : 0;
    },
    cloudRowById: async function (cid, table, rowId) {
      var s = cloudSlot(cid), id = String(rowId == null ? '' : rowId);
      if (!id) throw new Error('取一行需要填写行 Id');
      var path = '/api/v2/dtables/{uuid}' + '/rows/?table_name=' + encodeURIComponent(String(table))
        + '&start=0&limit=1000';
      var d = await cloudGateway(s, 'GET', path, null);
      var raw = ((d && d.rows) || []).filter(function (r) { return r._id === id; })[0];
      if (!raw) return null;
      var colMap = await cloudColumnMap(s, String(table));
      var row = {};
      Object.keys(raw).forEach(function (k) { row[colMap[k] || k] = raw[k]; });
      return row;
    },
    cloudAddRow: async function (cid, table, rowOrJson) {
      var s = cloudSlot(cid);
      var row = rowOrJson;
      if (typeof row === 'string') { try { row = JSON.parse(row); } catch (e) { throw new Error('新增一行的数据格式不正确：' + e.message); } }
      if (!row || typeof row !== 'object') throw new Error('新增一行需要至少一个字段');
      var d = await cloudGateway(s, 'POST', '/api/v2/dtables/{uuid}' + '/rows/',
        { table_name: String(table), rows: [row] });
      var ids = (d && d.row_ids) || [];
      return ids[0] && ids[0]._id ? ids[0]._id : ((d && d.inserted_row_count) || 0);
    },
    cloudUpdateRow: async function (cid, table, rowId, rowOrJson) {
      var s = cloudSlot(cid), id = String(rowId == null ? '' : rowId);
      if (!id) throw new Error('更新一行需要填写行 Id');
      var row = rowOrJson;
      if (typeof row === 'string') { try { row = JSON.parse(row); } catch (e) { throw new Error('更新内容格式不正确：' + e.message); } }
      if (!row || typeof row !== 'object') throw new Error('更新一行需要至少一个字段');
      var d = await cloudGateway(s, 'PUT', '/api/v2/dtables/{uuid}' + '/rows/',
        { table_name: String(table), updates: [{ row_id: id, row: row }] });
      return !!(d && d.success);
    },
    cloudDeleteRow: async function (cid, table, rowId) {
      var s = cloudSlot(cid), id = String(rowId == null ? '' : rowId);
      if (!id) throw new Error('删除一行需要填写行 Id');
      var d = await cloudGateway(s, 'DELETE', '/api/v2/dtables/{uuid}' + '/rows/',
        { table_name: String(table), row_ids: [id] });
      return Number((d && d.deleted_rows) || 0);
    },
    // 旧版（v1.9.6）设置云列表积木：登记到默认连接
    cloudSetup: async function (provider, server, uuid, token) {
      var srv = String(server || '').trim().replace(/\/+$/, '');
      if (provider === 'seatable-custom' && srv) { /* 使用自定义服务器 */ }
      else srv = cloudDefaultServer(provider);
      cloudLegacy.cfg = {
        provider: provider || 'seatable-cn', server: srv,
        uuid: String(uuid == null ? '' : uuid).trim(),
        token: String(token == null ? '' : token).trim()
      };
      cloudLegacy.jwt = null; cloudLegacy.uuid = null; cloudLegacy.gateway = null; cloudLegacy.meta = {};
      if (!cloudLegacy.cfg.uuid || !cloudLegacy.cfg.token) throw new Error('云列表缺少 UUID 或 API 密钥');
      await cloudAuth(cloudLegacy, true);
    },
    // 从一行数据（对象或 JSON 字符串）里取某字段的值
    jsonGet: function (obj, key) {
      if (obj == null) return '';
      if (typeof obj === 'string') { try { obj = JSON.parse(obj); } catch (e) { return ''; } }
      if (typeof obj !== 'object') return '';
      return Object.prototype.hasOwnProperty.call(obj, key) ? obj[key] : '';
    }
  };

  function runCode(sc) {
    try { new Function('RT', sc.code || '')(RT); }
    catch (e) { console.error('逻辑执行错误', e); showToast('该页面逻辑有误：' + e.message); }
    // 收集本页要触发的启动事件：首次启动仅本进程第一次打开该页时触发（先于每次启动）
    var isFirst = !firstFired[sc.id];
    if (isFirst) firstFired[sc.id] = true;
    var queue = isFirst ? firstStartHandlers.concat(startHandlers) : startHandlers.slice();
    var gen = renderGen;
    // 关键：等当前渲染/跳转调用栈完全结束后（宏任务）再触发启动事件。
    // 否则“页面启动就跳转、新页面启动又跳回”会在同一个调用栈里递归，直接爆栈。
    setTimeout(function () {
      if (gen !== renderGen) return;          // 已被后续跳转取代，本页启动事件不再补跑
      var times = (autoBurst[sc.id] || 0) + 1;
      autoBurst[sc.id] = times;
      if (times >= 3) {
        // 同一页面的“当页面启动时”在一段自动跳转中第 3 次触发=启动事件驱动的死循环（含等待后互跳的慢循环）：
        // 静默刹车，不再执行“每次启动”积木（不再弹提示框）；“首次启动”积木只会执行一次，不可能构成死循环，照常执行。
        queue = isFirst ? firstStartHandlers.slice() : [];
      }
      // 串行 await：整个启动事件（含“等待 N 秒再跳转”的延续）都算自动导航流程，
      // 期间跳转替换返回栈、循环计数不清零；前一个事件跳走后本页后续事件不再执行。
      (async function runQueue() {
        navKind = 'auto';
        for (var i = 0; i < queue.length; i++) {
          if (gen !== renderGen) return;      // 队列中前一个积木已跳转到别的页面，本页后续积木不再执行
          await safeAsync(queue[i]);
        }
      })();
    }, 0);
  }
  function safe(fn) {
    try {
      var r = fn();
      if (r && typeof r.then === 'function') r.catch(function (e) { console.error(e); showToast('动作出错：' + e.message); });
    } catch (e) { console.error(e); showToast('动作出错：' + e.message); }
  }
  // 与 safe 相同，但等待事件执行完（含 await），供启动队列串行调度使用
  function safeAsync(fn) {
    return new Promise(function (resolve) {
      try {
        var r = fn();
        if (r && typeof r.then === 'function') {
          r.then(function () { resolve(); }, function (e) { console.error(e); showToast('动作出错：' + e.message); resolve(); });
        } else resolve();
      } catch (e) { console.error(e); showToast('动作出错：' + e.message); resolve(); }
    });
  }

  var toastTimer = null;
  function showToast(msg) {
    var t = $('#toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.classList.remove('show'); }, 1800);
  }

  /* 系统返回键：能出栈就出栈；预览时返回编辑器；否则交给原生退出 */
  window.__rtSystemBack = function () {
    if (goBack()) return true;
    if (isPreview) { history.back(); return true; }
    return false;
  };
  $('#exitpreview').addEventListener('click', function () { history.back(); });

  /* 左侧边缘侧滑返回：从屏幕左缘 26px 内按下、向右拖过 64px 且以横向为主，即返回上一页/退出预览 */
  (function edgeSwipe() {
    var sx = 0, sy = 0, active = false, hint = null;
    function ensureHint() { if (!hint) hint = document.getElementById('edgeHint'); return hint; }
    document.addEventListener('touchstart', function (e) {
      var t = e.touches[0]; active = t.clientX <= 26; if (active) { sx = t.clientX; sy = t.clientY; }
    }, { passive: true, capture: true });
    document.addEventListener('touchmove', function (e) {
      if (!active) return; var t = e.touches[0], dx = t.clientX - sx, dy = t.clientY - sy;
      var h = ensureHint();
      if (dx > 12 && Math.abs(dx) > Math.abs(dy) && h) { h.classList.add('show'); h.style.transform = 'translateX(' + Math.min(dx - 12, 90) + 'px)'; }
    }, { passive: true, capture: true });
    function end(e) {
      if (!active) return; active = false;
      var h = ensureHint(), t = e.changedTouches ? e.changedTouches[0] : null;
      var dx = t ? t.clientX - sx : 0, dy = t ? t.clientY - sy : 0;
      if (h) { h.classList.remove('show'); h.style.transform = ''; }
      if (dx > 64 && Math.abs(dx) > Math.abs(dy) * 1.4) window.__rtSystemBack && window.__rtSystemBack();
    }
    document.addEventListener('touchend', end, { passive: true, capture: true });
    document.addEventListener('touchcancel', function () { active = false; var h = ensureHint(); if (h) { h.classList.remove('show'); h.style.transform = ''; } }, { passive: true, capture: true });
  })();

  loadProject();
  // 只有编辑器试运行才显示"启动中…"遮罩；导出的独立APP直接进
  if (!isPreview) {
    var s0 = document.getElementById('splash');
    if (s0) s0.style.display = 'none';
  } else {
    var splashHidden = false, settleT = null;
    function hideSplash() {
      if (splashHidden) return; splashHidden = true;
      var s = document.getElementById('splash');
      if (s) s.style.display = 'none';
    }
    function scheduleHide() {
      if (settleT) clearTimeout(settleT);
      settleT = setTimeout(hideSplash, 500);
    }
    window.addEventListener('resize', scheduleHide);
    scheduleHide();
    setTimeout(hideSplash, 2500);
  }
})();
