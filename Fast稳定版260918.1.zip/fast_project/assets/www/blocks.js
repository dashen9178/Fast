/* 自定义积木：块定义 + JavaScript 代码生成器 + 工具箱。依赖 blockly 已加载。 */
(function () {
  'use strict';
  var B = window.Blockly;
  var JS = B.JavaScript; // v10 UMD 中的 JS 生成器单例
  var C_EVENT = '#FB8C00', C_ACT = '#1565C0', C_VAL = '#00897B';

  // 形态统一：半包围积木开口内不再放“执行/否则”等文字标签（D 形细脊柱风格）
  ['CONTROLS_IF_MSG_THEN', 'CONTROLS_IF_MSG_ELSE', 'CONTROLS_REPEAT_INPUT_DO',
   'CONTROLS_WHILEUNTIL_INPUT_DO', 'CONTROLS_FOR_INPUT_DO', 'CONTROLS_FOREACH_INPUT_DO'
  ].forEach(function (k) { B.Msg[k] = ''; });

  // 组件下拉（选项由 editor.js 动态提供）
  function compField(types) {
    return new B.FieldDropdown(function () {
      return window.__compOptions ? window.__compOptions(types)
        : [['（请先添加组件）', 'NONE']];
    });
  }
  function pageField() {
    return new B.FieldDropdown(function () {
      return window.__pageOptions ? window.__pageOptions() : [['（无页面）', 'NONE']];
    });
  }
  function q(s) { return JSON.stringify(String(s)); }

  /* ---------------- 块定义 ---------------- */

  // 事件：页面启动（帽子块：只能作为一段程序的入口，顶部/底部都不能再接积木）
  B.Blocks['ev_start'] = {
    init: function () {
      this.appendDummyInput().appendField('   当页面启动时');
      this.appendStatementInput('DO');
      this.setColour(C_EVENT);
      this.hat = 'cap';
      this.setTooltip('该页面一打开就执行；这是程序入口，上面不能接积木。把要执行的积木拖进下方开口');
    }
  };
  // 事件：页面首次启动（帽子块：本次运行进程内，每个页面只触发一次）
  B.Blocks['ev_first_start'] = {
    init: function () {
      this.appendDummyInput().appendField('   当页面首次启动时');
      this.appendStatementInput('DO');
      this.setColour(C_EVENT);
      this.hat = 'cap';
      this.setTooltip('本次打开 App 的过程中，该页面第一次被打开时执行一次；之后再跳回本页面不会重复执行。把 App 从后台彻底划掉后重新打开，会再次执行。适合做一次性初始化');
    }
  };
  // 事件：组件被点击
  B.Blocks['ev_click'] = {
    init: function () {
      this.appendDummyInput()
        .appendField('当组件')
        .appendField(compField(), 'COMP')
        .appendField('被点击');
      this.appendStatementInput('DO');
      this.setColour(C_EVENT);
      this.hat = 'cap';
      this.setTooltip('点击指定组件时执行；这是程序入口，上面不能接积木。把要执行的积木拖进下方开口');
    }
  };
  // 事件：列表项被点击
  B.Blocks['ev_itemclick'] = {
    init: function () {
      this.appendDummyInput()
        .appendField('当列表')
        .appendField(compField(['list']), 'COMP')
        .appendField('某项被点击');
      this.appendStatementInput('DO');
      this.setColour(C_EVENT);
      this.hat = 'cap';
      this.setTooltip('点击列表某一项时执行；这是程序入口，上面不能接积木。开口内可用“列表选中项”积木拿到被点中的项');
    }
  };

  // 动作：设置组件文本
  B.Blocks['act_set_text'] = {
    init: function () {
      this.appendValueInput('VALUE')
        .appendField('设置组件')
        .appendField(compField(), 'COMP')
        .appendField('文本为');
      this.setInputsInline(true);
      this.setPreviousStatement(true);
      this.setNextStatement(true);
      this.setColour(C_ACT);
    }
  };
  // 动作：弹出提示
  B.Blocks['act_toast'] = {
    init: function () {
      this.appendValueInput('MSG').appendField('弹出提示');
      this.setInputsInline(true);
      this.setPreviousStatement(true);
      this.setNextStatement(true);
      this.setColour(C_ACT);
    }
  };
  // 动作：跳转页面
  B.Blocks['act_goto'] = {
    init: function () {
      this.appendDummyInput().appendField('跳转到页面').appendField(pageField(), 'PAGE');
      this.setPreviousStatement(true);
      this.setNextStatement(true);
      this.setColour(C_ACT);
    }
  };
  // 动作：返回
  B.Blocks['act_back'] = {
    init: function () {
      this.appendDummyInput().appendField('返回上一页');
      this.setPreviousStatement(true);
      this.setNextStatement(true);
      this.setColour(C_ACT);
    }
  };
  // 动作：列表添加项
  B.Blocks['act_list_add'] = {
    init: function () {
      this.appendValueInput('VALUE')
        .appendField('给列表')
        .appendField(compField(['list']), 'COMP')
        .appendField('添加');
      this.setInputsInline(true);
      this.setPreviousStatement(true);
      this.setNextStatement(true);
      this.setColour(C_ACT);
    }
  };
  // 动作：列表设置全部数据
  B.Blocks['act_list_set'] = {
    init: function () {
      this.appendValueInput('LIST')
        .appendField('设置列表')
        .appendField(compField(['list']), 'COMP')
        .appendField('数据为');
      this.setInputsInline(true);
      this.setPreviousStatement(true);
      this.setNextStatement(true);
      this.setColour(C_ACT);
    }
  };
  // 动作：清空列表
  B.Blocks['act_list_clear'] = {
    init: function () {
      this.appendDummyInput().appendField('清空列表').appendField(compField(['list']), 'COMP');
      this.setPreviousStatement(true);
      this.setNextStatement(true);
      this.setColour(C_ACT);
    }
  };
  // 动作：显示组件
  B.Blocks['act_show'] = {
    init: function () {
      this.appendDummyInput().appendField('显示组件').appendField(compField(), 'COMP');
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_ACT);
    }
  };
  // 动作：隐藏组件
  B.Blocks['act_hide'] = {
    init: function () {
      this.appendDummyInput().appendField('隐藏组件').appendField(compField(), 'COMP');
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_ACT);
    }
  };
  // 动作：设置透明度（0~100）
  B.Blocks['act_opacity'] = {
    init: function () {
      this.appendValueInput('V').appendField('设置组件').appendField(compField(), 'COMP').appendField('透明度(0~100)为');
      this.setInputsInline(true);
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_ACT);
    }
  };

  /* ---- 视频播放器 ---- */
  B.Blocks['act_video_play'] = {
    init: function () { this.appendDummyInput().appendField('播放视频').appendField(compField(['video']), 'COMP');
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_ACT); }
  };
  B.Blocks['act_video_pause'] = {
    init: function () { this.appendDummyInput().appendField('暂停视频').appendField(compField(['video']), 'COMP');
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_ACT); }
  };
  B.Blocks['act_video_src'] = {
    init: function () { this.appendValueInput('URL').appendField('设置视频').appendField(compField(['video']), 'COMP').appendField('地址为');
      this.setInputsInline(true); this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_ACT); }
  };
  B.Blocks['act_video_seek'] = {
    init: function () { this.appendValueInput('SEC').appendField('跳转视频到').appendField(compField(['video']), 'COMP').appendField('秒');
      this.setInputsInline(true); this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_ACT); }
  };
  /* ---- 音频播放 ---- */
  B.Blocks['act_audio_play'] = {
    init: function () { this.appendDummyInput().appendField('播放音频').appendField(compField(['audio']), 'COMP');
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_ACT); }
  };
  B.Blocks['act_audio_pause'] = {
    init: function () { this.appendDummyInput().appendField('暂停音频').appendField(compField(['audio']), 'COMP');
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_ACT); }
  };
  B.Blocks['act_audio_src'] = {
    init: function () { this.appendValueInput('URL').appendField('设置音频').appendField(compField(['audio']), 'COMP').appendField('地址为');
      this.setInputsInline(true); this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_ACT); }
  };
  B.Blocks['act_audio_seek'] = {
    init: function () { this.appendValueInput('SEC').appendField('跳转音频到').appendField(compField(['audio']), 'COMP').appendField('秒');
      this.setInputsInline(true); this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_ACT); }
  };
  /* ---- 网页 ---- */
  B.Blocks['act_web_url'] = {
    init: function () { this.appendValueInput('URL').appendField('设置网页').appendField(compField(['web']), 'COMP').appendField('网址为');
      this.setInputsInline(true); this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_ACT); }
  };

  var C_DEV = '#546E7A';
  // 设备：震动（毫秒，可接数字）
  B.Blocks['act_vibrate'] = {
    init: function () {
      this.appendValueInput('MS').appendField('震动 毫秒');
      this.setInputsInline(true);
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_DEV);
      this.setTooltip('让手机震动，括号内填毫秒数，如 30、200');
    }
  };
  // 设备：退出应用
  B.Blocks['act_exit'] = {
    init: function () {
      this.appendDummyInput().appendField('退出应用');
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_DEV);
      this.setTooltip('导出的独立 App 中退出应用；在编辑器“试运行”里则结束试运行、返回编辑器');
    }
  };

  var C_CTRL = '#607D8B';
  // 控制：等待若干秒（事件处理为异步，等待期间界面不卡死）
  B.Blocks['act_wait'] = {
    init: function () {
      this.appendValueInput('SECS').appendField('等待 秒');
      this.setInputsInline(true);
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_CTRL);
      this.setTooltip('等待指定秒数后再继续执行后面的动作，可填小数如 0.5');
    }
  };

  // 动作：设置组件背景色
  B.Blocks['act_set_bg'] = {
    init: function () {
      this.appendValueInput('COLOR')
        .appendField('设置组件').appendField(compField(), 'COMP').appendField('背景色为');
      this.setInputsInline(true);
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_ACT);
      this.setTooltip('修改按钮/输入框/列表等组件的背景颜色，颜色用“颜色”分类里的取色块');
    }
  };
  // 动作：设置组件文字颜色
  B.Blocks['act_set_color'] = {
    init: function () {
      this.appendValueInput('COLOR')
        .appendField('设置组件').appendField(compField(), 'COMP').appendField('文字颜色为');
      this.setInputsInline(true);
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_ACT);
      this.setTooltip('修改组件里文字的颜色，颜色用“颜色”分类里的取色块');
    }
  };

  // 取值：组件文本
  B.Blocks['val_get_text'] = {
    init: function () {
      this.appendDummyInput().appendField('组件').appendField(compField(), 'COMP').appendField('的文本');
      this.setOutput(true, null);
      this.setColour(C_VAL);
    }
  };
  // 取值：列表选中项 / 序号
  B.Blocks['val_selected_item'] = {
    init: function () {
      this.appendDummyInput().appendField('列表').appendField(compField(['list']), 'COMP').appendField('选中项');
      this.setOutput(true, null);
      this.setColour(C_VAL);
    }
  };
  B.Blocks['val_selected_index'] = {
    init: function () {
      this.appendDummyInput().appendField('列表').appendField(compField(['list']), 'COMP').appendField('选中序号');
      this.setOutput(true, 'Number');
      this.setColour(C_VAL);
    }
  };

  var C_MATH = '#3F51B5';
  // 取值：随机小数 0~1
  B.Blocks['val_random_frac'] = {
    init: function () {
      this.appendDummyInput().appendField('随机小数（0~1）');
      this.setOutput(true, 'Number'); this.setColour(C_MATH);
      this.setTooltip('生成一个大于等于 0、小于 1 的随机小数');
    }
  };
  // 取值：随机整数（区间，含两端）
  B.Blocks['val_random_int'] = {
    init: function () {
      this.appendValueInput('MIN').setCheck('Number').appendField('随机整数 从');
      this.appendValueInput('MAX').setCheck('Number').appendField('到');
      this.setInputsInline(true);
      this.setOutput(true, 'Number'); this.setColour(C_MATH);
      this.setTooltip('在“从…到…”两个整数之间随机取一个数（包含两端）');
    }
  };

  /* ---------------- JS 代码生成器 ---------------- */

  JS.forBlock['ev_start'] = function (b) {
    var body = JS.statementToCode(b, 'DO');
    return "RT.on('start', async function(){\n" + body + "});\n";
  };
  JS.forBlock['ev_first_start'] = function (b) {
    var body = JS.statementToCode(b, 'DO');
    return "RT.on('firstStart', async function(){\n" + body + "});\n";
  };
  JS.forBlock['ev_click'] = function (b) {
    var id = b.getFieldValue('COMP');
    var body = JS.statementToCode(b, 'DO');
    return "RT.onClick(" + q(id) + ", async function(){\n" + body + "});\n";
  };
  JS.forBlock['ev_itemclick'] = function (b) {
    var id = b.getFieldValue('COMP');
    var body = JS.statementToCode(b, 'DO');
    return "RT.onItemClick(" + q(id) + ", async function(__item, __index){\n" + body + "});\n";
  };
  JS.forBlock['act_set_text'] = function (b) {
    var v = JS.valueToCode(b, 'VALUE', JS.ORDER_ATOMIC) || "''";
    return "RT.setText(" + q(b.getFieldValue('COMP')) + ", " + v + ");\n";
  };
  JS.forBlock['act_toast'] = function (b) {
    var m = JS.valueToCode(b, 'MSG', JS.ORDER_ATOMIC) || "''";
    return "RT.toast(" + m + ");\n";
  };
  JS.forBlock['act_goto'] = function (b) {
    return "RT.gotoPage(" + q(b.getFieldValue('PAGE')) + ");\n";
  };
  JS.forBlock['act_back'] = function () { return "RT.back();\n"; };
  JS.forBlock['act_video_play'] = function (b) { return "RT.videoPlay(" + q(b.getFieldValue('COMP')) + ");\n"; };
  JS.forBlock['act_video_pause'] = function (b) { return "RT.videoPause(" + q(b.getFieldValue('COMP')) + ");\n"; };
  JS.forBlock['act_video_src'] = function (b) { var u = JS.valueToCode(b, 'URL', JS.ORDER_ATOMIC) || "''"; return "RT.videoSrc(" + q(b.getFieldValue('COMP')) + ", " + u + ");\n"; };
  JS.forBlock['act_video_seek'] = function (b) { var s = JS.valueToCode(b, 'SEC', JS.ORDER_ATOMIC) || "0"; return "RT.videoSeek(" + q(b.getFieldValue('COMP')) + ", " + s + ");\n"; };
  JS.forBlock['act_audio_play'] = function (b) { return "RT.audioPlay(" + q(b.getFieldValue('COMP')) + ");\n"; };
  JS.forBlock['act_audio_pause'] = function (b) { return "RT.audioPause(" + q(b.getFieldValue('COMP')) + ");\n"; };
  JS.forBlock['act_audio_src'] = function (b) { var u = JS.valueToCode(b, 'URL', JS.ORDER_ATOMIC) || "''"; return "RT.audioSrc(" + q(b.getFieldValue('COMP')) + ", " + u + ");\n"; };
  JS.forBlock['act_audio_seek'] = function (b) { var s = JS.valueToCode(b, 'SEC', JS.ORDER_ATOMIC) || "0"; return "RT.audioSeek(" + q(b.getFieldValue('COMP')) + ", " + s + ");\n"; };
  JS.forBlock['act_web_url'] = function (b) { var u = JS.valueToCode(b, 'URL', JS.ORDER_ATOMIC) || "''"; return "RT.webUrl(" + q(b.getFieldValue('COMP')) + ", " + u + ");\n"; };
  JS.forBlock['act_list_add'] = function (b) {
    var v = JS.valueToCode(b, 'VALUE', JS.ORDER_ATOMIC) || "''";
    return "RT.listAdd(" + q(b.getFieldValue('COMP')) + ", " + v + ");\n";
  };
  JS.forBlock['act_list_set'] = function (b) {
    var l = JS.valueToCode(b, 'LIST', JS.ORDER_ATOMIC) || "[]";
    return "RT.listSet(" + q(b.getFieldValue('COMP')) + ", " + l + ");\n";
  };
  JS.forBlock['act_list_clear'] = function (b) {
    return "RT.listClear(" + q(b.getFieldValue('COMP')) + ");\n";
  };
  JS.forBlock['act_show'] = function (b) { return "RT.show(" + q(b.getFieldValue('COMP')) + ");\n"; };
  JS.forBlock['act_hide'] = function (b) { return "RT.hide(" + q(b.getFieldValue('COMP')) + ");\n"; };
  JS.forBlock['act_opacity'] = function (b) {
    var v = JS.valueToCode(b, 'V', JS.ORDER_ATOMIC) || '100';
    return "RT.setOpacity(" + q(b.getFieldValue('COMP')) + ", " + v + ");\n";
  };
  JS.forBlock['act_vibrate'] = function (b) {
    var ms = JS.valueToCode(b, 'MS', JS.ORDER_ATOMIC) || '30';
    return "RT.vibrate(" + ms + ");\n";
  };
  JS.forBlock['act_exit'] = function () { return "RT.exit();\n"; };
  JS.forBlock['act_wait'] = function (b) {
    var s = JS.valueToCode(b, 'SECS', JS.ORDER_ATOMIC) || '1';
    return "await RT.wait(" + s + ");\n";
  };
  JS.forBlock['act_set_bg'] = function (b) {
    var c = JS.valueToCode(b, 'COLOR', JS.ORDER_ATOMIC) || "'#2196F3'";
    return "RT.setBg(" + q(b.getFieldValue('COMP')) + ", " + c + ");\n";
  };
  JS.forBlock['act_set_color'] = function (b) {
    var c = JS.valueToCode(b, 'COLOR', JS.ORDER_ATOMIC) || "'#000000'";
    return "RT.setFg(" + q(b.getFieldValue('COMP')) + ", " + c + ");\n";
  };
  JS.forBlock['val_get_text'] = function (b) {
    return ["RT.getText(" + q(b.getFieldValue('COMP')) + ")", JS.ORDER_ATOMIC];
  };
  JS.forBlock['val_selected_item'] = function (b) {
    return ["RT.selectedItem(" + q(b.getFieldValue('COMP')) + ")", JS.ORDER_ATOMIC];
  };
  JS.forBlock['val_selected_index'] = function (b) {
    return ["RT.selectedIndex(" + q(b.getFieldValue('COMP')) + ")", JS.ORDER_ATOMIC];
  };
  JS.forBlock['val_random_frac'] = function () {
    return ['Math.random()', JS.ORDER_FUNCTION_CALL || JS.ORDER_ATOMIC];
  };
  JS.forBlock['val_random_int'] = function (b) {
    var lo = JS.valueToCode(b, 'MIN', JS.ORDER_ATOMIC) || '1';
    var hi = JS.valueToCode(b, 'MAX', JS.ORDER_ATOMIC) || '100';
    return ['(Math.floor(Math.random()*(' + hi + '-(' + lo + ')+1))+(' + lo + '))', JS.ORDER_ATOMIC];
  };

  /* ---------------- 新控件：开关 / 复选框 / 滑块 / 进度条 ---------------- */
  // 设置 开关/复选框 状态（真=开/勾选）
  B.Blocks['act_set_checked'] = {
    init: function () {
      this.appendValueInput('VALUE').setCheck('Boolean')
        .appendField('设置').appendField(compField(['switch', 'checkbox']), 'COMP').appendField('状态为');
      this.setInputsInline(true);
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_ACT);
      this.setTooltip('设置开关或复选框的状态，接“真/假”或逻辑判断积木');
    }
  };
  JS.forBlock['act_set_checked'] = function (b) {
    var v = JS.valueToCode(b, 'VALUE', JS.ORDER_ATOMIC) || 'false';
    return "RT.setChecked(" + q(b.getFieldValue('COMP')) + ", " + v + ");\n";
  };
  // 读取 开关/复选框 状态
  B.Blocks['val_get_checked'] = {
    init: function () {
      this.appendDummyInput().appendField(compField(['switch', 'checkbox']), 'COMP').appendField('的状态');
      this.setOutput(true, 'Boolean'); this.setColour(C_VAL);
      this.setTooltip('返回开关/复选框是否为开（真）或关（假）');
    }
  };
  JS.forBlock['val_get_checked'] = function (b) {
    return ["RT.getChecked(" + q(b.getFieldValue('COMP')) + ")", JS.ORDER_ATOMIC];
  };
  // 设置滑块数值
  B.Blocks['act_set_slider'] = {
    init: function () {
      this.appendValueInput('VALUE').setCheck('Number')
        .appendField('设置滑块').appendField(compField(['slider']), 'COMP').appendField('数值为');
      this.setInputsInline(true);
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_ACT);
    }
  };
  JS.forBlock['act_set_slider'] = function (b) {
    var v = JS.valueToCode(b, 'VALUE', JS.ORDER_ATOMIC) || '0';
    return "RT.setSlider(" + q(b.getFieldValue('COMP')) + ", " + v + ");\n";
  };
  B.Blocks['val_get_slider'] = {
    init: function () {
      this.appendDummyInput().appendField('滑块').appendField(compField(['slider']), 'COMP').appendField('的数值');
      this.setOutput(true, 'Number'); this.setColour(C_VAL);
    }
  };
  JS.forBlock['val_get_slider'] = function (b) {
    return ["RT.getSlider(" + q(b.getFieldValue('COMP')) + ")", JS.ORDER_ATOMIC];
  };
  // 滑块数值变化事件（帽子块）
  B.Blocks['ev_slider_change'] = {
    init: function () {
      this.appendDummyInput()
        .appendField('当滑块').appendField(compField(['slider']), 'COMP').appendField('数值变化时');
      this.appendStatementInput('DO');
      this.setColour(C_EVENT); this.hat = 'cap';
      this.setTooltip('拖动滑块改变数值时执行；这是程序入口，上面不能接积木。开口内可用“滑块的数值”积木拿到最新数值');
    }
  };
  JS.forBlock['ev_slider_change'] = function (b) {
    var body = JS.statementToCode(b, 'DO');
    return "RT.onChange(" + q(b.getFieldValue('COMP')) + ", async function(__value){\n" + body + "});\n";
  };
  // 设置 / 读取 进度条
  B.Blocks['act_set_progress'] = {
    init: function () {
      this.appendValueInput('VALUE').setCheck('Number')
        .appendField('设置进度条').appendField(compField(['progress']), 'COMP').appendField('进度为');
      this.setInputsInline(true);
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_ACT);
    }
  };
  JS.forBlock['act_set_progress'] = function (b) {
    var v = JS.valueToCode(b, 'VALUE', JS.ORDER_ATOMIC) || '0';
    return "RT.setProgress(" + q(b.getFieldValue('COMP')) + ", " + v + ");\n";
  };
  B.Blocks['val_get_progress'] = {
    init: function () {
      this.appendDummyInput().appendField('进度条').appendField(compField(['progress']), 'COMP').appendField('的进度');
      this.setOutput(true, 'Number'); this.setColour(C_VAL);
    }
  };
  JS.forBlock['val_get_progress'] = function (b) {
    return ["RT.getProgress(" + q(b.getFieldValue('COMP')) + ")", JS.ORDER_ATOMIC];
  };

  // 动作：设置输入框提示词（placeholder）
  B.Blocks['act_set_hint'] = {
    init: function () {
      this.appendValueInput('VALUE')
        .appendField('设置输入框').appendField(compField(['input']), 'COMP').appendField('提示词为');
      this.setInputsInline(true);
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_ACT);
      this.setTooltip('修改输入框里灰色的提示文字（未输入内容时显示）');
    }
  };
  JS.forBlock['act_set_hint'] = function (b) {
    var v = JS.valueToCode(b, 'VALUE', JS.ORDER_ATOMIC) || "''";
    return "RT.setHint(" + q(b.getFieldValue('COMP')) + ", " + v + ");\n";
  };

  /* ---------------- 云列表（SeaTable 等云端表格） ----------------
     云表格在编辑器里通过“创建 SeaTable 云列表”弹窗登记（project.clouds），
     每块云积木都带一个云表格下拉（像变量一样选择），一个作品可接入多个云表格。 */
  var C_CLOUD = '#0284C7';
  function txtVal(b, name, def) {
    return JS.valueToCode(b, name, JS.ORDER_ATOMIC) || q(def);
  }
  // 编辑器侧返回当前工程登记的云表格列表 [{id,name,provider,server,uuid,token}]
  function projectClouds() {
    var list = (window.BB_getProjectClouds && window.BB_getProjectClouds()) || [];
    return Array.isArray(list) ? list : [];
  }
  // 云表格下拉：选项来自当前工程；未创建时给占位项
  function cloudDropdown() {
    var f = new B.FieldDropdown(function () {
      var cs = projectClouds().map(function (c) { return [c.name || '云表格', c.id]; });
      if (!cs.length) cs.push(['（未创建云表格）', '']);
      return cs;
    });
    return f;
  }
  // 代码生成时取当前积木选中的云表格 id（未选则回退第一个）
  function cloudIdCode(b) {
    var id = b.getFieldValue('CLOUD');
    if (id) return q(id);
    var cs = projectClouds();
    return cs[0] ? q(cs[0].id) : q('');
  }
  // 把“字段堆叠”里的 cloud_field 积木收集成一个对象（IIFE 内构造，避免同名冲突）
  function fieldObjectCode(b, inputName) {
    var inner = JS.statementToCode(b, inputName) || '';
    return '(await (async function (){ var __r = {};\n' + inner + 'return __r; })())';
  }

  /* ===== 旧版（v1.9.6）云列表积木：保留定义以兼容老工程，新积木从浮层移除 ===== */
  B.Blocks['cloud_setup'] = {
    init: function () {
      this.appendDummyInput()
        .appendField('☁ 设置云列表 品牌')
        .appendField(new B.FieldDropdown([
          ['SeaTable 中国云', 'seatable-cn'],
          ['SeaTable 国际云', 'seatable-io'],
          ['SeaTable 自定义服务器', 'seatable-custom']
        ]), 'PROVIDER');
      this.appendValueInput('SERVER').appendField('服务器地址（自定义时填写）');
      this.appendValueInput('UUID').appendField('表格 UUID');
      this.appendValueInput('TOKEN').appendField('API 密钥');
      this.setInputsInline(false);
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_CLOUD);
    }
  };
  JS.forBlock['cloud_setup'] = function (b) {
    var prov = q(b.getFieldValue('PROVIDER'));
    var server = JS.valueToCode(b, 'SERVER', JS.ORDER_ATOMIC) || "''";
    var uuid = JS.valueToCode(b, 'UUID', JS.ORDER_ATOMIC) || "''";
    var token = JS.valueToCode(b, 'TOKEN', JS.ORDER_ATOMIC) || "''";
    return 'await RT.cloudSetup(' + prov + ', ' + server + ', ' + uuid + ', ' + token + ');\n';
  };

  /* ===== 新版云表格积木（每块带云表格下拉） ===== */
  // （云表格▾）所有表格名称
  B.Blocks['cloud_tables'] = {
    init: function () {
      this.appendDummyInput().appendField(cloudDropdown(), 'CLOUD').appendField('所有表格名称');
      this.setOutput(true, null); this.setColour(C_CLOUD);
      this.setTooltip('返回所选云表格库里所有表格的名称（列表）');
    }
  };
  JS.forBlock['cloud_tables'] = function (b) {
    return ['await RT.cloudTables(' + cloudIdCode(b) + ')', JS.ORDER_ATOMIC];
  };
  // （云表格▾）查询表（）的所有行
  B.Blocks['cloud_rows'] = {
    init: function () {
      this.appendValueInput('TABLE').appendField(cloudDropdown(), 'CLOUD').appendField('查询表');
      this.appendDummyInput().appendField('的所有行');
      this.setInputsInline(true);
      this.setOutput(true, null); this.setColour(C_CLOUD);
      this.setTooltip('返回指定数据表的全部行，每行是一个对象，用“取字段”积木读取列值');
    }
  };
  JS.forBlock['cloud_rows'] = function (b) {
    var t = JS.valueToCode(b, 'TABLE', JS.ORDER_ATOMIC) || q('表名');
    return ['await RT.cloudRows(' + cloudIdCode(b) + ', ' + t + ')', JS.ORDER_ATOMIC];
  };
  // （云表格▾）SQL 查询（）
  B.Blocks['cloud_sql'] = {
    init: function () {
      this.appendValueInput('SQL').appendField(cloudDropdown(), 'CLOUD').appendField('SQL 查询');
      this.setInputsInline(true);
      this.setOutput(true, null); this.setColour(C_CLOUD);
      this.setTooltip('用 SQL 查询，例如 SELECT * FROM `表名`，返回符合条件的行列表');
    }
  };
  JS.forBlock['cloud_sql'] = function (b) {
    var s = JS.valueToCode(b, 'SQL', JS.ORDER_ATOMIC) || q('SELECT * FROM `表名`');
    return ['await RT.cloudSql(' + cloudIdCode(b) + ', ' + s + ')', JS.ORDER_ATOMIC];
  };
  // （云表格▾）表（）的行数
  B.Blocks['cloud_count'] = {
    init: function () {
      this.appendValueInput('TABLE').appendField(cloudDropdown(), 'CLOUD').appendField('表');
      this.appendDummyInput().appendField('的行数');
      this.setInputsInline(true);
      this.setOutput(true, null); this.setColour(C_CLOUD);
      this.setTooltip('返回指定数据表当前的总行数（数字）');
    }
  };
  JS.forBlock['cloud_count'] = function (b) {
    var t = JS.valueToCode(b, 'TABLE', JS.ORDER_ATOMIC) || q('表名');
    return ['await RT.cloudRowCount(' + cloudIdCode(b) + ', ' + t + ')', JS.ORDER_ATOMIC];
  };
  // （云表格▾）从表（）取行 Id 为（）的一行
  B.Blocks['cloud_row_by_id'] = {
    init: function () {
      this.appendValueInput('TABLE').appendField(cloudDropdown(), 'CLOUD').appendField('从表');
      this.appendValueInput('ROWID').appendField('取行 Id 为');
      this.appendDummyInput().appendField('的一行');
      this.setInputsInline(true);
      this.setOutput(true, null); this.setColour(C_CLOUD);
      this.setTooltip('按行 Id（_id）取某一行；新增行成功后可拿到新行的 Id');
    }
  };
  JS.forBlock['cloud_row_by_id'] = function (b) {
    var t = JS.valueToCode(b, 'TABLE', JS.ORDER_ATOMIC) || q('表名');
    var id = JS.valueToCode(b, 'ROWID', JS.ORDER_ATOMIC) || q('');
    return ['await RT.cloudRowById(' + cloudIdCode(b) + ', ' + t + ', ' + id + ')', JS.ORDER_ATOMIC];
  };
  // 字段（列名 = 值）：堆叠在“新增一行 / 更新一行”内部，替代手写 JSON
  B.Blocks['cloud_field'] = {
    init: function () {
      this.appendValueInput('KEY').appendField('列名');
      this.appendValueInput('VAL').appendField('=');
      this.setInputsInline(true);
      this.setPreviousStatement(true, null); this.setNextStatement(true, null);
      this.setColour(C_CLOUD);
      this.setTooltip('一个字段：左边填列名（文本），右边填值；叠放在“新增一行/更新一行”里');
    }
  };
  JS.forBlock['cloud_field'] = function (b) {
    var k = JS.valueToCode(b, 'KEY', JS.ORDER_ATOMIC) || q('列名');
    var v = JS.valueToCode(b, 'VAL', JS.ORDER_ATOMIC) || "''";
    return '__r[' + k + '] = ' + v + ';\n';
  };
  // （云表格▾）向表（）新增一行（字段堆叠）
  B.Blocks['cloud_add'] = {
    init: function () {
      this.appendValueInput('TABLE').appendField(cloudDropdown(), 'CLOUD').appendField('向表');
      this.appendDummyInput().appendField('新增一行：');
      this.appendStatementInput('FIELDS').setCheck(null);
      this.setInputsInline(true);
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_CLOUD);
      this.setTooltip('向数据表追加一行；把“字段”积木叠在里面，每个字段一对列名和值，不用手写 JSON');
    }
  };
  JS.forBlock['cloud_add'] = function (b) {
    var t = JS.valueToCode(b, 'TABLE', JS.ORDER_ATOMIC) || q('表名');
    return 'await RT.cloudAddRow(' + cloudIdCode(b) + ', ' + t + ', ' + fieldObjectCode(b, 'FIELDS') + ');\n';
  };
  // （云表格▾）更新表（）中行 Id 为（）的一行
  B.Blocks['cloud_update'] = {
    init: function () {
      this.appendValueInput('TABLE').appendField(cloudDropdown(), 'CLOUD').appendField('更新表');
      this.appendValueInput('ROWID').appendField('中行 Id 为');
      this.appendDummyInput().appendField('的一行，改为：');
      this.appendStatementInput('FIELDS').setCheck(null);
      this.setInputsInline(true);
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_CLOUD);
      this.setTooltip('按行 Id 更新一行；叠放“字段”积木指定要修改的列和新值');
    }
  };
  JS.forBlock['cloud_update'] = function (b) {
    var t = JS.valueToCode(b, 'TABLE', JS.ORDER_ATOMIC) || q('表名');
    var id = JS.valueToCode(b, 'ROWID', JS.ORDER_ATOMIC) || q('');
    return 'await RT.cloudUpdateRow(' + cloudIdCode(b) + ', ' + t + ', ' + id + ', ' + fieldObjectCode(b, 'FIELDS') + ');\n';
  };
  // （云表格▾）删除表（）中行 Id 为（）的行
  B.Blocks['cloud_delete'] = {
    init: function () {
      this.appendValueInput('TABLE').appendField(cloudDropdown(), 'CLOUD').appendField('删除表');
      this.appendValueInput('ROWID').appendField('中行 Id 为');
      this.appendDummyInput().appendField('的行');
      this.setInputsInline(true);
      this.setPreviousStatement(true); this.setNextStatement(true); this.setColour(C_CLOUD);
      this.setTooltip('按行 Id 删除一行（不可恢复，建议先查询确认）');
    }
  };
  JS.forBlock['cloud_delete'] = function (b) {
    var t = JS.valueToCode(b, 'TABLE', JS.ORDER_ATOMIC) || q('表名');
    var id = JS.valueToCode(b, 'ROWID', JS.ORDER_ATOMIC) || q('');
    return 'await RT.cloudDeleteRow(' + cloudIdCode(b) + ', ' + t + ', ' + id + ');\n';
  };
  // 取（对象）的字段（）——读取云表格行里某一列
  B.Blocks['val_json_get'] = {
    init: function () {
      this.appendValueInput('OBJ').appendField('取');
      this.appendValueInput('KEY').appendField('的字段');
      this.setInputsInline(true);
      this.setOutput(true, null); this.setColour(C_CLOUD);
      this.setTooltip('从云表格返回的一行数据里取某一列的值，字段名填列名，如“名称”；取行 Id 用“_id”');
    }
  };
  JS.forBlock['val_json_get'] = function (b) {
    var o = JS.valueToCode(b, 'OBJ', JS.ORDER_ATOMIC) || 'null';
    var k = JS.valueToCode(b, 'KEY', JS.ORDER_ATOMIC) || q('');
    return ['RT.jsonGet(' + o + ', ' + k + ')', JS.ORDER_ATOMIC];
  };

  /* ===== 云列表分类浮层：顶部两个按钮（创建/管理），未创建时只显示提示 ===== */
  window.BB_cloudFlyout = function () {
    var items = [
      { kind: 'button', text: '＋ 创建 SeaTable 云列表', callbackKey: 'BB_CLOUD_CREATE' },
      { kind: 'button', text: '⚙ 管理 SeaTable 云列表', callbackKey: 'BB_CLOUD_MANAGE' }
    ];
    var cs = projectClouds();
    if (!cs.length) {
      items.push({ kind: 'label', text: '还没有云表格，点上方按钮创建' });
      return items;
    }
    function blk(blockType, extras) {
      return { kind: 'block', blockxml: '<block type="' + blockType + '"><field name="CLOUD">' + cs[0].id + '</field>' + (extras || '') + '</block>' };
    }
    items.push(blk('cloud_tables'));
    items.push(blk('cloud_rows', txtSh('TABLE', '表名')));
    items.push(blk('cloud_sql', txtSh('SQL', 'SELECT * FROM `表名`')));
    items.push(blk('cloud_count', txtSh('TABLE', '表名')));
    items.push(blk('cloud_row_by_id', txtSh('TABLE', '表名') + txtSh('ROWID', '行 Id')));
    items.push(blk('cloud_add', txtSh('TABLE', '表名')
      + '<statement name="FIELDS"><block type="cloud_field">' + txtSh('KEY', '列名') + txtSh('VAL', '值') + '</block></statement>'));
    items.push(blk('cloud_update', txtSh('TABLE', '表名') + txtSh('ROWID', '行 Id')
      + '<statement name="FIELDS"><block type="cloud_field">' + txtSh('KEY', '列名') + txtSh('VAL', '新值') + '</block></statement>'));
    items.push(blk('cloud_delete', txtSh('TABLE', '表名') + txtSh('ROWID', '行 Id')));
    items.push({ kind: 'block', blockxml: '<block type="cloud_field">' + txtSh('KEY', '列名') + txtSh('VAL', '值') + '</block>' });
    items.push({ kind: 'block', blockxml: '<block type="val_json_get">' + txtSh('OBJ', '一行数据') + txtSh('KEY', '列名') + '</block>' });
    return items;
  };

  /* ---------------- 按控件类型生成“专属分类”的变体积木 ----------------
     同一动作（设置文本/显示/隐藏/透明度/颜色/点击…）针对不同控件类型各生成一个块，
     组件下拉只列出该类型的控件，方便快速找到。旧的通用块仍保留定义以兼容老工程。 */
  var CONTROL_GROUPS = [
    { key: 'button',   label: '按钮',   types: ['button'],   colour: '#1565C0', shapes: ['click', 'settext', 'setbg', 'setfg', 'show', 'hide', 'opacity'] },
    { key: 'text',     label: '文字',   types: ['text'],     colour: '#0277BD', shapes: ['click', 'settext', 'setfg', 'show', 'hide', 'opacity'] },
    { key: 'input',    label: '输入框', types: ['input'],    colour: '#00838F', shapes: ['settext', 'gettext', 'sethint', 'setbg', 'setfg', 'show', 'hide', 'opacity'] },
    { key: 'list',     label: '列表',   types: ['list'],     colour: '#6A1B9A', shapes: ['setbg', 'show', 'hide', 'opacity'] },
    { key: 'image',    label: '图片',   types: ['image'],    colour: '#2E7D32', shapes: ['click', 'setbg', 'show', 'hide', 'opacity'] },
    { key: 'switch',   label: '开关',   types: ['switch'],   colour: '#EF6C00', shapes: ['click', 'show', 'hide', 'opacity'] },
    { key: 'checkbox', label: '复选框', types: ['checkbox'], colour: '#AD1457', shapes: ['click', 'settext', 'setfg', 'show', 'hide', 'opacity'] },
    { key: 'slider',   label: '滑块',   types: ['slider'],   colour: '#4527A0', shapes: ['show', 'hide', 'opacity'] },
    { key: 'progress', label: '进度条', types: ['progress'], colour: '#00695C', shapes: ['show', 'hide', 'opacity'] },
    { key: 'video',    label: '视频播放器', types: ['video'], colour: '#5D4037', shapes: ['show', 'hide', 'opacity'] },
    { key: 'audio',    label: '音频播放', types: ['audio'], colour: '#37474F', shapes: ['show', 'hide', 'opacity'] },
    { key: 'web',      label: '网页', types: ['web'], colour: '#1B5E20', shapes: ['show', 'hide', 'opacity'] }
  ];
  function prevNext(b) { b.setPreviousStatement(true); b.setNextStatement(true); }
  var SHAPE_BUILD = {
    click: function (types) {
      this.appendDummyInput().appendField('当').appendField(compField(types), 'COMP').appendField('被点击');
      this.appendStatementInput('DO'); this.hat = 'cap';
      this.setTooltip('点击该' + this._grpLabel + '时执行；程序入口，上面不能接积木');
    },
    settext: function (types) {
      this.appendValueInput('VALUE').appendField('设置').appendField(compField(types), 'COMP').appendField('文本为');
      this.setInputsInline(true); prevNext(this);
    },
    gettext: function (types) {
      this.appendDummyInput().appendField(compField(types), 'COMP').appendField('的文本');
      this.setOutput(true, null);
    },
    sethint: function (types) {
      this.appendValueInput('VALUE').appendField('设置').appendField(compField(types), 'COMP').appendField('提示词为');
      this.setInputsInline(true); prevNext(this);
    },
    show: function (types) { this.appendDummyInput().appendField('显示').appendField(compField(types), 'COMP'); prevNext(this); },
    hide: function (types) { this.appendDummyInput().appendField('隐藏').appendField(compField(types), 'COMP'); prevNext(this); },
    opacity: function (types) {
      this.appendValueInput('V').appendField('设置').appendField(compField(types), 'COMP').appendField('透明度(0~100)为');
      this.setInputsInline(true); prevNext(this);
    },
    setbg: function (types) {
      this.appendValueInput('COLOR').appendField('设置').appendField(compField(types), 'COMP').appendField('背景色为');
      this.setInputsInline(true); prevNext(this);
    },
    setfg: function (types) {
      this.appendValueInput('COLOR').appendField('设置').appendField(compField(types), 'COMP').appendField('文字颜色为');
      this.setInputsInline(true); prevNext(this);
    }
  };
  var SHAPE_GEN = {
    click: JS.forBlock['ev_click'], settext: JS.forBlock['act_set_text'], gettext: JS.forBlock['val_get_text'],
    sethint: JS.forBlock['act_set_hint'],
    show: JS.forBlock['act_show'], hide: JS.forBlock['act_hide'], opacity: JS.forBlock['act_opacity'],
    setbg: JS.forBlock['act_set_bg'], setfg: JS.forBlock['act_set_color']
  };
  function vtype(key, shape) { return 'v_' + key + '_' + shape; }
  CONTROL_GROUPS.forEach(function (g) {
    g.shapes.forEach(function (shape) {
      var type = vtype(g.key, shape);
      B.Blocks[type] = {
        init: function () { this._grpLabel = g.label; SHAPE_BUILD[shape].call(this, g.types); this.setColour(g.colour); }
      };
      JS.forBlock[type] = SHAPE_GEN[shape];
    });
  });

  /* ---------------- 事件驱动代码生成 ----------------
     规则：只有顶部的“事件帽子块”(ev_*) 是程序入口；只有挂在事件 DO 里的积木会执行。
     单独散落在画布上、没有接到任何事件的积木一律不生成代码（不会运行）。 */
  function isEventHat(b) {
    var t = b && typeof b.type === 'string' ? b.type : '';
    // 事件帽子：内置 ev_* 入口，以及按控件生成的“当…被点击”变体积木 v_<控件>_click
    return t.indexOf('ev_') === 0 || /^v_[a-z]+_click$/.test(t);
  }

  window.generateEventCode = function (ws) {
    JS.init(ws);
    var out = [];
    var tops = ws.getTopBlocks(true); // 有序的顶层积木
    for (var i = 0; i < tops.length; i++) {
      var b = tops[i];
      if (!isEventHat(b)) continue;          // 非事件入口：跳过，散落积木不执行
      var code = JS.blockToCode(b);
      if (Array.isArray(code)) code = code[0];
      if (code) out.push(code);
    }
    var res = out.join('\n');
    res = JS.finish(res);
    res = res.replace(/^\s+\n/, '').replace(/\n\s+$/, '\n').replace(/[ \t]+\n/g, '\n');
    // 注册本工程登记的全部云表格（同步写入运行时连接池，密钥随工程导出）
    var prefix = projectClouds().map(function (c) {
      var cfg = { name: c.name, provider: c.provider, server: c.server, uuid: c.uuid, token: c.token };
      return 'RT.cloudRegister(' + q(c.id) + ', ' + JSON.stringify(cfg) + ');';
    }).join('\n');
    return prefix ? (prefix + '\n' + res) : res;
  };

  /* ---------------- 工具箱（按控件类型分“专属分类”，便于快速找到对应积木） ---------------- */
  function plain(t) { return '<block type="' + t + '"/>'; }
  function numSh(input, val) { return '<value name="' + input + '"><shadow type="math_number"><field name="NUM">' + val + '</field></shadow></value>'; }
  function txtSh(input, val) { return '<value name="' + input + '"><shadow type="text"><field name="TEXT">' + val + '</field></shadow></value>'; }
  function colSh(input, hex) { return '<value name="' + input + '"><shadow type="colour_picker"><field name="COLOUR">' + hex + '</field></shadow></value>'; }
  function boolSh(input, bool) { return '<value name="' + input + '"><shadow type="logic_boolean"><field name="BOOL">' + bool + '</field></shadow></value>'; }
  function vfrag(key, shape) {
    var t = vtype(key, shape);
    if (shape === 'settext') return '<block type="' + t + '">' + txtSh('VALUE', '文本') + '</block>';
    if (shape === 'sethint') return '<block type="' + t + '">' + txtSh('VALUE', '请输入') + '</block>';
    if (shape === 'setbg') return '<block type="' + t + '">' + colSh('COLOR', '#6750A4') + '</block>';
    if (shape === 'setfg') return '<block type="' + t + '">' + colSh('COLOR', '#000000') + '</block>';
    if (shape === 'opacity') return '<block type="' + t + '">' + numSh('V', '100') + '</block>';
    return plain(t);
  }
  var GROUP_EXTRA = {
    list: {
      head: [plain('ev_itemclick')],
      tail: ['<block type="act_list_add">' + txtSh('VALUE', '新项') + '</block>', plain('act_list_set'),
        plain('act_list_clear'), plain('val_selected_item'), plain('val_selected_index')]
    },
    switch: { head: [], tail: ['<block type="act_set_checked">' + boolSh('VALUE', 'TRUE') + '</block>', plain('val_get_checked')] },
    checkbox: { head: [], tail: ['<block type="act_set_checked">' + boolSh('VALUE', 'TRUE') + '</block>', plain('val_get_checked')] },
    slider: { head: [plain('ev_slider_change')], tail: ['<block type="act_set_slider">' + numSh('VALUE', '50') + '</block>', plain('val_get_slider')] },
    progress: { head: [], tail: ['<block type="act_set_progress">' + numSh('VALUE', '50') + '</block>', plain('val_get_progress')] },
    video: { head: [], tail: [plain('act_video_play'), plain('act_video_pause'), plain('act_video_seek'), '<block type="act_video_src">' + txtSh('URL', 'https://视频地址.mp4') + '</block>'] },
    audio: { head: [], tail: [plain('act_audio_play'), plain('act_audio_pause'), plain('act_audio_seek'), '<block type="act_audio_src">' + txtSh('URL', 'https://音频地址.mp3') + '</block>'] },
    web: { head: [], tail: ['<block type="act_web_url">' + txtSh('URL', 'https://example.com') + '</block>'] }
  };
  function groupCategory(g) {
    var xml = '<category name="' + g.label + '" colour="' + g.colour + '">';
    var ex = GROUP_EXTRA[g.key] || { head: [], tail: [] };
    ex.head.forEach(function (f) { xml += f; });
    g.shapes.forEach(function (s) { xml += vfrag(g.key, s); });
    ex.tail.forEach(function (f) { xml += f; });
    return xml + '</category>';
  }

  // usedTypes：工程里实际出现的控件类型 Set；只显示对应分类，避免积木栏臃肿。
  // usedTypes 为 null 时全部显示（兜底/空工程首次打开）。
  function buildToolboxXml(usedTypes) {
    var x = '<xml xmlns="https://developers.google.com/blockly/xml">';
    x += '<category name="事件" colour="#FB8C00"><block type="ev_start"/><block type="ev_first_start"/></category>';
    CONTROL_GROUPS.forEach(function (g) {
      if (usedTypes && usedTypes.size && !g.types.some(function (t) { return usedTypes.has(t); })) return;
      x += groupCategory(g);
    });
    x += '<category name="页面" colour="#0B57D0">'
      + '<block type="act_toast">' + txtSh('MSG', '提示内容') + '</block>'
      + plain('act_goto') + plain('act_back') + '</category>';
    x += '<category name="设备" colour="#546E7A">'
      + '<block type="act_vibrate">' + numSh('MS', '30') + '</block>' + plain('act_exit') + '</category>';
    x += '<category name="控制" colour="#607D8B">'
      + plain('controls_if')
      + '<block type="controls_repeat_ext">' + numSh('TIMES', '10') + '</block>'
      + plain('controls_whileUntil')
      + '<block type="controls_for"><field name="VAR">i</field>'
      + numSh('FROM', '1') + numSh('TO', '10') + numSh('BY', '1') + '</block>'
      + '<block type="controls_flow_statements"><field name="FLOW">BREAK</field></block>'
      + '<block type="act_wait">' + numSh('SECS', '1') + '</block></category>';
    x += '<category name="逻辑" colour="#4CAF50">'
      + plain('logic_compare') + plain('logic_operation') + plain('logic_negate') + plain('logic_boolean') + '</category>';
    x += '<category name="数学" colour="#3F51B5">'
      + '<block type="math_number"><field name="NUM">0</field></block>'
      + plain('math_arithmetic') + plain('math_single') + plain('val_random_frac')
      + '<block type="val_random_int">' + numSh('MIN', '1') + numSh('MAX', '100') + '</block></category>';
    x += '<category name="文本" colour="#795548">'
      + '<block type="text"><field name="TEXT">文本</field></block>' + plain('text_join') + plain('text_length') + '</category>';
    x += '<category name="数据列表" colour="#9C27B0">' + plain('lists_create_with') + plain('lists_length') + '</category>';
    x += '<category name="云列表" colour="' + C_CLOUD + '" custom="BB_CLOUD"></category>';
    x += '<category name="颜色" colour="#00ACC1">'
      + '<block type="colour_picker"><field name="COLOUR">#6750A4</field></block>' + plain('colour_rgb') + '</category>';
    x += '<category name="变量" colour="#EF6C00" custom="VARIABLE"></category>';
    x += '</xml>';
    return x;
  }
  window.TOOLBOX_XML = buildToolboxXml(null);   // 兜底；真正打开积木页时按工程实际控件重新生成
  window.buildToolboxXml = buildToolboxXml;

  /* ---------------- 供编辑器构建 M3 分类轨道：分组顺序 + 图标 ---------------- */
  window.BB_GROUPS = {
    widget: CONTROL_GROUPS.map(function (g) { return g.label; }),
    general: ['事件', '页面', '设备', '控制', '逻辑', '数学', '文本', '数据列表', '云列表', '颜色', '变量']
  };
  window.BB_CAT_ICON = {
    '按钮': 'Btn', '文字': 'Aa', '输入框': 'In', '列表': 'List', '图片': 'Img',
    '开关': 'Sw', '复选框': '✓', '滑块': 'Sl', '进度条': 'Pr',
    '视频播放器': '▶', '音频播放': '♪', '网页': 'W',
    '事件': '▶', '页面': '⇄', '设备': 'Dev', '控制': 'Ctl', '逻辑': '&',
    '数学': '∑', '文本': 'T', '数据列表': '[ ]', '云列表': '☁', '颜色': '●', '变量': 'x'
  };

  /* ================= 使用帮助数据（帮助页右侧说明，顺序与工具箱完全一致） ================= */
  // 每个动作 shape 的通用说明；{c} 渲染时替换为控件分类名（按钮/文字/输入框…）
  var SHAPE_HELP = {
    click:   { sig: '当{c}被点击 / 执行…', desc: '事件帽子块（程序入口）。用户点击这个{c}时，依次执行叠在“执行”里的积木。', use: '从“执行”缺口里叠放动作积木，例如点击按钮后弹出提示、跳转页面。' },
    settext: { sig: '设置{c}文本为（文本）', desc: '修改这个{c}界面上显示的文字。', use: '在右侧缺口接入“文本”积木或变量，运行时即更新显示。' },
    gettext: { sig: '{c}的文本', desc: '取值积木（椭圆形），读取这个{c}当前显示/输入的文字。', use: '接到需要文本的缺口，例如“弹出提示（输入框的文本）”。' },
    sethint: { sig: '设置{c}提示词为（文本）', desc: '设置输入框为空时显示的浅色占位提示。', use: '接一段文本，如“请输入账号”，用于引导用户输入。' },
    setbg:   { sig: '设置{c}背景色为（颜色）', desc: '修改这个{c}的背景颜色。', use: '缺口接“颜色”分类里的颜色积木。' },
    setfg:   { sig: '设置{c}文字颜色为（颜色）', desc: '修改这个{c}上文字的颜色。', use: '缺口接颜色积木，可与背景色搭配。' },
    show:    { sig: '显示{c}', desc: '让此前隐藏的{c}重新出现。', use: '常与“隐藏”配合，做条件显示界面。' },
    hide:    { sig: '隐藏{c}', desc: '把{c}从界面上隐藏（不删除，可用“显示”恢复）。', use: '例如登录前隐藏某按钮。' },
    opacity: { sig: '设置{c}透明度(0~100)为（数值）', desc: '调整{c}的不透明度：100 完全不透明，0 全透明。', use: '缺口接数字积木或滑块数值。' }
  };
  // 个别控件分类的专属积木
  var WIDGET_EXTRA_HELP = {
    list: [
      { sig: '当列表某项被点击 / 执行…', desc: '事件帽子块。用户点中列表里某一行时触发。', use: '配合“列表选中项/选中序号”读取被点中的内容。' },
      { sig: '给列表添加（项）', desc: '在列表末尾追加一项。', use: '缺口接文本，例如添加一条新留言。' },
      { sig: '设置列表数据为（列表）', desc: '用一个数据列表整体替换列表显示内容。', use: '接“数据列表”分类创建的列表。' },
      { sig: '清空列表', desc: '删除列表里的所有行。', use: '重置列表时使用。' },
      { sig: '列表选中项', desc: '取值积木，返回当前选中那一行的内容。', use: '接到文本缺口读取选中内容。' },
      { sig: '列表选中序号', desc: '取值积木，返回选中行的序号（数字）。', use: '序号常用于定位、删除。' }
    ],
    switch: [
      { sig: '设置开关状态为（真/假）', desc: '打开（真）或关闭（假）开关。', use: '缺口接“逻辑”里的 真/假 积木。' },
      { sig: '开关的状态', desc: '取值积木，返回开关当前是开（真）还是关（假）。', use: '接到“如果”条件里判断开关。' }
    ],
    checkbox: [
      { sig: '设置复选框状态为（真/假）', desc: '勾选（真）或取消勾选（假）复选框。', use: '缺口接 真/假 积木。' },
      { sig: '复选框的状态', desc: '取值积木，返回复选框是否被勾选（真/假）。', use: '用于“如果”条件判断。' }
    ],
    slider: [
      { sig: '当滑块数值变化时 / 执行…', desc: '事件帽子块。拖动滑块使数值改变时触发。', use: '在“执行”里用“滑块的数值”实时刷新界面。' },
      { sig: '设置滑块数值为（数值）', desc: '把滑块定位到指定数值。', use: '缺口接数字。' },
      { sig: '滑块的数值', desc: '取值积木，返回滑块当前数值。', use: '可接到透明度、进度、文本等数字缺口。' }
    ],
    progress: [
      { sig: '设置进度条进度为（数值）', desc: '设置进度条当前进度值。', use: '例如加载到 60%。' },
      { sig: '进度条的进度', desc: '取值积木，返回进度条当前进度。', use: '读取进度做判断或显示。' }
    ],
    video: [
      { sig: '播放视频 ▾', desc: '让指定视频播放器开始播放。', use: '放在按钮点击或页面启动事件里触发播放。' },
      { sig: '暂停视频 ▾', desc: '暂停指定视频的播放。', use: '与“播放视频”配合做暂停/继续。' },
      { sig: '设置视频 ▾ 地址为（文本）', desc: '把视频播放器切换到指定的视频地址（mp4 等网络链接）。', use: '缺口接文本网址，可用于根据条件切换不同视频。' },
      { sig: '跳转视频到 ▾ 秒（数值）', desc: '把视频跳到指定秒数的位置。', use: '如填 10 表示跳到第 10 秒。' }
    ],
    audio: [
      { sig: '播放音频 ▾', desc: '让指定音频开始播放。', use: '可做背景音乐、提示音。' },
      { sig: '暂停音频 ▾', desc: '暂停指定音频。', use: '与“播放音频”配合。' },
      { sig: '设置音频 ▾ 地址为（文本）', desc: '把音频切换到指定的音频地址（mp3 等网络链接）。', use: '缺口接文本网址。' },
      { sig: '跳转音频到 ▾ 秒（数值）', desc: '把音频跳到指定秒数的位置。', use: '如填 5 表示跳到第 5 秒。' }
    ],
    web: [
      { sig: '设置网页 ▾ 网址为（文本）', desc: '让指定网页控件加载指定网址。', use: '缺口接文本网址，可在运行时切换内嵌网页内容。' }
    ]
  };
  function buildWidgetHelp() {
    return CONTROL_GROUPS.map(function (g) {
      var blocks = g.shapes.map(function (s) {
        var h = SHAPE_HELP[s]; if (!h) return null;
        return { sig: h.sig.replace(/\{c\}/g, g.label), desc: h.desc.replace(/\{c\}/g, g.label), use: h.use.replace(/\{c\}/g, g.label) };
      }).filter(Boolean);
      if (WIDGET_EXTRA_HELP[g.key]) blocks = blocks.concat(WIDGET_EXTRA_HELP[g.key]);
      return { cat: g.label, colour: g.colour, blocks: blocks };
    });
  }
  window.BB_HELP = {
    general: [
      { cat: '事件', colour: '#FB8C00', blocks: [
        { sig: '▶ 当页面启动时 / 执行…', desc: '最常用的事件帽子块（程序入口）。每次进入该页面时自动运行一次。', use: '把页面打开就要执行的积木（初始化文字、加载云数据等）叠进“执行”。注意：只有接在事件帽子块下面的积木才会运行。' },
        { sig: '▶ 当页面首次启动时 / 执行…', desc: '事件帽子块。本次打开 App 期间，该页面第一次被打开时只执行一次；之后反复跳回本页面不会再执行。', use: '适合一次性初始化（只在第一次进入时跳转、只加载一次数据）。把 App 从后台彻底划掉后重新打开，会再次执行。想每次进入都执行，请用“当页面启动时”。' }
      ]},
      { cat: '页面', colour: '#0B57D0', blocks: [
        { sig: '弹出提示（文本）', desc: '在屏幕底部短暂显示一条小提示（Toast）。', use: '缺口接文本，如“保存成功”。' },
        { sig: '跳转到页面 ▾', desc: '切换到本 App 的另一个页面。', use: '点下拉选择目标页面，常用于按钮点击后翻页。新拖出的积木会自动选一个不是当前页的页面，避免“跳到自己”点了没反应；页面被删除后，指向它的积木会自动改为第一个页面。' },
        { sig: '返回上一页', desc: '回到上一个页面（等同系统返回）。', use: '用于“返回”按钮。注意：写在“当页面启动时”里的自动跳转不会占用返回栈（例如启动页自动进入主页后，按返回不会又被弹回启动页）；只有按钮等手动跳转才会。想做“返回首页”按钮，用这块比“跳转到页面”更合适。' }
      ]},
      { cat: '设备', colour: '#546E7A', blocks: [
        { sig: '震动 毫秒（数值）', desc: '让手机震动指定毫秒数。', use: '缺口接数字，如 30 表示短震动。' },
        { sig: '退出应用', desc: '关闭并退出当前 App。', use: '一般放在“退出”按钮里。' }
      ]},
      { cat: '控制', colour: '#607D8B', blocks: [
        { sig: '如果（条件）那么…否则…', desc: '条件判断。条件成立执行“那么”，不成立执行“否则”。点齿轮可添加“否则如果/否则”。', use: '条件缺口接椭圆形逻辑积木，如“开关的状态 = 真”。' },
        { sig: '重复（次数）次', desc: '把里面的积木重复执行指定次数。', use: '次数接数字，内部放要循环的动作。' },
        { sig: '重复 当/直到（条件）', desc: '条件循环：满足条件时反复执行，或直到条件成立为止。', use: '注意“直到”型要确保条件最终会成立，否则会一直循环。' },
        { sig: '循环变量 i 从（数）到（数）步长（数）', desc: '计数循环，变量 i 依次取区间内的值。', use: '适合遍历固定次数，内部可用变量 i。' },
        { sig: '跳出循环', desc: '立即结束当前所在的循环。', use: '放在循环内部的“如果”里，满足条件时提前退出。' },
        { sig: '等待（秒）', desc: '暂停指定秒数后再继续执行后面的积木。', use: '接数字（可填小数，如 0.5），用于延时、动画间隔。' }
      ]},
      { cat: '逻辑', colour: '#4CAF50', blocks: [
        { sig: '（值）= / ≠ / < / >（值）', desc: '比较两个值，成立返回“真”，否则返回“假”。', use: '接到“如果”的条件缺口。' },
        { sig: '（条件）与 / 或（条件）', desc: '“与”要求两个条件都成立；“或”只要一个成立。', use: '组合多个判断条件。' },
        { sig: '不成立（条件）', desc: '逻辑取反：条件为假时返回真，为真时返回假。', use: '用于“如果不…”这类判断。' },
        { sig: '真 / 假', desc: '逻辑布尔值。', use: '接到需要真/假的缺口，如设置开关状态。' }
      ]},
      { cat: '数学', colour: '#3F51B5', blocks: [
        { sig: '数字 0', desc: '一个可编辑的数字积木。', use: '点数字即可修改，接到任何数字缺口。' },
        { sig: '（数）+ − × ÷（数）', desc: '四则运算，下拉可切换运算。', use: '两侧接数字积木。' },
        { sig: '平方根 / 绝对值 / 四舍五入…（数）', desc: '单值数学函数，下拉选择开方、绝对值、取整等。', use: '接一个数字，返回计算结果。' },
        { sig: '随机小数（0~1）', desc: '返回 0 到 1 之间的随机小数。', use: '用于概率、随机比例。' },
        { sig: '随机整数 从（数）到（数）', desc: '返回指定区间内的随机整数（含两端）。', use: '如从 1 到 6 模拟掷骰子。' }
      ]},
      { cat: '文本', colour: '#795548', blocks: [
        { sig: '“文本”', desc: '一段文字，点击即可编辑。', use: '接到任何需要文本的缺口；需要数字时不要用文本。' },
        { sig: '拼接（文本）（文本）…', desc: '把多段文本连成一段，点齿轮可增加项。', use: '如把“得分：”与分数变量拼成一句话。' },
        { sig: '文本长度（文本）', desc: '返回文字的字符个数。', use: '可校验输入框是否为空（长度为 0）。' }
      ]},
      { cat: '数据列表', colour: '#9C27B0', blocks: [
        { sig: '建立列表（项…）', desc: '创建一个列表，可放多个数据项，点齿轮增减项；留空即为空列表。', use: '整体接到“设置列表数据为”即可批量显示。' },
        { sig: '列表长度（列表）', desc: '返回列表里有多少项。', use: '接列表，返回数字。' }
      ]},
      { cat: '云列表', colour: '#1E88E5', intro: '云列表对接 SeaTable 在线表格，可在多台设备间读写同一份数据。先在本分类点“创建 SeaTable 云列表”，选择服务器并填写表格名称、UUID 和 API 密钥；每个云表格积木上的“☁ 云表格▾”可切换要操作的表格。', blocks: [
        { sig: '＋ 创建 SeaTable 云列表（按钮）', desc: '打开创建弹窗，登记一个云表格连接（名称/服务器/UUID/API 密钥）。', use: '创建后本分类才会出现下面的云表格积木。' },
        { sig: '⚙ 管理 SeaTable 云列表（按钮）', desc: '查看、编辑或删除已登记的云表格连接。', use: '换密钥或不用了可在此管理。' },
        { sig: '（云表格▾）所有表格名称', desc: '取值，返回该云表格里所有数据表的名称列表。', use: '用于先确认要操作的表名。' },
        { sig: '（云表格▾）查询表（表名）的所有行', desc: '取值（异步），返回指定数据表的全部行。', use: '常配合循环与“取字段”逐行读取。' },
        { sig: '（云表格▾）SQL 查询（语句）', desc: '取值，用 SQL 语句灵活查询，如 SELECT * FROM `表名`。', use: '表名两侧用反引号 `，适合筛选/排序。' },
        { sig: '（云表格▾）表（表名）的行数', desc: '取值，返回该表的数据行数。', use: '用于统计记录总数。' },
        { sig: '（云表格▾）从表（表名）取行 Id 为（Id）的一行', desc: '取值，按行唯一 Id 取一整行。', use: '行 Id 用“取字段（行, _id）”获得。' },
        { sig: '（云表格▾）向表（表名）新增一行 / 字段…', desc: '动作。在“字段：”里叠放“字段 列名 = 值”积木，每块对应一列。', use: '无需手写 JSON，列名接文本、值接对应数据即可。' },
        { sig: '（云表格▾）更新表（表名）中行 Id 为（Id）的一行 / 改为…', desc: '动作。按行 Id 修改指定列，内部叠放“字段”积木。', use: '只改叠放了的列，其它列保持不变。' },
        { sig: '（云表格▾）删除表（表名）中行 Id 为（Id）的行', desc: '动作，按行 Id 删除一行，不可恢复。', use: '建议先查询确认 Id 再删除。' },
        { sig: '字段 列名（文本）= 值（任意）', desc: '一个字段对，只能叠在“新增一行/更新一行”的缺口里。', use: '左边填列名文本，右边填要写入的值。' },
        { sig: '取（一行）的字段（列名）', desc: '取值，从查询返回的一行里读取某一列；取行 Id 列名用 _id。', use: '如“取（某行）的字段（名称）”。' }
      ]},
      { cat: '颜色', colour: '#00ACC1', blocks: [
        { sig: '颜色选择器', desc: '一个颜色积木，点击可挑选颜色。', use: '接到背景色/文字颜色缺口。' },
        { sig: '红（数）绿（数）蓝（数）合成颜色', desc: '用 0~255 的三原色数值拼出颜色。', use: '可接滑块/数字做动态变色。' }
      ]},
      { cat: '变量', colour: '#EF6C00', intro: '变量用来保存会变化的数据（分数、名称、状态等）。先在分类里“新建变量”命名，再使用下列积木。', blocks: [
        { sig: '将（变量）设为（值）', desc: '把变量赋值，旧值被覆盖。', use: '初始化或重置变量时使用。' },
        { sig: '改变（变量）by（数值）', desc: '让数字变量增加（或负数减少）一个量。', use: '如“改变 分数 by 1”做加分。' },
        { sig: '（变量）的值', desc: '取值积木，读取变量当前内容。', use: '接到文本/数字/条件缺口参与运算或显示。' }
      ]}
    ],
    widget: buildWidgetHelp()
  };
})();
