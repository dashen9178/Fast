/* FAST 编辑器 v1.5 */
(function () {
  'use strict';
  var B = window.Blockly;
  var $ = function (id) { return document.getElementById(id); };
  function el(t, cls, txt) { var e = document.createElement(t); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }

  var ICON_EYE_ON = '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17a5 5 0 1 1 0-10 5 5 0 0 1 0 10zm0-8a3 3 0 1 0 0 6 3 3 0 0 0 0-6z"/></svg>';
  var ICON_EYE_OFF = '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46A11.804 11.804 0 0 0 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2zm4.31-.78l3.15 3.15.02-.16c0-1.66-1.34-3-3-3l-.17.01z"/></svg>';

  var TYPE_META = {
    text:     { label: '文字',   ico: 'Aa',   desc: '显示一段文字' },
    button:   { label: '按钮',   ico: 'Btn',  desc: '可点击的按钮' },
    input:    { label: '输入框', ico: 'In',   desc: '让用户输入文字' },
    list:     { label: '列表',   ico: 'List', desc: '可滚动、可点选的列表' },
    image:    { label: '图片',   ico: 'Img',  desc: '图片' },
    switch:   { label: '开关',   ico: 'Sw',   desc: '开 / 关切换' },
    checkbox: { label: '复选框', ico: '☑',    desc: '勾选 / 取消勾选' },
    slider:   { label: '滑块',   ico: 'Sl',   desc: '拖动选择一个数值' },
    progress: { label: '进度条', ico: 'Pr',   desc: '显示进度百分比' },
    video:    { label: '视频播放器', ico: '▶', desc: '播放网络视频（mp4）' },
    audio:    { label: '音频播放', ico: '♪',  desc: '播放网络音频（mp3）' },
    web:      { label: '网页', ico: 'W',  desc: '内嵌显示一个网页' }
  };
  var STORE_KEY = '__bb_projects_v2';
  var LEGACY_KEY = '__editorAutosave_v1';
  var OPEN_KEY = '__bb_open_id'; // 正在编辑的工程，用于从运行预览返回时自动恢复

  var state = { itemId: null, project: null, curScreenId: null, selectedCompId: null, ws: null, wsInited: false, view: 'design', inLayout: false, newOrient: 'portrait', runMode: 'start' };
  var loadingWs = false; // 程序化装载积木时抑制变更监听，避免误存半成品
  var DEFAULT_BLOCK_SCALE = 0.68; // 积木默认缩放（原 0.85 偏大，调小）
  var ZOOM_GLOBAL_KEY = '__bb_block_zoom_v1'; // 跨所有 App 记住积木缩放
  function globalBlockScale() {
    try { var g = parseFloat(localStorage.getItem(ZOOM_GLOBAL_KEY)); if (isFinite(g) && g >= 0.35 && g <= 2.0) return g; } catch (e) {}
    return null;
  }
  function savedBlockScale() {
    var v = state.project && state.project.blockZoom;           // 本 App 自己调过则优先
    if (typeof v === 'number' && v >= 0.35 && v <= 2.0) return v;
    var g = globalBlockScale();                                  // 新建 App 也沿用全局缩放
    return g != null ? g : DEFAULT_BLOCK_SCALE;
  }
  var zoomPersistTimer = null;
  // 记录当前积木缩放并防抖落盘（zoomCenter/滚轮/双指不一定触发 viewport 事件，故多触发点兜底）
  function recordZoom(immediate) {
    if (!state.wsInited || !state.ws || !state.project) return;
    var sc = state.ws.getScale();
    if (isFinite(sc) && sc >= 0.35 && sc <= 2.0) {
      state.project.blockZoom = sc;
      try { localStorage.setItem(ZOOM_GLOBAL_KEY, String(sc)); } catch (e) {} // 全局记忆，新建 App 不再恢复默认
    }
    clearTimeout(zoomPersistTimer);
    if (immediate) { try { persist(); } catch (e) {} }
    else zoomPersistTimer = setTimeout(function () { try { persist(); } catch (e) {} }, 300);
  }

  /* ---------------- Material 3 主题引擎（主题色 + 明暗，近似 M3 tonal palette） ---------------- */
  var THEME_KEY = '__bb_theme_v1';
  var SEEDS = [['#6750A4', '紫'], ['#0B57D0', '蓝'], ['#00696D', '青'], ['#386A20', '绿'],
    ['#9C4100', '橙'], ['#984061', '玫'], ['#B3261E', '红'], ['#7A5900', '金'],
    ['#4F378B', '深紫'], ['#006A6A', '蓝绿'], ['#1D1B20', '墨'], ['#5C5419', '橄榄']];
  function hex2hsl(hex) {
    var h = hex.replace('#', '');
    var r = parseInt(h.substr(0, 2), 16) / 255, g = parseInt(h.substr(2, 2), 16) / 255, b = parseInt(h.substr(4, 2), 16) / 255;
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, hu = 0, s = 0;
    if (mx !== mn) { var d = mx - mn; s = l > .5 ? d / (2 - mx - mn) : d / (mx + mn);
      if (mx === r) hu = (g - b) / d + (g < b ? 6 : 0); else if (mx === g) hu = (b - r) / d + 2; else hu = (r - g) / d + 4; hu *= 60; }
    return [hu, s * 100, l * 100];
  }
  function hsl(h, s, l) { l = Math.max(0, Math.min(100, l)); return 'hsl(' + Math.round(h) + ' ' + Math.round(s) + '% ' + Math.round(l) + '%)'; }
  function tone(H, S, t) { return hsl(H, S * (1 - Math.abs(t - 50) / 50 * .45), t); } // 两端降彩度
  function getTheme() { try { var t = JSON.parse(localStorage.getItem(THEME_KEY) || 'null'); if (t && t.seed) return t; } catch (e) {} return { seed: '#6750A4', mode: 'light' }; }
  function saveTheme(t) { try { localStorage.setItem(THEME_KEY, JSON.stringify(t)); } catch (e) {} }
  // 系统是否深色：优先问原生（部分安卓 WebView 不回传 prefers-color-scheme），再退回媒体查询
  function systemDark() {
    try { if (window.Native && Native.isSystemDark) { var r = Native.isSystemDark(); return r === true || r === 'true'; } } catch (e) {}
    try { return matchMedia('(prefers-color-scheme: dark)').matches; } catch (e) { return false; }
  }
  function effMode(mode) { if (mode !== 'auto') return mode; return systemDark() ? 'dark' : 'light'; }
  function applyTheme() {
    var th = getTheme(), dark = effMode(th.mode) === 'dark';
    var hs = hex2hsl(th.seed), H = hs[0], S = Math.max(hs[1], 36), Ht = (H + 58) % 360, St = Math.max(S, 30), N = Math.min(S, 16), V = {};
    if (!dark) {
      V = { '--primary': tone(H,S,40), '--on-primary': '#fff', '--primary-c': tone(H,S,90), '--on-primary-c': tone(H,S,10),
        '--secondary-c': tone(H,Math.max(S-8,22),90), '--on-secondary-c': tone(H,S,10),
        '--tertiary': tone(Ht,St,40), '--tertiary-c': tone(Ht,St,90), '--on-tertiary-c': tone(Ht,St,10),
        '--error': '#B3261E', '--on-error': '#fff', '--error-c': '#F9DEDC', '--on-error-c': '#410E0B',
        '--surface': tone(H,N,98), '--on-surface': tone(H,N,10), '--on-surface-var': tone(H,N,30),
        '--c-lowest': tone(H,N,100), '--c-low': tone(H,N,96), '--c': tone(H,N,94), '--c-high': tone(H,N,92), '--c-highest': tone(H,N,90),
        '--outline': tone(H,N,50), '--outline-var': tone(H,N,88), '--scrim': 'rgba(0,0,0,.32)' };
    } else {
      V = { '--primary': tone(H,S,80), '--on-primary': tone(H,S,20), '--primary-c': tone(H,S,30), '--on-primary-c': tone(H,S,90),
        '--secondary-c': tone(H,Math.max(S-8,22),30), '--on-secondary-c': tone(H,S,90),
        '--tertiary': tone(Ht,St,80), '--tertiary-c': tone(Ht,St,30), '--on-tertiary-c': tone(Ht,St,90),
        '--error': '#F2B8B5', '--on-error': '#601410', '--error-c': '#8C1D18', '--on-error-c': '#F9DEDC',
        '--surface': tone(H,N,6), '--on-surface': tone(H,N,90), '--on-surface-var': tone(H,N,76),
        '--c-lowest': tone(H,N,4), '--c-low': tone(H,N,10), '--c': tone(H,N,15), '--c-high': tone(H,N,20), '--c-highest': tone(H,N,25),
        '--outline': tone(H,N,60), '--outline-var': tone(H,N,30), '--scrim': 'rgba(0,0,0,.5)' };
    }
    var root = document.documentElement;
    Object.keys(V).forEach(function (k) { root.style.setProperty(k, V[k]); });
    root.setAttribute('data-theme', dark ? 'dark' : 'light');
  }
  applyTheme();
  // 系统深浅色变化：浏览器媒体查询 或 原生配置变更回调，都会在“跟随系统”时即时换肤
  try { matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function () { if (getTheme().mode === 'auto') applyTheme(); }); } catch (e) {}
  window.__onSystemThemeChanged = function () { if (getTheme().mode === 'auto') applyTheme(); };

  /* ---------------- M3 自定义取色器（替代安卓系统原生取色框，支持预设 + HSL + HEX） ---------------- */
  function clamp255(n) { return Math.max(0, Math.min(255, Math.round(n))); }
  function hslToHex(h, s, l) { // s,l 为 0..100
    s /= 100; l /= 100; h = ((h % 360) + 360) % 360;
    var c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2;
    var r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; } else if (h < 180) { g = c; b = x; }
    else if (h < 240) { g = x; b = c; } else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
    function hx(v) { return clamp255((v + m) * 255).toString(16).padStart(2, '0'); }
    return ('#' + hx(r) + hx(g) + hx(b)).toUpperCase();
  }
  // 接受 #rgb / #rrggbb，输出规范大写 #RRGGBB；非法返回 null（杜绝原生 color input 静默变黑）
  function normalizeHex(str) {
    if (str == null) return null;
    var s = String(str).trim();
    if (!s) return null;
    if (s.charAt(0) !== '#') s = '#' + s;
    if (/^#[0-9a-fA-F]{3}$/.test(s)) s = '#' + s[1] + s[1] + s[2] + s[2] + s[3] + s[3];
    return /^#[0-9a-fA-F]{6}$/.test(s) ? s.toUpperCase() : null;
  }
  var CP = { h: 262, s: 34, l: 48, cb: null, hexEditing: false };
  var CP_PRESETS = ['#1D1B20', '#49454F', '#6750A4', '#0B57D0', '#00696D', '#386A20',
    '#9C4100', '#984061', '#B3261E', '#C7C9CE', '#F3EDF7', '#FFFFFF'];
  function cpCurrentHex() { return hslToHex(CP.h, CP.s, CP.l); }
  function cpSync() {
    var hex = cpCurrentHex();
    $('cpNew').style.background = hex;
    $('cpH').value = Math.round(CP.h); $('cpS').value = Math.round(CP.s); $('cpL').value = Math.round(CP.l);
    $('cpHv').textContent = Math.round(CP.h) + '°'; $('cpSv').textContent = Math.round(CP.s) + '%'; $('cpLv').textContent = Math.round(CP.l) + '%';
    if (!CP.hexEditing) $('cpHex').value = hex;
  }
  function pickColor(initial, fallback) {
    return new Promise(function (resolve) {
      var init = normalizeHex(initial) || normalizeHex(fallback) || '#6750A4';
      var hv = hex2hsl(init); CP.h = hv[0]; CP.s = hv[1]; CP.l = hv[2];
      CP.cb = resolve; CP.hexEditing = false;
      $('cpHex').value = init; cpSync();
      var cm = document.querySelector('#colorMask .modal'); if (cm) cm.scrollTop = 0;
      $('colorMask').classList.remove('hidden');
    });
  }
  function closeColor(res) { if (CP.cb) { var r = res; CP.cb(r); CP.cb = null; } $('colorMask').classList.add('hidden'); }
  function bindColorPicker() {
    var presets = $('cpPresets'); presets.innerHTML = '';
    CP_PRESETS.forEach(function (hex) {
      var sw = el('button', 'cp-swatch'); sw.type = 'button'; sw.style.background = hex; sw.title = hex;
      sw.addEventListener('click', function () { var v = hex2hsl(hex); CP.h = v[0]; CP.s = v[1]; CP.l = v[2]; cpSync(); });
      presets.appendChild(sw);
    });
    [['cpH', 'h'], ['cpS', 's'], ['cpL', 'l']].forEach(function (pair) {
      $(pair[0]).addEventListener('input', function () { CP[pair[1]] = Number(this.value); cpSync(); });
    });
    $('cpHex').addEventListener('input', function () {
      CP.hexEditing = true;
      var v = normalizeHex(this.value);
      if (v) { var hsv = hex2hsl(v); CP.h = hsv[0]; CP.s = hsv[1]; CP.l = hsv[2];
        $('cpH').value = CP.h; $('cpS').value = CP.s; $('cpL').value = CP.l;
        $('cpHv').textContent = Math.round(CP.h) + '°'; $('cpSv').textContent = Math.round(CP.s) + '%'; $('cpLv').textContent = Math.round(CP.l) + '%';
        $('cpNew').style.background = v;
      }
    });
    $('cpOk').addEventListener('click', function () {
      var v = normalizeHex($('cpHex').value) || cpCurrentHex(); closeColor(v);
    });
    $('cpCancel').addEventListener('click', function () { closeColor(null); });
    $('cpClear').addEventListener('click', function () { closeColor(''); });   // 恢复默认=清除自定义
  }

  /* ---------------- 精美确认弹窗（替代浏览器原生 confirm） ---------------- */
  function confirmDialog(opt) {
    return new Promise(function (resolve) {
      $('confirmTitle').textContent = opt.title || '确认操作';
      var msg = $('confirmMsg'); msg.innerHTML = '';
      if (typeof opt.msg === 'string') msg.textContent = opt.msg; else msg.appendChild(opt.msg);
      var ok = $('confirmOk'), cancel = $('confirmCancel');
      var nonDanger = opt.danger === false;
      ok.textContent = opt.okText || '删除';
      ok.style.background = nonDanger ? 'var(--primary)' : 'var(--error)';
      ok.style.color = nonDanger ? 'var(--on-primary)' : 'var(--on-error)';
      $('confirmIcon').classList.toggle('info', nonDanger);
      $('confirmMask').classList.remove('hidden');
      function done(r) { $('confirmMask').classList.add('hidden'); ok.onclick = null; cancel.onclick = null; resolve(r); }
      ok.onclick = function () { done(true); };
      cancel.onclick = function () { done(false); };
    });
  }

  /* 滑动 vs 点击：在可滚动列表里上下滑动时不触发 click（防止误选其它条目）。
     记录触摸起点，移动超过阈值即判定为拖拽/滑动，本次 click 一律忽略。 */

  /* ================= 触摸弹窗守卫 =================
     真机触摸 tap 的兼容 click 会在 touchend 之后才完成命中检测：若 tap 的抬手动作刚打开了
     全屏弹窗（数字/文本编辑框、云列表创建/管理等），这个迟到的 click 会落到遮罩背景上，
     触发“点遮罩关闭”，表现为弹窗一闪即关、按钮点不动、字段无法编辑。
     这里记录每个遮罩最近一次显示的时间，显示后 600ms 内落在遮罩背景上的 click 一律拦截
     （弹窗内按钮的 target 不是遮罩本身，不受影响；600ms 后点背景关闭的习惯仍然保留）。 */
  (function maskOpenGuard() {
    var shownAt = Object.create(null);
    function keyOf(m) { return m.id || ('anon_' + maskOpenGuard.seed++); }
    function mark(m) {
      if (m && m.classList && m.classList.contains('mask') && !m.classList.contains('hidden')) {
        shownAt[keyOf(m)] = Date.now();
      }
    }
    maskOpenGuard.seed = 1;
    function observe(m) {
      if (!m || m.__maskGuarded) return; m.__maskGuarded = true;
      new MutationObserver(function () { mark(m); }).observe(m, { attributes: true, attributeFilter: ['class'] });
      mark(m);
    }
    document.querySelectorAll('.mask').forEach(observe);
    document.addEventListener('click', function (e) {
      var m = e.target;
      if (!m || m.nodeType !== 1 || !m.classList || !m.classList.contains('mask')) return;
      var t = shownAt[keyOf(m)] || 0;
      if (Date.now() - t < 600) { e.stopImmediatePropagation(); e.stopPropagation(); e.preventDefault(); }
    }, true);
    window.__observeMask = observe;
  })();

  /* ================= Blockly 弹窗 M3 化（替代安卓原生 prompt/confirm/alert） ================= */
  var bdState = null;
  function bdFinish(v) {
    var cb = bdState && bdState.cb;
    $('blocklyDialogMask').classList.add('hidden');
    bdState = null;
    if (cb) cb(v);
  }
  function setupBlocklyDialogs() {
    if (!window.Blockly || !Blockly.dialog) return;
    function openModal() { $('blocklyDialogMask').classList.remove('hidden'); }
    function bdPrompt(message, defaultValue, cb) {
      bdState = { cb: cb };
      $('bdMessage').textContent = message || '';
      $('bdField').style.display = '';
      var inp = $('bdInput');
      inp.type = 'text'; inp.value = defaultValue == null ? '' : String(defaultValue);
      $('bdCancel').style.display = ''; $('bdOk').textContent = '确定';
      openModal();
      // 不再全选已有文案：聚焦后把光标放到末尾，避免一输入就覆盖原内容
      setTimeout(function () {
        inp.focus();
        var len = inp.value.length;
        try { inp.setSelectionRange(len, len); } catch (e) { inp.scrollLeft = inp.scrollWidth; }
      }, 60);
    }
    function bdConfirm(message, cb) {
      bdState = { cb: cb };
      $('bdMessage').textContent = message || '';
      $('bdField').style.display = 'none';
      $('bdCancel').style.display = ''; $('bdOk').textContent = '确定';
      openModal();
    }
    function bdAlert(message, cb) {
      bdState = { cb: cb };
      $('bdMessage').textContent = message || '';
      $('bdField').style.display = 'none';
      $('bdCancel').style.display = 'none'; $('bdOk').textContent = '知道了';
      openModal();
    }
    Blockly.dialog.setPrompt(bdPrompt);
    Blockly.dialog.setConfirm(bdConfirm);
    Blockly.dialog.setAlert(bdAlert);
    setupBlocklyDialogs.done = true;
  }
  function bindBlocklyDialogUi() {
    function ok() {
      if (!bdState) return;
      if ($('bdField').style.display === 'none') bdFinish(true);
      else bdFinish($('bdInput').value);
    }
    $('bdOk').addEventListener('click', ok);
    $('bdCancel').addEventListener('click', function () {
      if (!bdState) return;
      bdFinish($('bdField').style.display === 'none' ? false : null);
    });
    $('bdInput').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); ok(); }
      if (e.key === 'Escape') { e.preventDefault(); bdFinish(null); }
    });
    $('blocklyDialogMask').addEventListener('click', function (e) {
      if (e.target === this && bdState) bdFinish($('bdField').style.display === 'none' ? false : null);
    });
  }

  /* ================= 云表格（SeaTable）创建 / 管理 ================= */
  window.BB_getProjectClouds = function () {
    return (state && state.project && Array.isArray(state.project.clouds)) ? state.project.clouds : [];
  };
  function cloudProviderLabel(p) {
    if (p === 'seatable-io') return 'SeaTable 国际版';
    if (p === 'seatable-custom') return 'SeaTable 自定义';
    return 'SeaTable 中国版';
  }
  function cloudDefaultServer(p) {
    return p === 'seatable-io' ? 'https://cloud.seatable.io' : 'https://cloud.seatable.cn';
  }
  // 编辑器侧 HTTP：App 内走原生桥接（绕开网关重复 CORS 头），无头/浏览器直连 fetch
  function editorCloudHttp(method, url, body, token) {
    var h = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
    if (token) h['Authorization'] = 'Token ' + token;
    var bodyText = (body !== undefined && body !== null) ? JSON.stringify(body) : null;
    function interpret(status, txt) {
      var data = null; if (txt) { try { data = JSON.parse(txt); } catch (e) { data = null; } }
      var errMsg = data && (data.error_message || data.error_msg || data.detail || data.error);
      if (status < 200 || status >= 300 || errMsg) throw new Error(errMsg || ('请求失败 HTTP ' + status));
      return data;
    }
    if (window.Native && Native.httpRequest) {
      return new Promise(function (resolve, reject) {
        var id = 'cc_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
        var done = false;
        var timer = setTimeout(function () { if (!done) { done = true; reject(new Error('连接超时，请检查网络')); } }, 20000);
        var prev = window.__nativeHttpResolve || function () {};
        window.__nativeHttpResolve = function (rid, json) {
          if (rid === id) {
            window.__nativeHttpResolve = prev;
            if (done) return; done = true; clearTimeout(timer);
            var r = null; try { r = JSON.parse(json); } catch (e) { reject(new Error('响应解析失败')); return; }
            if (r.error) { reject(new Error(r.error)); return; }
            try { resolve(interpret(r.status || 0, r.body || '')); } catch (e) { reject(e); }
          } else if (typeof prev === 'function') prev(rid, json);
        };
        try { Native.httpRequest(id, method, url, JSON.stringify(h), bodyText || ''); }
        catch (e) { if (!done) { done = true; clearTimeout(timer); reject(e); } }
      });
    }
    var opt = { method: method, headers: h };
    if (bodyText !== null) opt.body = bodyText;
    return fetch(url, opt).then(function (resp) {
      return resp.text().then(function (txt) { return interpret(resp.status, txt); });
    });
  }
  // 校验凭证：换取 token 并读取表清单
  async function cloudPing(provider, server, uuid, token) {
    var srv = (provider === 'seatable-custom' ? String(server || '').trim().replace(/\/+$/, '') : cloudDefaultServer(provider));
    if (provider === 'seatable-custom' && !srv) throw new Error('请填写服务器地址');
    if (!uuid) throw new Error('请填写表格 UUID');
    if (!token) throw new Error('请填写 API 密钥');
    var d = await editorCloudHttp('GET', srv + '/api/v2.1/dtable/app-access-token/', null, token);
    if (!d || !d.access_token) throw new Error('鉴权失败，请检查 API 密钥');
    var gateway = (d.dtable_server || (srv + '/api-gateway/')).replace(/\/+$/, '');
    var realUuid = d.dtable_uuid || uuid;
    var meta = await editorCloudHttp('GET', gateway + '/api/v2/dtables/' + realUuid + '/metadata/', null, d.access_token);
    var tables = (meta && meta.metadata && meta.metadata.tables || []).map(function (t) { return t.name; });
    return { server: srv, uuid: realUuid, tables: tables };
  }
  // 云表格变更后：刷新画布/浮层下拉，若云列表浮层开着则重建
  function refreshCloudUi() {
    try { refreshCompDropdowns(); } catch (e) {}
    if (!state.wsInited || !state.ws) return;
    try {
      var tb = state.ws.getToolbox && state.ws.getToolbox(), sel = tb && tb.getSelectedItem();
      if (sel && catItemName(sel) === '云列表') {
        tb.clearSelection();
        setTimeout(function () { try { tb.setSelectedItem(sel); } catch (e) {} }, 0);
      }
    } catch (e) {}
  }
  var ccEditingId = null;
  function ccSyncServerVis() {
    $('ccServerField').style.display = $('ccProvider').value === 'seatable-custom' ? '' : 'none';
  }
  function ccSetError(msg) { $('ccError').textContent = msg || ''; }
  function openCloudCreate(editingId) {
    ccEditingId = editingId || null;
    var c = null;
    if (ccEditingId) c = window.BB_getProjectClouds().filter(function (x) { return x.id === ccEditingId; })[0] || null;
    $('ccTitle').textContent = c ? '编辑 SeaTable 云列表' : '创建 SeaTable 云列表';
    $('ccGo').textContent = c ? '保存' : '创建云表格';
    $('ccProvider').value = c ? c.provider : 'seatable-cn';
    $('ccServer').value = c ? (c.server || '') : '';
    $('ccName').value = c ? c.name : '';
    $('ccUuid').value = c ? c.uuid : '';
    $('ccToken').value = c ? c.token : '';
    ccSetError(''); ccSyncServerVis();
    $('cloudCreateMask').classList.remove('hidden');
    setTimeout(function () { (c ? $('ccToken') : $('ccName')).focus(); }, 80);
  }
  function closeCloudCreate() { $('cloudCreateMask').classList.add('hidden'); ccEditingId = null; }
  async function ccSubmit() {
    var f = {
      provider: $('ccProvider').value, server: $('ccServer').value.trim(),
      name: $('ccName').value.trim(), uuid: $('ccUuid').value.trim(), token: $('ccToken').value.trim()
    };
    var btn = $('ccGo');
    if (!f.name) { ccSetError('请给这个云表格起个名字'); $('ccName').focus(); return; }
    if (f.provider === 'seatable-custom' && !/^https?:\/\//.test(f.server)) { ccSetError('服务器地址需以 http:// 或 https:// 开头'); $('ccServer').focus(); return; }
    var dup = window.BB_getProjectClouds().some(function (x) { return x.name === f.name && x.id !== ccEditingId; });
    if (dup) { ccSetError('已存在同名云表格，请换一个名字'); $('ccName').focus(); return; }
    btn.disabled = true; var oldText = btn.textContent; btn.textContent = '校验中…'; ccSetError('');
    try {
      var r = await cloudPing(f.provider, f.server, f.uuid, f.token);
      var clouds = state.project.clouds = state.project.clouds || [];
      if (ccEditingId) {
        var ex = clouds.filter(function (x) { return x.id === ccEditingId; })[0];
        if (ex) { ex.name = f.name; ex.provider = f.provider; ex.server = r.server; ex.uuid = r.uuid; ex.token = f.token; }
        snack('云表格已更新');
      } else {
        clouds.push({ id: 'c_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
          name: f.name, provider: f.provider, server: r.server, uuid: r.uuid, token: f.token });
        snack('云表格创建成功，共 ' + r.tables.length + ' 个数据表');
      }
      closeCloudCreate(); refreshCloudUi(); autosave();
    } catch (e) {
      ccSetError('创建失败：' + (e && e.message ? e.message : e));
    } finally {
      btn.disabled = false; btn.textContent = oldText;
    }
  }
  function renderCloudManage() {
    var list = $('cmList'); list.innerHTML = '';
    var clouds = window.BB_getProjectClouds();
    if (!clouds.length) { list.appendChild(el('div', 'cm-empty', '还没有云表格，点下方“创建云表格”开始')); return; }
    clouds.forEach(function (c) {
      var item = el('div', 'cm-item');
      var info = el('div', 'cm-info');
      info.appendChild(el('div', 'cm-name', c.name));
      info.appendChild(el('div', 'cm-meta', cloudProviderLabel(c.provider) + ' · ' + (c.server || '').replace(/^https?:\/\//, '') + ' · ' + String(c.uuid).slice(0, 8)));
      var ops = el('div', 'cm-ops');
      var editBtn = el('button', '', '编辑'); editBtn.type = 'button';
      editBtn.addEventListener('click', function () { $('cloudManageMask').classList.add('hidden'); openCloudCreate(c.id); });
      var delBtn = el('button', 'danger', '删除'); delBtn.type = 'button';
      delBtn.addEventListener('click', async function () {
        var ok = await confirmDialog({ title: '删除云表格', msg: '确定删除云表格“' + c.name + '”吗？相关积木需要重新选择云表格。', okText: '删除' });
        if (!ok) return;
        state.project.clouds = state.project.clouds.filter(function (x) { return x.id !== c.id; });
        renderCloudManage(); refreshCloudUi(); autosave(); snack('已删除');
      });
      ops.appendChild(editBtn); ops.appendChild(delBtn);
      item.appendChild(info); item.appendChild(ops); list.appendChild(item);
    });
  }
  function openCloudManage() { renderCloudManage(); $('cloudManageMask').classList.remove('hidden'); }
  function bindCloudUi() {
    $('ccProvider').addEventListener('change', ccSyncServerVis);
    $('ccGo').addEventListener('click', ccSubmit);
    $('ccCancel').addEventListener('click', closeCloudCreate);
    $('cloudCreateMask').addEventListener('click', function (e) { if (e.target === this) closeCloudCreate(); });
    $('cmAdd').addEventListener('click', function () { $('cloudManageMask').classList.add('hidden'); openCloudCreate(null); });
    $('cmClose').addEventListener('click', function () { $('cloudManageMask').classList.add('hidden'); });
    $('cloudManageMask').addEventListener('click', function (e) { if (e.target === this) this.classList.add('hidden'); });
  }

  var tapGuard = (function () {
    var sx = 0, sy = 0, dragging = false, down = false;
    document.addEventListener('touchstart', function (e) {
      var t = e.touches[0]; sx = t.clientX; sy = t.clientY; dragging = false; down = true;
    }, { passive: true, capture: true });
    document.addEventListener('touchmove', function (e) {
      if (!down) return; var t = e.touches[0];
      if (Math.abs(t.clientX - sx) > 10 || Math.abs(t.clientY - sy) > 10) dragging = true;
    }, { passive: true, capture: true });
    document.addEventListener('touchend', function () {
      // 留到 click 阶段读取后再复位
      setTimeout(function () { down = false; dragging = false; }, 350);
    }, { passive: true, capture: true });
    return { isDragging: function () { return dragging; } };
  })();
  // 仅当“轻点”（非滑动）时执行
  function onTap(handler) {
    return function (e) { if (tapGuard.isDragging()) { e.preventDefault(); e.stopPropagation(); return; } handler.call(this, e); };
  }

  /* 弹窗打开时锁定背后滚动：任何 .mask 可见时，只允许弹窗本体(.modal)内部滚动，
     阻止背后页面（首页列表/组件列表/积木画布）跟着滑动 */
  (function lockBackgroundScroll() {
    function openMask() { return document.querySelector('.mask:not(.hidden)'); }
    function block(e) {
      var m = openMask(); if (!m) return;
      if (e.target.closest && e.target.closest('.modal')) return;  // 弹窗内部滚动放行
      e.preventDefault();
    }
    document.addEventListener('touchmove', block, { passive: false, capture: true });
    document.addEventListener('wheel', block, { passive: false, capture: true });
  })();

  /* 编辑器侧滑返回：左缘右拖 → 优先关弹窗，其次退出“拖动布局”回到编辑器 */
  (function editorEdgeSwipe() {
    var sx = 0, sy = 0, active = false;
    document.addEventListener('touchstart', function (e) {
      var t = e.touches[0]; active = t.clientX <= 26; if (active) { sx = t.clientX; sy = t.clientY; }
    }, { passive: true, capture: true });
    document.addEventListener('touchmove', function (e) {
      if (!active) return; var t = e.touches[0], dx = t.clientX - sx, dy = t.clientY - sy, h = $('edgeHint');
      if (dx > 12 && Math.abs(dx) > Math.abs(dy) && h) { h.classList.add('show'); h.style.transform = 'translateX(' + Math.min(dx - 12, 90) + 'px)'; }
    }, { passive: true, capture: true });
    function finish(e) {
      if (!active) return; active = false;
      var h = $('edgeHint'); if (h) { h.classList.remove('show'); h.style.transform = ''; }
      var t = e.changedTouches ? e.changedTouches[0] : null, dx = t ? t.clientX - sx : 0, dy = t ? t.clientY - sy : 0;
      if (!(dx > 64 && Math.abs(dx) > Math.abs(dy) * 1.4)) return;
      var masks = ['createMask', 'colorMask', 'cloudCreateMask', 'cloudManageMask', 'blocklyDialogMask', 'confirmMask', 'exportMask', 'settingsMask', 'modalMask'];
      for (var i = 0; i < masks.length; i++) { var m = $(masks[i]); if (m && !m.classList.contains('hidden')) { m.classList.add('hidden'); return; } }
      if (state.inLayout) closeLayout();
    }
    document.addEventListener('touchend', finish, { passive: true, capture: true });
    document.addEventListener('touchcancel', function () { active = false; var h = $('edgeHint'); if (h) h.classList.remove('show'); }, { passive: true, capture: true });
  })();

  /* ---------------- 项目工程 ---------------- */
  function blankProject() {
    return {
      appName: '我的应用', orientation: 'portrait', version: '1.0', icon: null,
      startScreen: 's1', clouds: [],
      screens: [{ id: 's1', title: '页面1', components: [], blocksXml: '<xml xmlns="https://developers.google.com/blockly/xml"></xml>' }]
    };
  }
  function loadStore() {
    var s = null;
    try { s = JSON.parse(localStorage.getItem(STORE_KEY) || 'null'); } catch (e) {}
    if (!s || !s.items) {
      s = { items: [] };
      // 迁移旧版单工程自动保存
      try {
        var old = JSON.parse(localStorage.getItem(LEGACY_KEY) || 'null');
        if (old && old.project && old.project.screens) {
          s.items.push({ id: 'p' + Date.now().toString(36), name: old.project.appName || '我的应用',
            updatedAt: Date.now(), project: old.project });
        }
      } catch (e) {}
      saveStore(s);
    }
    return s;
  }
  function saveStore(s) { try { localStorage.setItem(STORE_KEY, JSON.stringify(s)); } catch (e) {} }
  function persist() {
    if (!state.itemId || !state.project) return;
    state.project.appName = $('appName').value || state.project.appName;
    var s = loadStore();
    for (var i = 0; i < s.items.length; i++) if (s.items[i].id === state.itemId) {
      s.items[i].project = state.project; s.items[i].name = state.project.appName; s.items[i].updatedAt = Date.now();
    }
    saveStore(s);
  }
  var saveTimer = null;
  // 自动保存绝不能关闭分类浮层/下拉/齿轮框：在 mutator 小框里拖积木会触发主工作区变更→
  // autosave→旧逻辑收起小框，表现为“拖动时框突然关闭”。离开积木页时才显式传 closeOverlays=true。
  function autosave() { clearTimeout(saveTimer); saveTimer = setTimeout(function () { saveCurrentWs(false); persist(); }, 250); }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }

  /* ---------------- 首页 ---------------- */
  function showHome() {
    saveCurrentWs(true); persist();
    try { localStorage.removeItem(OPEN_KEY); } catch (e) {}
    $('viewEditor').classList.add('hidden');
    $('viewHelp').classList.add('hidden');
    $('viewHome').classList.remove('hidden');
    renderHome();
  }

  /* ---------------- 使用帮助页（左：与编辑器一致的分类轨道；右：逐积木说明） ---------------- */
  var helpBuilt = false, helpCurrent = null;
  function openHelp() {
    buildHelp();
    $('viewHome').classList.add('hidden');
    $('viewHelp').classList.remove('hidden');
  }
  function buildHelp() {
    if (helpBuilt) return; helpBuilt = true;
    var rail = $('helpCats');
    function catButton(group) {
      var b = el('button', 'bb-cat'); b.type = 'button';
      b.style.setProperty('--bb-c', group.colour);
      var icoTxt = (window.BB_CAT_ICON && window.BB_CAT_ICON[group.cat]) || group.cat.slice(0, 1);
      var ico = el('span', 'bb-cat-ico', icoTxt);
      ico.style.background = group.colour + '1F'; ico.style.color = group.colour;
      var lb = el('span', 'bb-cat-lb', group.cat);
      b.appendChild(ico); b.appendChild(lb);
      b.addEventListener('click', function (ev) {
        ev.preventDefault();
        helpCurrent = group;
        Array.prototype.forEach.call(rail.querySelectorAll('.bb-cat'), function (x) { x.classList.remove('on'); });
        b.classList.add('on');
        renderHelpCat(group);
      });
      return b;
    }
    var gp = $('hpGeneralPanel'), wp = $('hpWidgetPanel');
    (window.BB_HELP.general || []).forEach(function (g) { gp.appendChild(catButton(g)); });
    (window.BB_HELP.widget || []).forEach(function (g) { wp.appendChild(catButton(g)); });
    function setMode(mode) {
      rail.classList.remove('bb-mode-general', 'bb-mode-widget');
      rail.classList.add('bb-mode-' + mode);
      // 切换到某组时，若当前选中分类属于另一组，则自动选中该组第一个分类
      var list = mode === 'widget' ? window.BB_HELP.widget : window.BB_HELP.general;
      var inList = list.some(function (g) { return g === helpCurrent; });
      if (!inList && list.length) {
        helpCurrent = list[0];
        var panel = mode === 'widget' ? wp : gp;
        var btns = panel.querySelectorAll('.bb-cat');
        Array.prototype.forEach.call(rail.querySelectorAll('.bb-cat'), function (x) { x.classList.remove('on'); });
        if (btns[0]) btns[0].classList.add('on');
        renderHelpCat(list[0]);
      }
    }
    $('hpBotSw').addEventListener('click', function () { setMode('widget'); });
    $('hpTopSw').addEventListener('click', function () { setMode('general'); });
    // 默认选中“事件”
    var first = rail.querySelector('.bb-cat');
    if (first) first.classList.add('on');
    helpCurrent = window.BB_HELP.general[0];
    renderHelpCat(helpCurrent);
  }
  function renderHelpCat(group) {
    var box = $('helpContent'); box.innerHTML = '';
    var head = el('div', 'hp-cat-head');
    var dot = el('span', 'hp-cat-dot'); dot.style.background = group.colour;
    var title = el('span', 'hp-cat-title', group.cat);
    head.appendChild(dot); head.appendChild(title); box.appendChild(head);
    if (group.intro) { var inr = el('div', 'hp-intro', group.intro); box.appendChild(inr); }
    (group.blocks || []).forEach(function (bk) {
      var card = el('div', 'hp-block');
      var sig = el('div', 'hp-sig', bk.sig);
      sig.style.background = group.colour;
      card.appendChild(sig);
      var desc = el('div', 'hp-desc', bk.desc); card.appendChild(desc);
      if (bk.use) {
        var use = el('div', 'hp-use');
        var tag = el('span', 'hp-use-tag', '用法'); var ut = el('span', 'hp-use-tx', bk.use);
        use.appendChild(tag); use.appendChild(ut); card.appendChild(use);
      }
      box.appendChild(card);
    });
    box.scrollTop = 0;
  }
  function fmtTime(t) {
    var d = new Date(t || Date.now()), p = function (n) { return (n < 10 ? '0' : '') + n; };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  }
  function renderHome() {
    var s = loadStore(), box = $('projectList'); box.innerHTML = '';
    var empty = $('homeEmpty');
    empty.classList.toggle('hidden', s.items.length > 0);
    empty.textContent = s.items.length ? '' : '点击右上角「创建新 App」开始';
    s.items.slice().sort(function (a, b) { return (b.updatedAt || 0) - (a.updatedAt || 0); }).forEach(function (it) {
      var n = it.project.screens.reduce(function (a, x) { return a + x.components.length; }, 0);
      var card = el('div', 'proj-card');
      card.appendChild(el('div', 'pname', it.name || '未命名'));
      card.appendChild(el('div', 'pmeta', it.project.screens.length + ' 个页面 · ' + n + ' 个组件\n更新于 ' + fmtTime(it.updatedAt).replace('\n', ' ')));
      card.querySelector('.pmeta').innerHTML = it.project.screens.length + ' 个页面 · ' + n + ' 个组件<br>更新于 ' + fmtTime(it.updatedAt);
      var ops = el('div', 'pops');
      var open = el('button', null, '打开编辑'), dup = el('button', null, '复制'),
          del = el('button', 'danger', '删除');
      open.addEventListener('click', function () { openItem(it.id); });
      dup.addEventListener('click', function () { duplicateItem(it.id); });
      del.addEventListener('click', function () {
        var msg = el('div'); msg.appendChild(document.createTextNode('确定删除作品「'));
        var nm = el('span', 'confirm-name', it.name || '未命名'); msg.appendChild(nm); msg.appendChild(document.createTextNode('」？'));
        confirmDialog({ title: '删除作品', msg: msg, okText: '删除' }).then(function (ok) { if (ok) deleteItem(it.id); });
      });
      ops.appendChild(open); ops.appendChild(dup); ops.appendChild(del);
      card.appendChild(ops); card.addEventListener('dblclick', function () { openItem(it.id); });
      box.appendChild(card);
    });
  }
  // 创建 App：先弹 M3 对话框（应用名 + 竖/横屏），确认后再建工程
  function setNewOrient(o) {
    state.newOrient = o;
    Array.prototype.forEach.call(document.querySelectorAll('#newOrient .ori'), function (b) {
      b.classList.toggle('on', b.getAttribute('data-orient') === o);
    });
  }
  function createItem() {
    var mask = $('createMask'), inp = $('newAppName');
    if (!mask) { // 兜底：弹窗缺失时维持原“直接创建”行为
      var s0 = loadStore(), it0 = { id: 'p' + Date.now().toString(36), name: '我的应用', updatedAt: Date.now(), project: blankProject() };
      s0.items.push(it0); saveStore(s0); openItem(it0.id); return;
    }
    inp.value = '';
    var box = inp.closest('.m3-outlined'); if (box) box.classList.remove('filled', 'focused', 'err');
    setNewOrient('portrait');
    syncCreateBtn();
    mask.classList.remove('hidden');
    setTimeout(function () { try { inp.focus(); } catch (e) {} }, 120);
  }
  // 没有输入应用名时禁止创建
  function syncCreateBtn() {
    var inp = $('newAppName'), go = $('createGo');
    if (!inp || !go) return;
    var hasName = !!(inp.value || '').trim();
    go.disabled = !hasName;
    var box = inp.closest('.m3-outlined'); if (box && !hasName) box.classList.remove('err');
  }
  function closeCreate() { $('createMask').classList.add('hidden'); }
  function confirmCreate() {
    var name = ($('newAppName').value || '').trim();
    if (!name) { // 空名：拦截并提示，不允许创建
      var box = $('newAppName').closest('.m3-outlined'); if (box) box.classList.add('err');
      $('newAppName').focus(); return;
    }
    var p = blankProject(); p.appName = name;
    var s = loadStore(), it = { id: 'p' + Date.now().toString(36), name: name, updatedAt: Date.now(), project: p };
    s.items.push(it); saveStore(s);
    $('createMask').classList.add('hidden');
    openItem(it.id);
  }
  function openItem(id) {
    var s = loadStore(), it = null;
    for (var i = 0; i < s.items.length; i++) if (s.items[i].id === id) it = s.items[i];
    if (!it) return;
    state.itemId = id; state.project = it.project;
    if (!Array.isArray(it.project.clouds)) it.project.clouds = [];   // 老工程兼容
    try { localStorage.setItem(OPEN_KEY, id); } catch (e) {}
    // 试运行返回时恢复到运行前正在编辑的页面（一次性消费）；否则打开第一个页面
    var restoreScreen = null;
    try { restoreScreen = localStorage.getItem('__previewReturnScreen'); } catch (e) {}
    var validRestore = restoreScreen && it.project.screens.some(function (s) { return s.id === restoreScreen; });
    state.curScreenId = (validRestore ? restoreScreen : (it.project.screens[0] && it.project.screens[0].id));
    try { localStorage.removeItem('__previewReturnScreen'); } catch (e) {}
    state.selectedCompId = null;
    $('viewHome').classList.add('hidden');
    $('viewEditor').classList.remove('hidden');
    $('appName').value = it.project.appName || '我的应用';
    state.view = 'design'; state.inLayout = false;
    $('viewDesign').classList.remove('hidden'); $('viewBlocks').classList.add('hidden'); $('viewLayout').classList.add('hidden');
    $('tabDesign').classList.add('on'); $('tabBlocks').classList.remove('on');
    var _bl = $('btnLayout'); if (_bl) _bl.classList.remove('on');
    closeMenus();
    renderTabs(); renderCompList(); syncOrientSeg();
    if (state.wsInited) loadScreenToWs(curScreen());
    requestWsResize();
    // 从试运行返回时恢复到运行前所在页（设计/积木），一次性消费，避免影响正常打开
    try {
      var retView = localStorage.getItem('__previewReturnView');
      if (retView === 'blocks') showView('blocks');
      localStorage.removeItem('__previewReturnView');
    } catch (e) {}
  }
  function duplicateItem(id) {
    var s = loadStore();
    for (var i = 0; i < s.items.length; i++) if (s.items[i].id === id) {
      var copy = { id: 'p' + Date.now().toString(36), name: s.items[i].name + ' 副本', updatedAt: Date.now(), project: clone(s.items[i].project) };
      copy.project.appName = copy.name; s.items.push(copy); saveStore(s); renderHome(); return;
    }
  }
  function deleteItem(id) {
    var s = loadStore(); s.items = s.items.filter(function (x) { return x.id !== id; }); saveStore(s); renderHome();
    try { if (localStorage.getItem(OPEN_KEY) === id) localStorage.removeItem(OPEN_KEY); } catch (e) {}
  }

  /* ---------------- 工具 ---------------- */
  function curScreen() {
    for (var i = 0; i < state.project.screens.length; i++)
      if (state.project.screens[i].id === state.curScreenId) return state.project.screens[i];
    return state.project.screens[0];
  }
  function genId(type) {
    var max = 0;
    state.project.screens.forEach(function (s) { s.components.forEach(function (c) {
      if (c.id && c.id.indexOf(type) === 0) { var n = parseInt(c.id.slice(type.length), 10); if (!isNaN(n)) max = Math.max(max, n); }
    }); });
    return type + (max + 1);
  }
  // 控件在积木下拉里的“可读名”：优先用户命名，其次控件上实际显示的文案（如按钮文字 A），
  // 再次才是类型名；重名时追加 id 区分。值始终用 c.id，代码生成不受影响。
  function compPreview(c) {
    return c.text || c.value
      || ((c.type === 'switch' || c.type === 'checkbox') ? (c.checked ? '开' : '关') : '')
      || (c.type === 'slider' ? ('滑块 ' + (validN(c.value) ? c.value : 0)) : '')
      || (c.type === 'progress' ? ('进度 ' + (validN(c.value) ? c.value : 0)) : '')
      || (c.items ? c.items.length + ' 项' : '') || '';
  }
  function compDisplayName(c) {
    if (c.name && String(c.name).trim()) return String(c.name).trim();
    var pv = String(compPreview(c)).trim();
    if (pv) return pv;
    return TYPE_META[c.type].label;
  }
  window.__compOptions = function (types) {
    var sc = window.__codegenScreen || curScreen();
    var rows = sc.components.filter(function (c) { return !types || types.indexOf(c.type) >= 0; });
    var counts = {};
    rows.forEach(function (c) { var n = compDisplayName(c); counts[n] = (counts[n] || 0) + 1; });
    var out = rows.map(function (c) {
      var n = compDisplayName(c);
      if (counts[n] > 1) n = n + '·' + c.id;  // 同名控件追加 id 去重
      return [n, c.id];
    });
    if (!out.length) out.push(['（请先在设计里添加对应组件）', 'NONE']);
    return out;
  };
  window.__pageOptions = function () {
    var out = state.project.screens.map(function (s) { return [s.title || s.id, s.id]; });
    return out.length ? out : [['（无页面）', 'NONE']];
  };

  /* ---------------- 设计：页面与组件列表 ---------------- */
  // 横竖屏 / 通知栏 改为「当前页面」级，存到 screen 上（旧工程缺省时取 portrait / 是）
  function curOrient() { var s = curScreen(); return (s && s.orientation) || 'portrait'; }
  function curShowSB() { var s = curScreen(); return !s || s.showStatusBar !== false; }
  function syncOrientSeg() {
    var o = curOrient();
    Array.prototype.forEach.call(document.querySelectorAll('#moreOrient .orientbtn'), function (b) {
      b.classList.toggle('on', b.getAttribute('data-orient') === o);
    });
    var sb = curShowSB() ? 'yes' : 'no';
    Array.prototype.forEach.call(document.querySelectorAll('#moreStatusBar .orientbtn'), function (b) {
      b.classList.toggle('on', b.getAttribute('data-sb') === sb);
    });
  }
  // 页面切换已改为顶栏「页面 ▾」菜单；这里只负责同步按钮文案与“更多”菜单里的页面名
  function renderTabs() {
    var cur = curScreen();
    var btn = $('btnScreenMenu');
    if (btn) btn.textContent = (cur.title || cur.id) + ' ▾';
    var pt = $('morePageTitle');
    if (pt && document.activeElement !== pt) pt.value = cur.title || '';
    if (state.inLayout) renderLayout();
  }
  function compName(c) { return (c.name && c.name.trim()) ? c.name.trim() : (TYPE_META[c.type].label + ' (' + c.id + ')'); }
  function compDesc(c) {
    var base;
    if (c.type === 'switch' || c.type === 'checkbox') base = (c.text || TYPE_META[c.type].label) + '：' + (c.checked ? '已勾选' : '未勾选');
    else if (c.type === 'slider') base = '范围 ' + (c.min || 0) + '~' + (c.max || 100) + '，当前 ' + (validN(c.value) ? c.value : 0);
    else if (c.type === 'progress') base = '进度 ' + (validN(c.value) ? c.value : 0) + ' / ' + (c.max || 100);
    else base = c.text || c.value || (c.items ? '列表：' + c.items.length + ' 项' : (c.hint || TYPE_META[c.type].desc));
    if (c.x != null && c.y != null) base += '（坐标 ' + c.x + ',' + c.y + '）';
    return base;
  }
  function renderCompList() {
    var sc = curScreen(), box = $('compList'); box.innerHTML = '';
    // 空列表不额外放提示文案（保持界面干净）
    sc.components.forEach(function (c, idx) {
      var meta = TYPE_META[c.type];
      var hidden = c.visible === false;
      var card = el('div', 'compcard' + (c.id === state.selectedCompId ? ' sel' : '') + (hidden ? ' is-hidden' : ''));
      card.dataset.id = c.id;
      card.appendChild(el('div', 'ico', meta.ico));
      var main = el('div', 'main');
      main.appendChild(el('div', 't1', compName(c)));
      main.appendChild(el('div', 't2', compDesc(c)));
      var ops = el('div', 'ops');
      // 卡片上的“显示/隐藏”快捷开关，不必进详情即可隐藏
      var eye = el('button', 'iconbtn eye' + (hidden ? ' off' : ''));
      eye.title = hidden ? '已隐藏，点击显示' : '点击隐藏该控件';
      eye.setAttribute('aria-label', eye.title);
      eye.innerHTML = hidden ? ICON_EYE_OFF : ICON_EYE_ON;
      eye.addEventListener('click', function (e) {
        e.stopPropagation();
        c.visible = hidden ? true : false;
        renderCompList(); if (state.inLayout) renderLayout(); autosave();
      });
      var d = el('button', 'iconbtn', '×');
      d.addEventListener('click', function (e) { e.stopPropagation(); delComp(c.id); });
      ops.appendChild(eye); ops.appendChild(d);
      card.appendChild(main); card.appendChild(ops);
      // 长按卡片拖拽排序（替代旧的上移/下移按钮）
      bindCardReorder(card, c.id);
      card.addEventListener('click', onTap(function (e) {
        e.stopPropagation();
        if (cardReorder.justEnded()) return;   // 长按拖拽松手后的残余 click 不触发选中
        state.selectedCompId = c.id; renderCompList(); renderPropPanel();
      }));
      box.appendChild(card);
    });
    renderPropPanel();
    refreshCompDropdowns();   // 组件改名/增删/排序/改文字后，同步刷新积木里的控件下拉名称
  }
  function selectedComp() {
    var sc = curScreen();
    for (var i = 0; i < sc.components.length; i++) if (sc.components[i].id === state.selectedCompId) return sc.components[i];
    return null;
  }
  // 估算文字在给定字号下的像素宽：中文/全角约 1em，拉丁约 0.58em
  function textPixelWidth(s, fs) {
    s = String(s == null ? '' : s); var w = 0;
    for (var i = 0; i < s.length; i++) { w += (s.charCodeAt(i) >= 0x2e80 ? 1.0 : 0.58) * fs; }
    return w;
  }
  function clampNum(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
  /* 新建控件的“自身内容尺寸”：不再默认占满整行，而是按控件类型/文字内容给一个紧凑初始大小。
     宽度不超过画布内宽；文字类高度留空由内容撑开，其余给类型固定高度。 */
  function naturalSize(type, base) {
    var maxW = designSize().w - 32;
    switch (type) {
      case 'button':   return { w: Math.round(clampNum(textPixelWidth(base.text, 15) + (base.icon ? 46 : 36), 88, maxW)), h: 48 };
      case 'input':    return { w: Math.round(Math.min(220, maxW)), h: 52 };
      case 'list':     return { w: Math.round(Math.min(260, maxW)), h: 170 };
      case 'image':    return { w: Math.round(Math.min(160, maxW)), h: 120 };
      case 'switch':   return { w: Math.round(clampNum(textPixelWidth(base.text, 16) + 52 + 20, 112, maxW)), h: 40 };
      case 'checkbox': return { w: Math.round(clampNum(textPixelWidth(base.text, 16) + 22 + 20, 96, maxW)), h: 40 };
      case 'slider':   return { w: Math.round(Math.min(200, maxW)), h: 48 };
      case 'progress': return { w: Math.round(Math.min(200, maxW)), h: 14 };
      case 'video':    return { w: Math.round(Math.min(240, maxW)), h: 135 };
      case 'audio':    return { w: Math.round(Math.min(280, maxW)), h: 44 };
      case 'web':      return { w: Math.round(Math.min(320, maxW)), h: 240 };
      case 'text':
      default:         return { w: Math.round(clampNum(textPixelWidth(base.value, 16) + 8, 56, maxW)) };
    }
  }
  function addComponent(type) {
    var sc = curScreen(), base = { id: genId(type), type: type };
    var def = {
      text: { value: '文字' }, button: { text: '按钮' },
      input: { hint: '请输入', value: '' }, list: { items: ['第一项', '第二项'] }, image: { alt: '图片' },
      switch: { text: '开关', checked: false }, checkbox: { text: '复选项', checked: false },
      slider: { min: 0, max: 100, value: 40 }, progress: { max: 100, value: 40 },
      video: { src: '' }, audio: { src: '' }, web: { url: '' }
    }[type];
    Object.keys(def).forEach(function (k) { base[k] = def[k]; });
    var ns = naturalSize(type, base);           // 按自身内容给紧凑初始尺寸，不再一创建就占满整行
    base.w = ns.w; if (ns.h) base.h = ns.h;
    sc.components.unshift(base); state.selectedCompId = base.id;   // 新控件插到最上面
    renderCompList(); if (state.inLayout) renderLayout(); autosave();
  }
  function moveComp(idx, dir) {
    var arr = curScreen().components, j = idx + dir;
    if (j < 0 || j >= arr.length) return;
    var t = arr[idx]; arr[idx] = arr[j]; arr[j] = t;
    renderCompList(); if (state.inLayout) renderLayout(); autosave();
  }
  /* ================= 控件卡片：长按拖拽排序 ================= */
  var cardReorder = (function () {
    var dragId = null, endedAt = 0;
    return {
      active: function () { return !!dragId; },
      start: function (id) { dragId = id; },
      stop: function () { dragId = null; endedAt = Date.now(); },
      justEnded: function () { return Date.now() - endedAt < 450; }
    };
  })();
  // 长按排序期间禁止列表自身的触摸滚动（由我们接管手势）
  document.addEventListener('touchmove', function (e) {
    if (cardReorder.active() && e.target.closest && e.target.closest('#compList')) e.preventDefault();
  }, { passive: false, capture: true });
  function bindCardReorder(card, compId) {
    var box = $('compList');
    var armTimer = null, dragging = false, startX = 0, startY = 0, grabY = 0, ph = null, fromIdx = -1, edgeDir = 0, edgeRaf = 0;
    function clearArm() { if (armTimer) { clearTimeout(armTimer); armTimer = null; } }
    function beginDrag(downE) {
      var sc = curScreen();
      fromIdx = sc.components.findIndex(function (x) { return x.id === compId; });
      if (fromIdx < 0) return;
      dragging = true; cardReorder.start(compId);
      var r = card.getBoundingClientRect();
      grabY = startY - r.top;
      ph = el('div', 'compcard-reph');
      ph.style.height = r.height + 'px';
      card.classList.add('reordering');
      card.style.width = r.width + 'px';
      card.style.left = r.left + 'px';
      card.style.top = (downE.clientY - grabY) + 'px';
      box.appendChild(card);   // 卡片转 fixed 后置末，占位符接管原文档流位置
      box.insertBefore(ph, box.children[fromIdx] || null);
      try { if (navigator.vibrate) navigator.vibrate(15); } catch (err) {}
    }
    function onDown(e) {
      if (e.button !== undefined && e.button !== 0) return;
      if (e.target.closest && e.target.closest('button')) return;   // 显隐/删除按钮不触发
      if (document.querySelector('.mask:not(.hidden)')) return;
      dragging = false; edgeDir = 0;
      startX = e.clientX; startY = e.clientY;
      clearArm();
      armTimer = setTimeout(function () { beginDrag(e); }, 300);
      document.addEventListener('pointermove', onMove);
      document.addEventListener('pointerup', onUp, true);
      document.addEventListener('pointercancel', onUp, true);
    }
    function edgeTick() {
      if (!dragging || !edgeDir) { edgeRaf = 0; return; }
      box.scrollTop += edgeDir * 9;
      edgeRaf = requestAnimationFrame(edgeTick);
    }
    function onMove(e) {
      if (!dragging) {
        // 长按生效前手指移动超过阈值 => 判定为滚动列表，取消长按
        if (Math.abs(e.clientX - startX) > 9 || Math.abs(e.clientY - startY) > 9) clearArm();
        return;
      }
      e.preventDefault();
      card.style.top = (e.clientY - grabY) + 'px';
      var others = Array.prototype.slice.call(box.querySelectorAll('.compcard:not(.reordering)'));
      var target = others.length;
      for (var i = 0; i < others.length; i++) {
        var r = others[i].getBoundingClientRect();
        if (e.clientY < r.top + r.height / 2) { target = i; break; }
      }
      var ref = others[target] || card;   // 插到最后时位于 fixed 卡片之前
      // 其他卡片让位用 FLIP 动画平滑滑动，而不是瞬间跳动
      if (ph.nextSibling !== ref) {
        others.forEach(function (o) { o.style.transition = 'none'; });
        var first = others.map(function (o) { return o.getBoundingClientRect().top; });
        box.insertBefore(ph, ref);
        others.forEach(function (o) { o.style.transform = ''; });
        void box.offsetHeight;   // 强制 reflow，得到去 transform 后的新布局位置
        var last = others.map(function (o) { return o.getBoundingClientRect().top; });
        others.forEach(function (o, i) {
          var d = first[i] - last[i];
          if (Math.abs(d) > 0.5) o.style.transform = 'translateY(' + d + 'px)';
        });
        requestAnimationFrame(function () {
          requestAnimationFrame(function () {
            others.forEach(function (o) {
              o.style.transition = 'transform .22s cubic-bezier(.2,0,0,1)';
              o.style.transform = '';
            });
          });
        });
      }
      var br = box.getBoundingClientRect();
      edgeDir = e.clientY < br.top + 34 ? -1 : (e.clientY > br.bottom - 34 ? 1 : 0);
      if (edgeDir && !edgeRaf) edgeRaf = requestAnimationFrame(edgeTick);
    }
    function onUp() {
      document.removeEventListener('pointermove', onMove);
      document.removeEventListener('pointerup', onUp, true);
      document.removeEventListener('pointercancel', onUp, true);
      clearArm();
      if (edgeRaf) { cancelAnimationFrame(edgeRaf); edgeRaf = 0; }
      if (dragging) {
        var toIdx = Array.prototype.indexOf.call(box.children, ph);
        var lastIdx = box.children.length - 1;   // 末尾是 fixed 的拖拽卡片
        if (toIdx > lastIdx) toIdx = lastIdx;
        var sc = curScreen();
        if (toIdx >= 0 && toIdx !== fromIdx && fromIdx >= 0) {
          var item = sc.components.splice(fromIdx, 1)[0];
          sc.components.splice(toIdx, 0, item);
        }
        cardReorder.stop();
        renderCompList(); if (state.inLayout) renderLayout(); autosave();
      }
      dragging = false;
    }
    card.addEventListener('pointerdown', onDown, true);
  }
  function delComp(id) {
    var arr = curScreen().components;
    for (var i = 0; i < arr.length; i++) if (arr[i].id === id) arr.splice(i, 1);
    if (state.selectedCompId === id) state.selectedCompId = null;
    renderCompList(); if (state.inLayout) renderLayout(); autosave();
  }
  function switchScreen(id) {
    saveCurrentWs(true);
    state.curScreenId = id; state.selectedCompId = null;
    renderTabs(); renderCompList();
    if (state.wsInited) loadScreenToWs(curScreen());
    autosave();
  }
  function addScreen() {
    saveCurrentWs(true);
    var n = state.project.screens.length + 1, id = 's' + Date.now().toString(36);
    state.project.screens.push({ id: id, title: '页面' + n, components: [], blocksXml: '<xml xmlns="https://developers.google.com/blockly/xml"></xml>' });
    switchScreen(id);
  }
  function deleteScreen() {
    var screens = state.project.screens;
    if (screens.length <= 1) { modal('无法删除', '至少要保留一个页面。'); return; }
    var cur = curScreen();
    var msg = el('div'); msg.appendChild(document.createTextNode('确定删除页面「'));
    msg.appendChild(el('span', 'confirm-name', cur.title || cur.id));
    msg.appendChild(document.createTextNode('」及其全部组件和积木？'));
    confirmDialog({ title: '删除页面', msg: msg, okText: '删除' }).then(function (yes) {
      if (!yes) return;
      saveCurrentWs(true);
      var idx = screens.indexOf(cur);
      screens.splice(idx, 1);
      // 其他页面“跳转到页面”积木若指向被删页，改写为第一个页面，避免运行时静默跳不到
      var fallback = screens[0].id;
      screens.forEach(function (s) {
        if (!s.blocksXml) return;
        s.blocksXml = s.blocksXml.replace(new RegExp('(<field name="PAGE">)' + cur.id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(</field>)', 'g'), '$1' + fallback + '$2');
      });
      var next = screens[Math.max(0, idx - 1)];
      state.project.startScreen = screens[0].id;
      state.curScreenId = next.id; state.selectedCompId = null;
      renderTabs(); renderCompList();
      if (state.wsInited) loadScreenToWs(next);
      autosave();
    });
  }

  /* ---------------- 属性面板（schema 化：内容/位置大小/样式） ---------------- */
  function ppField(labelText, input) {
    var f = el('div', 'pp-field'); f.appendChild(el('span', null, labelText)); f.appendChild(input); return f;
  }
  function txtInput(value, ph, oninput) {
    var i = el('input'); i.type = 'text'; i.value = value || ''; if (ph) i.placeholder = ph;
    i.addEventListener('input', function () { oninput(i.value); });
    return i;
  }
  function numInput(value, ph, oninput) {
    var i = el('input'); i.type = 'number'; i.value = value == null ? '' : value; if (ph) i.placeholder = ph;
    i.addEventListener('input', function () {
      var raw = (i.value || '').trim();
      if (raw === '') { oninput(null); return; }            // 留空=自动，不影响其它参数
      var n = Number(raw);
      oninput(isFinite(n) ? Math.round(n) : null);          // 非法数字按空处理，避免 NaN 拖垮组件
    });
    return i;
  }
  function areaInput(value, oninput) {
    var a = el('textarea'); a.value = value || '';
    a.addEventListener('input', function () { oninput(a.value); });
    return a;
  }
  function colorInput(value, fallback, oninput) {
    // M3 色块（点击弹自研取色器，不再用系统原生 type=color）+ HEX 文本，二者都可靠生效
    var row = el('div', 'pp-color');
    var chip = el('button', 'cp-chip'); chip.type = 'button';
    function paint() {
      var v = normalizeHex(t.value) || normalizeHex(fallback);
      chip.style.background = v || 'var(--c-high)';
      chip.classList.toggle('empty', !v);
    }
    var t = el('input'); t.type = 'text'; t.value = value || ''; t.placeholder = fallback || '#000000';
    t.addEventListener('input', function () { oninput(t.value); paint(); });
    t.addEventListener('blur', function () {           // 失焦时把合法简写规范成 #RRGGBB
      var v = normalizeHex(t.value);
      if (v) { t.value = v; oninput(v); } paint();
    });
    chip.addEventListener('click', function () {
      pickColor(t.value || fallback).then(function (res) {
        if (res === null) return;                        // 取消：不变
        t.value = res; oninput(res || null); paint();    // '' = 恢复默认（清除）
      });
    });
    paint();
    row.appendChild(chip); row.appendChild(t); return row;
  }
  function segInput(options, value, oninput) {
    var wrap = el('div', 'pp-seg');
    options.forEach(function (op) {
      var b = el('button', (value || options[0][1]) === op[1] ? 'on' : '', op[0]);
      b.addEventListener('click', function () {
        oninput(op[1]); Array.prototype.forEach.call(wrap.children, function (x) { x.classList.remove('on'); });
        b.classList.add('on');
      });
      wrap.appendChild(b);
    });
    return wrap;
  }
  function sec(title) { return el('div', 'pp-sec', title); }

  // 属性字段构建（右侧属性栏与布局视图底部控制台共用）
  // afterEdit：每次改值后的轻量刷新；rebuild：需要整体重建（换图/复位）时调用
  function fillPropFields(host, c, afterEdit, rebuild, showVis) {
    var mark = function (fn) { return function (v) { fn(v); autosave(); afterEdit && afterEdit(); }; };

    host.appendChild(sec('基础'));
    host.appendChild(ppField('组件名称', txtInput(c.name || '', TYPE_META[c.type].label + ' (' + c.id + ')', mark(function (v) { c.name = v; }))));

    /* 内容 */
    host.appendChild(sec('内容'));
    if (c.type === 'text') host.appendChild(ppField('显示文字', areaInput(c.value, mark(function (v) { c.value = v; }))));
    if (c.type === 'button') {
      host.appendChild(ppField('按钮文字', txtInput(c.text, '按钮', mark(function (v) { c.text = v; }))));
      host.appendChild(ppField('按钮图标（emoji，可空）', txtInput(c.icon, '如 ✓、🔍', mark(function (v) { c.icon = v; }))));
    }
    if (c.type === 'input') {
      host.appendChild(ppField('提示文字（灰色占位）', txtInput(c.hint, '请输入', mark(function (v) { c.hint = v; }))));
      host.appendChild(ppField('默认内容（可空）', txtInput(c.value, '', mark(function (v) { c.value = v; }))));
    }
    if (c.type === 'list') host.appendChild(ppField('列表项（每行一个）', areaInput((c.items || []).join('\n'), mark(function (v) { c.items = v.split('\n'); }))));
    if (c.type === 'image') {
      host.appendChild(ppField('占位说明', txtInput(c.alt, '图片', mark(function (v) { c.alt = v; }))));
      var upBtn = el('button', 'small', c.src ? '更换图片' : '上传图片');
      var finp = el('input'); finp.type = 'file'; finp.accept = 'image/*'; finp.className = 'hidden';
      finp.addEventListener('change', function () { pickImage(finp, function (url) { c.src = url; autosave(); rebuild && rebuild(); }); });
      upBtn.addEventListener('click', function () { finp.click(); });
      var row = el('div', 'pp-row2'); var f = el('div', 'pp-field'); f.appendChild(upBtn); f.appendChild(finp); row.appendChild(f);
      if (c.src) { var clr = el('button', 'small', '移除图片'); clr.addEventListener('click', mark(function () { c.src = null; rebuild && rebuild(); })); var f2 = el('div', 'pp-field'); f2.appendChild(clr); row.appendChild(f2); }
      host.appendChild(row);
    }

    if (c.type === 'switch' || c.type === 'checkbox') {
      host.appendChild(ppField('标签文字', txtInput(c.text || '', c.type === 'switch' ? '开关' : '复选项', mark(function (v) { c.text = v; }))));
      host.appendChild(ppField('初始状态', segInput([['未勾选', false], ['已勾选', true]], !!c.checked, mark(function (v) { c.checked = v; }))));
    }
    if (c.type === 'slider') {
      var slRow = el('div', 'pp-row2');
      slRow.appendChild(ppField('最小值', numInput(c.min, '0', mark(function (v) { c.min = v; }))));
      slRow.appendChild(ppField('最大值', numInput(c.max, '100', mark(function (v) { c.max = v; }))));
      host.appendChild(slRow);
      host.appendChild(ppField('默认数值', numInput(c.value, '0', mark(function (v) { c.value = v; }))));
    }
    if (c.type === 'progress') {
      var pgRow = el('div', 'pp-row2');
      pgRow.appendChild(ppField('最大值', numInput(c.max, '100', mark(function (v) { c.max = v; }))));
      pgRow.appendChild(ppField('当前进度', numInput(c.value, '0', mark(function (v) { c.value = v; }))));
      host.appendChild(pgRow);
    }
    if (c.type === 'video' || c.type === 'audio') {
      var isVid = c.type === 'video';
      host.appendChild(ppField(isVid ? '视频地址（网络链接，留空用本地）' : '音频地址（网络链接，留空用本地）',
        txtInput(c.src, isVid ? 'https://example.com/video.mp4' : 'https://example.com/audio.mp3', mark(function (v) { c.src = v; }))));
      var upBtn = el('button', 'small', isVid ? '选择本地视频' : '选择本地音频');
      upBtn.addEventListener('click', function () {
        if (!window.Native || !Native.pickMedia) { snack('本地上传需在安卓 App 内使用'); return; }
        state.pendingMediaCompId = c.id;
        Native.pickMedia(isVid ? 'video' : 'audio');
      });
      var upf = el('div', 'pp-field'); upf.appendChild(upBtn); host.appendChild(upf);
    }
    if (c.type === 'web') host.appendChild(ppField('网页网址（https://）', txtInput(c.url, 'https://example.com', mark(function (v) { c.url = v; }))));

    /* 位置与大小 */
    host.appendChild(sec('位置与大小（留空=自动排列）'));
    var posRow = el('div', 'pp-row2');
    posRow.appendChild(ppField('X 距左(px)', numInput(c.x, '自动', mark(function (v) { c.x = v; }))));
    posRow.appendChild(ppField('Y 距顶(px)', numInput(c.y, '自动', mark(function (v) { c.y = v; }))));
    host.appendChild(posRow);
    var sizeRow = el('div', 'pp-row2');
    sizeRow.appendChild(ppField('宽度(px)', numInput(c.w, '自适应', mark(function (v) { c.w = v; }))));
    if (c.type !== 'list') sizeRow.appendChild(ppField('高度(px)', numInput(c.h, '自适应', mark(function (v) { c.h = v; }))));
    host.appendChild(sizeRow);
    var resetPos = el('button', 'small', '恢复自动排列');
    resetPos.addEventListener('click', mark(function () { c.x = c.y = c.w = c.h = null; rebuild && rebuild(); }));
    var rp = el('div', 'pp-field'); rp.appendChild(resetPos); host.appendChild(rp);

    /* 样式 */
    host.appendChild(sec('样式'));
    var fsRow = el('div', 'pp-row2');
    fsRow.appendChild(ppField('字号(px)', numInput(c.fs, '默认', mark(function (v) { c.fs = v; }))));
    fsRow.appendChild(ppField('圆角(px)', numInput(c.radius, '默认', mark(function (v) { c.radius = v; }))));
    host.appendChild(fsRow);
    host.appendChild(ppField('文字颜色', colorInput(c.color, c.type === 'button' ? '#ffffff' : '#1f2329', mark(function (v) { c.color = v; }))));
    if (c.type === 'button' || c.type === 'input' || c.type === 'list'
      || c.type === 'switch' || c.type === 'checkbox' || c.type === 'slider' || c.type === 'progress') {
      var bgFallback = (c.type === 'button' || c.type === 'switch' || c.type === 'checkbox' || c.type === 'slider' || c.type === 'progress') ? '#6750a4'
        : '#ffffff';
      host.appendChild(ppField('背景颜色', colorInput(c.bg, bgFallback, mark(function (v) { c.bg = v; }))));
    }
    host.appendChild(ppField('对齐方式', segInput([['左', 'left'], ['中', 'center'], ['右', 'right']], c.align, mark(function (v) { c.align = v; }))));
    host.appendChild(ppField('加粗', segInput([['正常', false], ['加粗', true]], c.bold, mark(function (v) { c.bold = v; }))));
    // “初始可见”仅保留在拖动布局控制台；设计页已把隐藏开关放到卡片眼睛上，故详情面板不再显示
    if (showVis !== false)
      host.appendChild(ppField('初始可见', segInput([['显示', true], ['隐藏', false]], c.visible === false ? false : true, mark(function (v) { c.visible = v; }))));
    host.appendChild(ppField('透明度（0全透~100不透明）', numInput(validN(c.opacity) ? c.opacity : 100, '100', mark(function (v) { c.opacity = v; }))));

    var acts = el('div', 'pp-actions');
    var del = el('button', 'danger', '删除该组件');
    del.addEventListener('click', function () { delComp(c.id); });
    acts.appendChild(del); host.appendChild(acts);
  }

  function renderPropPanel() {
    var panel = $('propPanel'), c = selectedComp();
    if (!c) { panel.classList.add('hidden'); panel.innerHTML = ''; return; }
    panel.classList.remove('hidden'); panel.innerHTML = '';
    var head = el('div', 'pp-head');
    head.appendChild(el('h4', null, '编辑 · ' + compName(c)));
    var x = el('button', 'pp-close', '✕');
    x.title = '关闭';
    x.addEventListener('click', function () { state.selectedCompId = null; renderCompList(); });
    head.appendChild(x); panel.appendChild(head);
    var body = el('div', 'pp-body');
    panel.appendChild(body);
    fillPropFields(body, c, function () {
      var idx = curScreen().components.indexOf(c);
      var cards = $('compList').querySelectorAll('.compcard');
      if (cards[idx]) { var t1 = cards[idx].querySelector('.t1'), t2 = cards[idx].querySelector('.t2'); if (t1) t1.textContent = compName(c); if (t2) t2.textContent = compDesc(c); }
      var hh = panel.querySelector('.pp-head h4'); if (hh) hh.textContent = '编辑 · ' + compName(c);
    }, renderPropPanel, false);
  }

  /* 选择图片并压缩为 dataURL（正方形上限 256，控制工程体积） */
  function pickImage(input, cb) {
    var f = input.files && input.files[0]; if (!f) return;
    var reader = new FileReader();
    reader.onload = function () {
      var img = new Image();
      img.onload = function () {
        var side = Math.max(img.width, img.height), max = 256, scale = Math.min(1, max / side);
        var w = Math.round(img.width * scale), h = Math.round(img.height * scale);
        var cv = document.createElement('canvas'); cv.width = w; cv.height = h;
        cv.getContext('2d').drawImage(img, 0, 0, w, h);
        cb(cv.toDataURL('image/png'));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(f);
  }

  /* ---------------- 自定义渲染器 fastzelos ---------------------------------------
     形态语言：语句积木 = 左边一条直线、右端整端半圆（D 形）；上下堆叠边铺平无卡扣；
     半包围（C 形）积木脊柱与底边纤细、臂端圆润；值积木保持药丸/圆槽。 ---------------- */
  var FAST_RENDERER_REGISTERED = false;
  function registerFastRenderer() {
    if (FAST_RENDERER_REGISTERED || !window.Blockly || !Blockly.zelos) return;
    var z = Blockly.zelos;
    var P = Blockly.utils.svgPaths;
    var T = Blockly.blockRendering.Types;
    var R_CAP = 20;        // 右端半圆角半径（= 单行语句块半高，上下弧正好相接）
    var R_INSIDE = 8;      // C 形开口内凹角半径（小而圆，臂更纤细）
    var NOTCH_W = 8;       // 语句连接齿宽（视觉已铺平，仅保留布局所需小尺寸，C 形脊柱随之变细）
    var CORNER_KEEP_H = 8; // 右端圆角在顶/底行保留的高度（块高维持原值，半圆与内容同心）
    class FastConstants extends z.ConstantProvider {
      init() {
        super.init();
        this.CORNER_RADIUS = R_CAP;                       // 外角半径（右圆角 measurable 取此值）
        this.INSIDE_R = R_INSIDE;
        this.NOTCH_WIDTH = NOTCH_W;
        this.NOTCH_OFFSET_LEFT = 12;
        this.STATEMENT_INPUT_PADDING_LEFT = 8;
        this.BOTTOM_ROW_AFTER_STATEMENT_MIN_HEIGHT = 12;  // C 形底臂更薄
        this.EMPTY_STATEMENT_INPUT_HEIGHT = 16;           // 空开口高度
        this.NOTCH = this.makeNotch();
        this.INSIDE_CORNERS = this.makeInsideCorners();
        this.OUTSIDE_CORNERS = this.makeOutsideCorners();
        // 派生常量：zelos 在 init 末尾按内凹角推导，主题应用后可能被置空，必须显式重设（探针标定值）
        this.STATEMENT_INPUT_NOTCH_OFFSET = 16;
        // 事件帽：完全平顶（高度0），左端凸出圆钮交给 drawLeft_ 绘制
        this.START_HAT_HEIGHT = 0;
        this.START_HAT = this.makeStartHat();
      }
      setDynamicProperties_(theme) {
        super.setDynamicProperties_(theme);
        this.STATEMENT_INPUT_NOTCH_OFFSET = 16;
      }
      // 铺平语句连接“卡扣”：凹凸曲线换成沿边缘的水平直线，视觉无卡扣
      makeNotch() {
        var n = super.makeNotch();
        n.pathLeft = P.lineOnAxis('h', n.width);
        n.pathRight = P.lineOnAxis('h', -n.width);
        return n;
      }
      // 内凹角用独立的小半径，不跟随外角大圆角
      makeInsideCorners() {
        var r = this.INSIDE_R;
        function a(flags, dx, dy) { return P.arc('a', '0 0,' + flags, r, P.point(dx, dy)); }
        return {
          width: r, height: r, rightWidth: r, rightHeight: r,
          pathTop: a(0, -r, r), pathBottom: a(0, r, r),
          pathTopRight: a(1, -r, r), pathBottomRight: a(1, r, r)
        };
      }
      // 外角：左侧完全直角（空路径）；右侧整端半圆
      makeOutsideCorners() {
        var r = R_CAP;
        var topRight = P.arc('a', '0 0,1', r, P.point(r, r));
        var bottomRight = P.arc('a', '0 0,1', r, P.point(-r, r));
        return { topLeft: '', topRight: topRight, bottomRight: bottomRight, bottomLeft: '', rightHeight: r, leftHeight: 0 };
      }
      // 值连接统一为圆润槽：布尔（六边形）也改成圆角，语言统一柔和
      shapeFor(conn) {
        if (conn && (conn.type === Blockly.ConnectionType.INPUT_VALUE || conn.type === Blockly.ConnectionType.OUTPUT_VALUE)) {
          return this.ROUNDED;
        }
        return super.shapeFor(conn);
      }
    }
    // 语句积木（无输出口）左角一律为方角；帽子曲线由 Hat 元素自行绘制
    class FastTopRow extends z.TopRow {
      hasLeftSquareCorner(b) { return b.outputConnection ? super.hasLeftSquareCorner(b) : true; }
    }
    class FastBottomRow extends z.BottomRow {
      hasLeftSquareCorner(b) { return b.outputConnection ? super.hasLeftSquareCorner(b) : true; }
    }
    class FastRenderInfo extends z.RenderInfo {
      constructor(renderer, block) {
        super(renderer, block);
        this.topRow = new FastTopRow(this.constants_);
        this.bottomRow = new FastBottomRow(this.constants_);
      }
      // 右端半圆只占横向空间，纵向不把行撑高（块高维持原值，半圆与内容同心）
      shrinkRightCorners() {
        [this.topRow.elements, this.bottomRow.elements].forEach(function (els) {
          for (var i = 0; i < els.length; i++) {
            if (T.isRightRoundedCorner(els[i])) els[i].height = CORNER_KEEP_H;
          }
        });
      }
      populateTopRow_() {
        super.populateTopRow_();
        this.shrinkRightCorners();
        // 帽块：标题行压到和普通单行积木一样扁
        if (this.block_.hat === 'cap') {
          this.topRow.height -= 12;
        }
      }
      populateBottomRow_() { super.populateBottomRow_(); this.shrinkRightCorners(); }
      // 半包围（C 形）开口下方横条做细：压缩 statement 之后的 spacer，让底臂贴近开口
      finalize_() {
        for (var i = 0; i < this.rows.length; i++) {
          var r = this.rows[i];
          if (r && r.followsStatement && T.isSpacer(r)) r.height = 3;
        }
        super.finalize_();
      }
    }
    // 轮廓绘制：消除右半圆外的竖线毛刺、统一堆叠连接点、C 形细底臂
    class FastDrawer extends z.Drawer {
      // 上连接点 x = NOTCH_OFFSET_LEFT；下连接点默认取齿 measurable 左缘（窄齿后偏小），
      // 两者不一致会让每向下叠一块就向左错位，这里强制对齐到同一 x。
      positionNextConnection_() {
        super.positionNextConnection_();
        var br = this.info_.bottomRow;
        if (br.connection) {
          br.connection.connectionModel.setOffsetInBlock(this.constants_.NOTCH_OFFSET_LEFT, br.baseline);
        }
      }
      // 复刻 common.drawTop_，但去掉结尾的 v(topRow.height)：右半圆半径(24)大于圆角行
      // 预留高度(8)，那段竖线会画在圆弧之外，在每个块的右下方戳出一小段“毛刺”。
      drawTop_() {
        if (this.block_.outputConnection || this.block_.hat === 'cap') return super.drawTop_();
        var topRow = this.info_.topRow, els = topRow.elements;
        this.positionPreviousConnection_();
        var d = P.moveBy(topRow.xPos, this.info_.startY);
        for (var i = 0, e; (e = els[i]); i++) {
          if (T.isLeftRoundedCorner(e)) d += this.constants_.OUTSIDE_CORNERS.topLeft;
          else if (T.isRightRoundedCorner(e)) d += this.constants_.OUTSIDE_CORNERS.topRight;
          else if (T.isPreviousConnection(e)) d += e.shape.pathLeft;
          else if (T.isHat(e)) d += e.shape.path;
          else if (T.isSpacer(e)) d += P.lineOnAxis('h', e.width);
        }
        this.outlinePath_ += d;
      }
      // 中间行：简单 D 形语句块的输入行不再逐行画右侧竖边（右端由上下两个半圆包住，
      // 逐行 V 会在圆弧外戳出毛刺）；C 形块上臂的输入行仍要画竖边把开口压到正确高度。
      drawRightSideRow_(row) {
        var b = this.block_;
        if (b.outputConnection || b.statementInputCount || T.isSpacer(row)) {
          return super.drawRightSideRow_(row);
        }
      }
      // 每次渲染后，给事件帽块左端叠加独立圆钮（与"当开始被点击"一致：
      // 同色外圆 + 白色小圆 + 同色播放三角）。用独立 SVG 元素避开主 path 的 evenodd 填充。
      draw() {
        super.draw();
        var b = this.block_;
        var g = b.getSvgRoot ? b.getSvgRoot() : b.svgRoot_;
        if (b.hat === 'cap' && !b.outputConnection && g) {
          var SVGNS = 'http://www.w3.org/2000/svg';
          var knob = g.querySelector('.hat-knob');
          var R = 30;                       // 圆钮半径，直径大于标题条高，圆凸出条顶条底
          var cy = 26;
          if (!knob) {
            knob = document.createElementNS(SVGNS, 'g');
            knob.setAttribute('class', 'hat-knob');
            var outer = document.createElementNS(SVGNS, 'circle');
            outer.setAttribute('class', 'hat-knob-outer');
            var ring = document.createElementNS(SVGNS, 'circle');
            ring.setAttribute('class', 'hat-knob-ring');
            var tri = document.createElementNS(SVGNS, 'polygon');
            tri.setAttribute('class', 'hat-knob-tri');
            knob.appendChild(outer);
            knob.appendChild(ring);
            knob.appendChild(tri);
            // 插到主填充路径之后、文字层之前
            var mainPath = g.querySelector('.blocklyPath');
            if (mainPath && mainPath.nextSibling) g.insertBefore(knob, mainPath.nextSibling);
            else g.appendChild(knob);
          }
          var color = b.getColour();
          var o = knob.querySelector('.hat-knob-outer');
          o.setAttribute('cx', -6); o.setAttribute('cy', cy); o.setAttribute('r', R);
          o.setAttribute('fill', color); o.removeAttribute('stroke');
          var ring = knob.querySelector('.hat-knob-ring');
          ring.setAttribute('cx', -6); ring.setAttribute('cy', cy); ring.setAttribute('r', R * 0.62);
          ring.setAttribute('fill', '#ffffff'); ring.removeAttribute('stroke');
          // 同色播放三角，居中于圆心，指向右
          var t = knob.querySelector('.hat-knob-tri');
          var xL = -R * 0.18, xR = R * 0.18, yH = R * 0.28;
          t.setAttribute('points', (-6 + xL) + ',' + (cy - yH) + ' ' + (-6 + xL) + ',' + (cy + yH) + ' ' + (-6 + xR) + ',' + cy);
          t.setAttribute('fill', color);
        }
      }
      drawLeft_() {
        super.drawLeft_();
      }
      // C 形积木底臂较薄，臂端圆角按臂厚自适应（简单语句块走 r=R_CAP 的整端半圆）
      drawBottom_() {
        var info = this.info_, b = this.block_;
        if (!b.statementInputCount) return super.drawBottom_();
        var armTopY = null;
        for (var i = 0; i < info.rows.length; i++) {
          var rw = info.rows[i];
          if (T.isSpacer(rw) && rw.followsStatement) armTopY = rw.yPos;
        }
        var baseline = info.bottomRow.baseline;
        // 底横条做细：端圆角半径固定取小值，臂厚≈侧边竖条，不再随开口下方空间变粗
        var rArm = 7;
        this.positionNextConnection_();
        var tail = '';
        var els = info.bottomRow.elements;
        for (var j = els.length - 1, el; (el = els[j]); j--) {
          if (T.isNextConnection(el)) tail += el.shape.pathRight;
          else if (T.isLeftSquareCorner(el)) tail += P.lineOnAxis('H', info.bottomRow.xPos);
          else if (T.isLeftRoundedCorner(el)) tail += this.constants_.OUTSIDE_CORNERS.bottomLeft;
          else if (T.isRightRoundedCorner(el)) tail += P.arc('a', '0 0,1', rArm, P.point(-rArm, rArm));
          else if (T.isSpacer(el)) tail += P.lineOnAxis('h', -el.width);
        }
        this.outlinePath_ += P.lineOnAxis('V', baseline - rArm) + tail;
      }
    }
    class FastRenderer extends z.Renderer {
      makeConstants_() { return new FastConstants(); }
      makeRenderInfo_(block) { return new FastRenderInfo(this, block); }
      makeDrawer_(block, info) { return new FastDrawer(block, info); }
    }
    Blockly.blockRendering.register('fastzelos', FastRenderer);
    FAST_RENDERER_REGISTERED = true;
  }

  /* 稳定的双指缩放：内置 pinch 在真机上会与单指拖块/平移手势竞争，两指状态切换时画面在
     缩放与平移间来回跳（“闪来闪去”）。这里在 document 捕获阶段统一接管多指：第二指落下即
     取消 Blockly 当前手势，随后的多指移动全部由我们以双指中点为锚缩放，并屏蔽 Blockly 的移动；
     单指完全不干预（拖块、平移画布照旧）。 */
  function setupCustomPinch(ws) {
    if (ws.__pinchBound) return; ws.__pinchBound = true;
    var host = $('blocklyDiv');
    var pts = new Map();
    var pinch = null;
    function inControl(n) {
      return n && n.closest && (n.closest('#bbZoom') || n.closest('#bbCats') ||
        n.closest('.blocklyFlyout') || n.closest('.blocklyToolboxDiv') || n.closest('.mask'));
    }
    function pos(e) { var r = host.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
    function dist(a, b) { return Math.hypot(a.x - b.x, a.y - b.y); }
    function midp(a, b) { return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }; }
    function onDown(e) {
      if (state.view !== 'blocks' || inControl(e.target)) return;
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      pts.set(e.pointerId, pos(e));
      if (pts.size === 2 && !pinch) {
        try { ws.cancelCurrentGesture(); } catch (err) {}   // 终止第一指可能正在进行的拖块/平移
        var v = Array.from(pts.values());
        pinch = { d: dist(v[0], v[1]), m: midp(v[0], v[1]) };
        try { if (navigator.vibrate) navigator.vibrate(8); } catch (err) {}
      }
    }
    function onMove(e) {
      if (!pts.has(e.pointerId)) return;
      pts.set(e.pointerId, pos(e));
      if (pinch && pts.size >= 2) {
        e.preventDefault(); e.stopImmediatePropagation();   // 屏蔽 Blockly 的平移/拖块，避免打架
        var v = Array.from(pts.values());
        var nd = dist(v[0], v[1]), nm = midp(v[0], v[1]);
        if (pinch.d > 1) {
          var ratio = nd / pinch.d;
          var speed = (ws.options.zoomOptions && ws.options.zoomOptions.scaleSpeed) || 1.03;
          var amount = Math.log(ratio) / Math.log(speed);
          if (isFinite(amount) && Math.abs(amount) > 1e-6) {
            try { ws.zoom(nm.x, nm.y, amount); } catch (err) {}
          }
        }
        pinch.d = nd; pinch.m = nm;
      }
    }
    function onUp(e) {
      if (!pts.has(e.pointerId)) return;
      var wasPinch = !!pinch;
      pts.delete(e.pointerId);
      if (pinch && pts.size < 2) {
        pinch = null;
        if (wasPinch) { try { recordZoom(); } catch (err) {} }
      }
    }
    document.addEventListener('pointerdown', onDown, { capture: true, passive: true });
    document.addEventListener('pointermove', onMove, { capture: true, passive: false });
    document.addEventListener('pointerup', onUp, { capture: true, passive: true });
    document.addEventListener('pointercancel', onUp, { capture: true, passive: true });
  }

  /* ---------------- 长按积木：复制/删除（含整条往下链） ---------------- */
  function bindBlockLongPress(ws) {
    if (ws.__longPressBound) return; ws.__longPressBound = true;
    var host = $('blocklyDiv');
    var lpTimer = null, lpBlock = null, lpX = 0, lpY = 0, lpFired = false;
    var LONG_MS = 480, MOVE_TOL = 12;

    function blockFromNode(node) {
      var g = node && node.closest ? node.closest('.blocklyDraggable') : null;
      if (!g || g.closest('.blocklyFlyout') || g.closest('.blocklyToolboxDiv')) return null;
      var all = ws.getAllBlocks(false);
      for (var i = 0; i < all.length; i++) { try { if (all[i].getSvgRoot() === g) return all[i]; } catch (e) {} }
      return null;
    }
    // 沿 next 链向下数顶层块数（含起点；半包围内部只随其所属块整体计数，不穿出半包围）
    function countChain(b) {
      var n = 0;
      while (b) { n++; b = b.getNextBlock ? b.getNextBlock() : null; }
      return n;
    }
    function clearTimer() { if (lpTimer) { clearTimeout(lpTimer); lpTimer = null; } }

    function ensureMenu() {
      var mask = $('blockActionMask');
      if (mask) return mask;
      mask = el('div', 'mask hidden'); mask.id = 'blockActionMask';
      var sheet = el('div', 'action-sheet');
      sheet.appendChild(el('div', 'as-title', '积木操作'));
      var defs = [
        ['baCopyBelow', '', '复制以下积木'],
        ['baCopyOne', '', '复制此单个积木'],
        ['baDelBelow', 'danger', '删除以下积木'],
        ['baDelOne', 'danger', '删除此单个积木'],
        ['baCancel', 'as-cancel', '取消']
      ];
      defs.forEach(function (d) {
        var btn = el('button', d[1], d[2]); btn.type = 'button'; btn.id = d[0];
        sheet.appendChild(btn);
      });
      mask.appendChild(sheet);
      document.body.appendChild(mask);
      mask.addEventListener('pointerdown', function (e) { if (e.target === mask) closeMenu(); });
      $('baCancel').addEventListener('click', closeMenu);
      return mask;
    }
    function closeMenu() { var m = $('blockActionMask'); if (m) m.classList.add('hidden'); lpBlock = null; }

    function openMenu(block) {
      var mask = ensureMenu();
      var n = countChain(block);
      $('baCopyBelow').textContent = '复制以下积木（' + n + ' 个）';
      $('baDelBelow').textContent = '删除以下积木（' + n + ' 个）';
      mask.classList.remove('hidden');
    }

    // 复制：single=true 只复制当前块（去掉 next 链与半包围内部）；否则复制当前块及整条往下链（含内部）
    function doCopy(block, single) {
      try { ws.hideChaff(); } catch (e) {}
      var dom = B.Xml.blockToDomWithXY(block);
      if (single) {
        ['next', 'statement'].forEach(function (tag) {
          var nodes = dom.getElementsByTagName(tag);
          for (var k = nodes.length - 1; k >= 0; k--) nodes[k].parentNode.removeChild(nodes[k]);
        });
      }
      var nb = B.Xml.domToBlock(dom, ws);
      try {
        var xy = block.getRelativeToSurfaceXY();
        nb.moveBy(xy.x + 26, xy.y + 26);
      } catch (e) {}
      try { nb.select(); } catch (e) {}
      autosave(); snack(single ? '已复制此积木' : '已复制 ' + countChain(block) + ' 个积木');
    }
    function doDelete(block, single) {
      var n = countChain(block);
      try { ws.hideChaff(); } catch (e) {}
      try { block.dispose(!!single); } catch (e) { try { block.dispose(false); } catch (e2) {} }
      autosave(); snack(single ? '已删除此积木' : '已删除 ' + n + ' 个积木');
    }

    host.addEventListener('pointerdown', function (e) {
      if (state.view !== 'blocks') return;
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      var b = blockFromNode(e.target);
      if (!b || b.isInFlyout || b.isShadow()) { lpBlock = null; return; }
      lpBlock = b; lpFired = false; lpX = e.clientX; lpY = e.clientY;
      clearTimer();
      lpTimer = setTimeout(function () {
        if (!lpBlock) return;
        lpFired = true;
        try { if (navigator.vibrate) navigator.vibrate(12); } catch (e) {}
        try { ws.cancelCurrentGesture && ws.cancelCurrentGesture(); } catch (e) {}
        openMenu(lpBlock);
      }, LONG_MS);
    }, true);
    host.addEventListener('pointermove', function (e) {
      if (lpTimer && lpBlock && (Math.abs(e.clientX - lpX) > MOVE_TOL || Math.abs(e.clientY - lpY) > MOVE_TOL)) {
        clearTimer(); lpBlock = null;
      }
    }, true);
    function onEnd() { clearTimer(); }
    host.addEventListener('pointerup', onEnd, true);
    host.addEventListener('pointercancel', onEnd, true);

    // 菜单按钮（每次点击时按当前 lpBlock 操作）
    ensureMenu();
    $('baCopyBelow').addEventListener('click', function () { if (lpBlock) doCopy(lpBlock, false); closeMenu(); });
    $('baCopyOne').addEventListener('click', function () { if (lpBlock) doCopy(lpBlock, true); closeMenu(); });
    $('baDelBelow').addEventListener('click', function () { if (lpBlock) doDelete(lpBlock, false); closeMenu(); });
    $('baDelOne').addEventListener('click', function () { if (lpBlock) doDelete(lpBlock, true); closeMenu(); });
  }

  /* ---------------- Blockly（加固：尺寸观测 + 多重 resize 兜底，杜绝空白） ---------------- */
  function initWorkspace() {
    if (state.wsInited) return;
    registerFastRenderer();
    // 浮层（积木展示页）横/竖滚动条全局细化；主画布滚动条已用 CSS 隐藏
    try { if (B.Scrollbar && 'scrollbarThickness' in B.Scrollbar) B.Scrollbar.scrollbarThickness = 5; } catch (e) {}
    // 按工程实际用到的控件类型生成工具箱：没有该类控件就不显示对应分类
    var usedTypes = new Set();
    ((state.project && state.project.screens) || []).forEach(function (s) { (s.components || []).forEach(function (c) { if (c && c.type) usedTypes.add(c.type); }); });
    var opts = {
      toolbox: window.buildToolboxXml(usedTypes), renderer: 'fastzelos', theme: B.Themes.Zelos,
      grid: { spacing: 28, length: 1, colour: '#e3e6ea', snap: false },
      zoom: { controls: true, wheel: true, startScale: savedBlockScale(), maxScale: 2.0, minScale: 0.35, pinch: false },
      trashcan: false, move: { scrollbars: true, drag: true }, sounds: false, media: 'blockly/media/',
      modalInputs: true   // 数字/文本字段一律走 Blockly.dialog（已替换为 M3 弹窗），杜绝安卓原生 prompt
    };
    state.ws = B.inject('blocklyDiv', opts);
    state.wsInited = true;
    window.blocklyWs = state.ws;   // 调试/自动化测试句柄（只读使用，不影响功能）
    // 包装中心缩放：无论来自自定义按钮还是内部调用，缩放后都持久化（该方法不触发 viewport 事件）
    (function wrapZoom() {
      var ws = state.ws, orig = ws.zoomCenter ? ws.zoomCenter.bind(ws) : null;
      if (orig) ws.zoomCenter = function (dir) { var r = orig(dir); recordZoom(); return r; };
    })();
    setupCustomPinch(state.ws);   // 稳定的双指缩放（替代内置 pinch，避免真机缩放/平移手势竞争闪烁）
    bindBlockLongPress(state.ws); // 长按积木弹出复制/删除菜单
    // 分类浮层使用原生 autoClose：点选积木、把积木拖出、点画布空白都会关闭浮层并让出画布；
    // 可滚动的分类里，在积木上竖向拖动是滚动浮层，横向拖向画布才是取出积木（Blockly 原生判定）。
    try { var fl = state.ws.getFlyout && state.ws.getFlyout(); if (fl) fl.autoClose = true; } catch (e) {}
    bindDeleteOnDrag(state.ws);
    // “跳转到页面”积木拖出时，默认目标若落在当前页（=跳自己，运行时点了没反应），
    // 自动改成第一个其他页面；只有一个页面时保持默认。加载已保存工程/切页（loadingWs）不篡改。
    state.ws.addChangeListener(function (ev) {
      try {
        if (loadingWs || ev.type !== B.Events.BLOCK_CREATE) return;
        if (ev.workspaceId !== state.ws.id) return;   // 浮层/拖影等其他工作区的事件不处理
        var ids = ev.ids || (ev.blockId ? [ev.blockId] : []);
        ids.forEach(function (bid) {
          var b = state.ws.getBlockById(bid);
          if (!b || b.type !== 'act_goto' || b.isInFlyout) return;
          var cur = curScreen(), v = b.getFieldValue('PAGE');
          if (v && v !== 'NONE' && v !== cur.id) return;   // 已指向别的页面则不动
          var other = (state.project.screens || []).filter(function (s) { return s.id !== cur.id; });
          if (other.length) b.setFieldValue(other[0].id, 'PAGE', true);
        });
      } catch (e) {}
    });
    buildCategoryRail(state.ws);   // 自定义 M3 分类轨道（替代原生分类列，杜绝点按/滑动误判导致的“打不开”）
    // 云列表：动态分类浮层（创建/管理按钮 + 按已登记云表格生成积木）
    try {
      setupBlocklyDialogs();   // 安卓 WebView 下数字/文本编辑默认走原生 prompt，这里替换为 M3 弹窗
      state.ws.registerToolboxCategoryCallback('BB_CLOUD', function () { return window.BB_cloudFlyout(state.ws); });
      state.ws.registerButtonCallback('BB_CLOUD_CREATE', function () {
        try { state.ws.hideChaff(); } catch (e) {}
        try { state.ws.getToolbox().clearSelection(); } catch (e) {}
        openCloudCreate(null);
      });
      state.ws.registerButtonCallback('BB_CLOUD_MANAGE', function () {
        try { state.ws.hideChaff(); } catch (e) {}
        try { state.ws.getToolbox().clearSelection(); } catch (e) {}
        openCloudManage();
      });
    } catch (e) { console.error('cloud category register', e); }
    // 点积木画布空白处：收起分类浮层、下拉，并关闭“如果/否则”等蓝色齿轮弹出的设置框(mutator 气泡)
    function closeMutatorBubbles(ws) {
      try {
        ws.getAllBlocks(false).forEach(function (b) {
          try { if (b.mutator && b.mutator.bubbleIsVisible && b.mutator.bubbleIsVisible()) b.mutator.setBubbleVisible(false); } catch (e) {}
        });
      } catch (e) {}
    }
    state.ws.closeMutatorBubbles = function () { closeMutatorBubbles(state.ws); };
    $('blocklyDiv').addEventListener('pointerdown', function (e) {
      // 浮层/工具箱/齿轮气泡本体(含其内部工作区与拖动表面)/下拉/缩放钮/齿轮图标自身不处理
      // （齿轮保留原生开-关切换）；mutator 小框内的一切拖动都不能触发关闭
      if (e.target.closest && e.target.closest('.blocklyToolboxDiv,.blocklyFlyout,.blocklyBubble,.blocklyBubbleCanvas,.blocklyMutatorBackground,.blocklyBlockDragSurface,.blocklyWidgetDiv,.blocklyDropDownDiv,.blocklyZoom,.blocklyIconGroup')) return;
      // 双保险：触点落在任意已打开气泡的屏幕范围内，也不关闭（真机上个别元素 closest 可能漏判）
      var insideBubble = false;
      try {
        Array.prototype.forEach.call(document.querySelectorAll('.blocklyBubbleCanvas'), function (g) {
          var r = g.getBoundingClientRect();
          if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) insideBubble = true;
        });
      } catch (err) {}
      if (insideBubble) return;
      try { state.ws.hideChaff(); } catch (err) {}
      clearRailActive();
      closeMutatorBubbles(state.ws);
    }, true);
    // 积木任何结构性变更都自动保存（选择/视口等 UI 事件除外），杜绝试运行返回后积木丢失
    state.ws.addChangeListener(function (e) {
      if (loadingWs || (e && e.isUiEvent)) return;
      autosave();
    });
    // 缩放比例持久化：滚轮/双指/缩放按钮改变视口后，防抖写入工程，重进/切页面不再复位
    var zoomSaveTimer = null;
    state.ws.addChangeListener(function (e) {
      if (!e || e.type !== 'viewport_change' || loadingWs) return;
      clearTimeout(zoomSaveTimer);
      zoomSaveTimer = setTimeout(function () {
        if (!state.project || !state.ws) return;
        var sc = state.ws.getScale();
        if (isFinite(sc) && sc >= 0.35 && sc <= 2.0 && Math.abs((state.project.blockZoom || DEFAULT_BLOCK_SCALE) - sc) > 0.001) {
          state.project.blockZoom = sc;
          try { localStorage.setItem(ZOOM_GLOBAL_KEY, String(sc)); } catch (e) {}
          autosave();
        }
      }, 250);
    });
    // 滚轮 / 双指缩放后持久化（冒泡阶段，Blockly 处理完已更新 scale）
    $('blocklyDiv').addEventListener('wheel', function () { recordZoom(); }, { passive: true });
    $('blocklyDiv').addEventListener('pointerup', function () { recordZoom(); }, { passive: true });
    $('blocklyDiv').addEventListener('pointercancel', function () { recordZoom(); }, { passive: true });
    loadScreenToWs(curScreen());
    // 容器尺寸变化即同步画布（旋转、显示切换、键盘弹起都覆盖）
    if (window.ResizeObserver) new ResizeObserver(function () { safeResize(); }).observe($('blocklyDiv'));
    window.addEventListener('resize', requestWsResize);
    window.addEventListener('orientationchange', function () { setTimeout(requestWsResize, 120); setTimeout(requestWsResize, 400); });
  }
  function safeResize() {
    if (!state.ws) return;
    var d = $('blocklyDiv');
    if (!d || d.clientWidth < 2 || d.clientHeight < 2) return; // 容器还没布局好，等下一次
    try { state.ws.resize(); } catch (e) {}
  }
  var resizeTimer = null;
  function requestWsResize() {
    safeResize();
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(safeResize, 60);
    setTimeout(safeResize, 220);
  }
  /* 工具箱“分类行”滑动 vs 轻点：
     Blockly 在 pointerdown 时就会选中分类，导致上下滑动分类列时误开别的分类。
     这里只拦截【左侧分类行】(.blocklyToolboxCategory)：
       - 按下先拦住 Blockly 的选中；
       - 移动超过阈值 => 判定为滑动（交给浏览器原生滚动），始终不选中；
       - 未移动就抬手 => 判定为轻点，直接用 Toolbox API 选中该分类。
     右侧积木浮层(.blocklyFlyout)与画布完全不干预；浮层另设 autoClose=false，
     保证浮层滚动不闪、积木可正常拖出、拖出后浮层常驻。 */
  function guardToolboxScroll() {
    var root = $('blocklyDiv'); if (!root || root.__tbGuarded) return;
    root.__tbGuarded = true;
    var active = false, moved = false, row = null, pid = -1, sx = 0, sy = 0;
    var TAP_SLOP = 9;
    function catRow(t) { return t && t.closest ? t.closest('.blocklyToolboxCategory') : null; }

    root.addEventListener('pointerdown', function (e) {
      var r = catRow(e.target);
      if (!r) { active = false; return; }          // 非分类行：画布/浮层/积木一律放行
      active = true; moved = false; row = r; pid = e.pointerId; sx = e.clientX; sy = e.clientY;
      e.stopPropagation();                          // 先拦住 Blockly 的“按下即选”
    }, true);

    root.addEventListener('pointermove', function (e) {
      if (!active || e.pointerId !== pid) return;
      if (Math.abs(e.clientX - sx) > TAP_SLOP || Math.abs(e.clientY - sy) > TAP_SLOP) moved = true;
    }, true);

    function selectCategory(target) {
      try {
        var tb = state.ws && state.ws.getToolbox && state.ws.getToolbox();
        if (!tb) return false;
        var item = null;
        if (tb.getToolboxItems) {
          var list = tb.getToolboxItems();
          for (var i = 0; i < list.length; i++) { if (list[i] && list[i].htmlDiv_ === target) { item = list[i]; break; } }
        }
        if (!item && target.id && tb.getToolboxItemById) item = tb.getToolboxItemById(target.id);
        if (item && (!item.isSelectable || item.isSelectable())) {
          // 再次点击已展开的分类 => 收起浮层；否则展开
          if (tb.getSelectedItem() === item) tb.clearSelection(); else tb.setSelectedItem(item);
          return true;
        }
      } catch (err) {}
      return false;
    }
    function finish() {
      if (!active) return;
      var target = row; active = false; row = null;
      if (!moved && target && target.isConnected) selectCategory(target);  // 干净轻点：选中分类
    }
    window.addEventListener('pointerup', finish, true);
    window.addEventListener('pointercancel', function () { active = false; row = null; }, true);
  }

  /* 自定义 M3 分类轨道：分「控件积木 / 常规积木」两组，常驻折叠箭头；
     直接用 Toolbox API 选中分类（真实 click，无按下即选/滑动误判），杜绝偶发“打不开”。 */
  function catItemName(it) { try { return it.getName_ ? it.getName_() : (it.name_ || ''); } catch (e) { return ''; } }
  function catItemColour(it) {
    var c = it && it.colour_;
    if (!c) return '#6750a4';
    if (typeof c === 'string') return c;
    return c.primary || c.base || c.colour || '#6750a4';
  }
  function chevSvg(dir) {
    var d = dir === 'up' ? 'M6 14l6-6 6 6' : 'M6 10l6 6 6-6';
    return '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="' + d + '"/></svg>';
  }
  function clearRailActive() {
    var rail = document.getElementById('bbCats');
    if (rail) Array.prototype.forEach.call(rail.querySelectorAll('.bb-cat.on'), function (b) { b.classList.remove('on'); });
  }
  // 离开积木页时：关闭分类浮层、控件下拉(BlocklyDropDownDiv 挂在 body，切视图不会自动关)、齿轮设置框
  function closeBlocksOverlays() {
    if (!state.wsInited || !state.ws) return;
    try { state.ws.hideChaff(); } catch (e) {}
    try { var tb = state.ws.getToolbox && state.ws.getToolbox(); if (tb && tb.clearSelection) tb.clearSelection(); } catch (e) {}
    try { state.ws.closeMutatorBubbles && state.ws.closeMutatorBubbles(); } catch (e) {}
    clearRailActive();
  }
  // 控件改名/增删/改文字后，画布与浮层里所有“控件/页面下拉”按 id 重新取最新显示名（value 存的是 id，仅文字需刷新）
  function refreshCompDropdowns() {
    if (!state.wsInited || !state.ws) return;
    function reroot(ws) {
      if (!ws || !ws.getAllBlocks) return;
      try {
        ws.getAllBlocks(false).forEach(function (b) {
          (b.inputList || []).forEach(function (inp) {
            (inp.fieldRow || []).forEach(function (f) {
              if (f && typeof f.getOptions === 'function') {
                // 关键：先以 useCache=false 重新执行动态 generator，刷新 Blockly 缓存的选项，
                // 否则 doValueUpdate_ 会沿用旧缓存文本（控件改名后显示不更新）。
                try { f.getOptions(false); } catch (e) {}
                try { if (typeof f.doValueUpdate_ === 'function') f.doValueUpdate_(f.getValue()); } catch (e) {}
                try { if (typeof f.forceRerender === 'function') f.forceRerender(); } catch (e) {}
                try { if (typeof f.updateTextNode_ === 'function') f.updateTextNode_(); } catch (e) {}
              }
            });
          });
        });
      } catch (e) {}
    }
    reroot(state.ws);
    try { var fl = state.ws.getFlyout && state.ws.getFlyout(); if (fl && fl.getWorkspace) reroot(fl.getWorkspace()); } catch (e) {}
  }
  function buildCategoryRail(ws) {
    var host = $('viewBlocks');
    var old = document.getElementById('bbCats'); if (old) old.remove();
    var oldZoom = document.getElementById('bbZoom'); if (oldZoom) oldZoom.remove();
    var tb = ws.getToolbox && ws.getToolbox(); if (!tb || !tb.getToolboxItems) return;
    var items = tb.getToolboxItems();
    var byName = {};
    items.forEach(function (it) { var n = catItemName(it); if (n) byName[n] = it; });

    var rail = el('div', ''); rail.id = 'bbCats';
    rail.classList.add('bb-mode-general');   // 默认展示“常规积木”整栏

    // 单个分类按钮（横向长方形 M3 条目）；直接走 Toolbox API 选中，真实 click，杜绝偶发打不开
    function makeCatButton(n) {
      var it = byName[n]; if (!it) return null;
      var colour = catItemColour(it);
      var b = el('button', 'bb-cat'); b.type = 'button'; b.title = n;
      b.style.setProperty('--bb-c', colour);
      var ico = el('span', 'bb-cat-ico', (window.BB_CAT_ICON && window.BB_CAT_ICON[n]) || n.slice(0, 1));
      ico.style.background = colour + '1F'; ico.style.color = colour;
      var lb = el('span', 'bb-cat-lb', n);
      b.appendChild(ico); b.appendChild(lb);
      b.addEventListener('click', function (ev) {
        ev.preventDefault(); ev.stopPropagation();
        try {
          var isSel = tb.getSelectedItem() === it;
          clearRailActive();
          if (isSel) tb.clearSelection(); else { tb.setSelectedItem(it); b.classList.add('on'); }
        } catch (err) {}
      });
      return b;
    }
    function makePanel(cls, names) {
      var panel = el('div', 'bb-panel ' + cls);
      names.forEach(function (n) { var b = makeCatButton(n); if (b) panel.appendChild(b); });
      return panel;
    }

    // 常驻切换槽：组名 + 箭头同处一条；槽内文案表示“箭头将展开的目标分组”。
    // 常规态底部为“控件积木 + 向上”（向上拉出控件栏），控件态顶部为“常规积木 + 向下”（向下拉回常规栏）。
    var topWrap = el('div', 'bb-switch-wrap bb-top-wrap');
    var topSw = el('button', 'bb-switch'); topSw.type = 'button'; topSw.setAttribute('aria-label', '切回常规积木');
    topSw.innerHTML = '<span class="bb-sw-tx">常规积木</span>' + chevSvg('down'); topWrap.appendChild(topSw);
    var botWrap = el('div', 'bb-switch-wrap bb-bot-wrap');
    var botSw = el('button', 'bb-switch'); botSw.type = 'button'; botSw.setAttribute('aria-label', '查看控件积木');
    botSw.innerHTML = '<span class="bb-sw-tx">控件积木</span>' + chevSvg('up'); botWrap.appendChild(botSw);

    var viewport = el('div', 'bb-rail-viewport');
    var generalPanel = makePanel('bb-panel-general', (window.BB_GROUPS && window.BB_GROUPS.general) || []);
    var widgetPanel = makePanel('bb-panel-widget', (window.BB_GROUPS && window.BB_GROUPS.widget) || []);
    viewport.appendChild(widgetPanel); viewport.appendChild(generalPanel);
    rail.appendChild(topWrap); rail.appendChild(viewport); rail.appendChild(botWrap);
    host.appendChild(rail);

    function setMode(mode) {
      var cur = rail.classList.contains('bb-mode-widget') ? 'widget' : 'general';
      if (cur === mode) return;
      try { tb.clearSelection(); } catch (e) {}
      clearRailActive();
      rail.classList.remove('bb-mode-general', 'bb-mode-widget');
      rail.classList.add('bb-mode-' + mode);
      var p = mode === 'widget' ? widgetPanel : generalPanel;
      setTimeout(function () { try { p.scrollTop = 0; } catch (e) {} }, 12);
    }
    botSw.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); setMode('widget'); });
    topSw.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); setMode('general'); });

    // 浮层因拖出积木/点空白自动关闭后，同步取消轨道高亮
    document.addEventListener('pointerup', function () {
      setTimeout(function () { try { if (!tb.getSelectedItem()) clearRailActive(); } catch (e) {} }, 60);
    }, true);

    // M3 缩放控件（替代老旧的原生放大镜位图）：整理积木 / 放大 / 复位 / 缩小
    var zoom = el('div', ''); zoom.id = 'bbZoom';
    var tidy = el('button', 'bb-z'); tidy.type = 'button'; tidy.title = '整理积木';
    tidy.innerHTML = '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M7 6h13M7 12h13M7 18h13"/><circle cx="3.5" cy="6" r="1" fill="currentColor" stroke="none"/><circle cx="3.5" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="3.5" cy="18" r="1" fill="currentColor" stroke="none"/></svg>';
    tidy.addEventListener('click', function (e) {
      e.preventDefault(); e.stopPropagation();
      try {
        ws.cleanUp();
        // cleanUp 把积木排到工作区起点后，整体往右、下挪一点，避免紧贴分类栏/顶边
        try {
          ws.getTopBlocks(false).forEach(function (b) { b.moveBy(40, 28); });
        } catch (eM) {}
        // 贴左上排列：滚动到 (0,0)，让积木紧靠分类栏右缘/画布顶部
        try { ws.scroll(0, 0); } catch (err) { try { ws.scrollCenter(); } catch (e2) {} }
        autosave(); snack('已整理积木');
      } catch (err) {}
    });
    var plus = el('button', 'bb-z'); plus.type = 'button'; plus.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20"><path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    var minus = el('button', 'bb-z'); minus.type = 'button'; minus.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20"><path d="M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    var reset = el('button', 'bb-z bb-z-center'); reset.type = 'button'; reset.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    plus.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); ws.zoomCenter(1); recordZoom(); });
    minus.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); ws.zoomCenter(-1); recordZoom(); });
    reset.addEventListener('click', function (e) {
      e.preventDefault(); e.stopPropagation();
      ws.setScale(DEFAULT_BLOCK_SCALE); ws.scrollCenter(); recordZoom();
    });
    zoom.appendChild(tidy); zoom.appendChild(plus); zoom.appendChild(reset); zoom.appendChild(minus);
    host.appendChild(zoom);
  }
  function bindDeleteOnDrag(ws) {
    var draggingBlock = null, armed = false, lastX = 0, lastY = 0, zone = $('delZone');
    function tbRect() { var t = document.querySelector('.blocklyToolboxDiv'); return t ? t.getBoundingClientRect() : null; }
    function overToolbox(x, y) { var r = tbRect(); return !!r && x >= r.left && x <= r.right && y >= r.top && y <= r.bottom; }
    function clearHint() { armed = false; if (zone) zone.classList.remove('on'); }
    document.addEventListener('pointermove', function (e) {
      lastX = e.clientX; lastY = e.clientY;
      if (!draggingBlock) return;
      var over = overToolbox(lastX, lastY);
      if (over !== armed) { armed = over; zone.classList.toggle('on', over); }
    }, true);
    // 兜底：指针在窗口外松开/手势被取消时，提示也必须消失
    window.addEventListener('pointerup', clearHint, true);
    window.addEventListener('pointercancel', clearHint, true);
    ws.addChangeListener(function (e) {
      if (e.type !== B.Events.BLOCK_DRAG || !e.blockId) return;
      if (e.isStart) { draggingBlock = ws.getBlockById(e.blockId); return; }
      // 拖放结束：无论积木是否还在（Blockly 可能已原生删除它），都必须先撤掉删除提示
      var wasArmed = armed, hit = overToolbox(lastX, lastY);
      draggingBlock = null; clearHint();
      var b = ws.getBlockById(e.blockId);
      // 积木仍存在且确实释放在左侧栏上 => 主动删除；已被 Blockly 原生删除则不再处理
      if (b && wasArmed && hit) setTimeout(function () { try { b.dispose(true); autosave(); } catch (err) {} }, 0);
    });
    // 再兜底：拖动中的积木若被任何路径删除（原生删除/剪切），提示立即消失
    ws.addChangeListener(function (e) {
      if (draggingBlock && (e.type === B.Events.BLOCK_DELETE || e.type === B.Events.BLOCK_DRAG && !e.isStart)) clearHint();
    });
  }
  function saveCurrentWs(closeOverlays) {
    if (!state.wsInited || !state.ws) return;
    if (closeOverlays) closeBlocksOverlays();   // 仅在显式离开积木页/切页面/运行导出前收起浮层，避免残留在其它页面
    recordZoom(true);   // 离开积木页/运行/导出前一并保存缩放
    try { curScreen().blocksXml = B.utils.xml.domToText(B.Xml.workspaceToDom(state.ws)); } catch (e) {}
  }
  function loadScreenToWs(s) {
    if (!state.wsInited || !state.ws) return;
    loadingWs = true;
    // 试运行返回时带回运行前视口，加载后精确还原；否则正常居中
    var vpRestore = null;
    try { var v = localStorage.getItem('__previewViewport'); if (v) { vpRestore = JSON.parse(v); } } catch (e) {}
    try {
      state.ws.clear();
      clearRailActive();
      state.ws.setScale(vpRestore ? vpRestore.scale : savedBlockScale());
      var dom = B.utils.xml.textToDom(s.blocksXml || '<xml xmlns="https://developers.google.com/blockly/xml"></xml>');
      B.Xml.domToWorkspace(dom, state.ws);
      if (vpRestore) {
        try { localStorage.removeItem('__previewViewport'); } catch (e) {}
        state.__skipScrollCenter = true;
        // 积木装载与 showView 的 resize 都是异步的，延迟到它们全部完成后再精确定位，
        // 否则会被后续 scrollCenter/resize 覆盖
        var doRestore = function () {
          try { state.ws.setScale(vpRestore.scale); state.ws.scroll(vpRestore.x, vpRestore.y); } catch (e) {}
        };
        requestAnimationFrame(function () { requestAnimationFrame(function () { setTimeout(doRestore, 120); }); });
      } else {
        state.ws.scrollCenter();
      }
    } catch (e) { console.error('loadWs', e); try { state.ws.clear(); } catch (x) {} }
    // Blockly 的创建事件是异步派发的（单个 setTimeout(0)），用双宏任务确保装载事件全部派发完再解除抑制，
    // 避免“跳转积木默认目标”等新建监听器篡改从工程里加载出来的积木
    finally { setTimeout(function () { setTimeout(function () { loadingWs = false; }, 0); }, 0); }
    requestWsResize();
  }
  function genCode(screen) {
    var ws = new B.Workspace(); window.__codegenScreen = screen;
    try {
      var dom = B.utils.xml.textToDom(screen.blocksXml || '<xml/>');
      B.Xml.domToWorkspace(dom, ws);
      // 仅事件帽子块作为入口生成；散落积木不执行
      return (window.generateEventCode ? window.generateEventCode(ws) : (B.JavaScript.workspaceToCode(ws) || '')) || '';
    } catch (e) { console.error('genCode', e); return ''; }
    finally { ws.dispose(); window.__codegenScreen = null; }
  }
  function buildOutput() {
    saveCurrentWs(true);
    var p = clone(state.project);
    p.appName = ($('appName').value || '我的应用').trim();
    p.startScreen = p.screens[0].id;
    p.screens.forEach(function (s) { s.code = genCode(s); });
    return p;
  }

  /* ---------------- 视图切换（设计 / 积木）；拖动布局是独立全屏界面 ---------------- */
  function showView(which) {
    state.view = which;
    $('viewDesign').classList.toggle('hidden', which !== 'design');
    $('viewBlocks').classList.toggle('hidden', which !== 'blocks');
    $('tabDesign').classList.toggle('on', which === 'design');
    $('tabBlocks').classList.toggle('on', which === 'blocks');
    if (which === 'blocks') {
      initWorkspace();
      // 新增/删除控件类型后，按工程实际用到的控件刷新工具箱（没有该类控件就隐藏对应分类）
      var usedTypes = new Set();
      ((state.project && state.project.screens) || []).forEach(function (s) { (s.components || []).forEach(function (c) { if (c && c.type) usedTypes.add(c.type); }); });
      try { if (state.ws) { state.ws.updateToolbox(window.buildToolboxXml(usedTypes)); buildCategoryRail(state.ws); } } catch (e) {}
      refreshCompDropdowns();   // 把控件改名/增删后的最新名称同步到积木下拉
      // 工作区从隐藏切到显示后，zelos 字段文本节点需在“可见 + resize 完成”后再刷新一次才稳定（多帧兜底）
      requestAnimationFrame(function () {
        requestAnimationFrame(function () { requestWsResize(); refreshCompDropdowns(); setTimeout(refreshCompDropdowns, 90); });
      });
    } else {
      closeBlocksOverlays();    // 离开积木页：收起分类浮层/控件下拉/齿轮框，避免残留在设计页
    }
  }

  /* 进入独立全屏布局界面：保存积木，按项目方向物理旋转，让竖屏项目真正竖屏 */
  function openLayout() {
    if (!state.project) return;
    saveCurrentWs(true);
    state.inLayout = true;
    var bl = $('btnLayout'); if (bl) bl.classList.add('on');
    closeMenus();
    $('viewLayout').classList.remove('hidden');
    if (window.Native && Native.setLayoutChrome) Native.setLayoutChrome(true);   // 与运行时一致的系统栏/安全区
    // 布局页始终隐藏通知栏（通知栏开关只在试运行/打包APK时生效）
    if (window.Native && Native.setOrientation) Native.setOrientation(curOrient());
    if (window.Native && Native.setStatusBar) Native.setStatusBar(false);
    renderLayout();
    // 物理旋转是异步的，多帧 + 旋转后的 resize 都会再 fit 并捕获真机设计尺寸（见全局 resize 监听）
    requestAnimationFrame(function () { requestAnimationFrame(fitStage); setTimeout(fitStage, 260); setTimeout(fitStage, 480); setTimeout(fitStage, 800); });
  }
  /* 返回编辑器：恢复横屏，隐藏布局屏 */
  function closeLayout() {
    state.inLayout = false;
    var bl = $('btnLayout'); if (bl) bl.classList.remove('on');
    closeSheet();
    closeMenus();
    $('viewLayout').classList.add('hidden');
    if (window.Native && Native.setLayoutChrome) Native.setLayoutChrome(false);  // 恢复编辑器全屏沉浸
    if (window.Native && Native.setOrientation) Native.setOrientation('landscape');
    requestAnimationFrame(requestWsResize);
  }

  /* 系统返回键：逐级返回（弹层 → 积木浮层 → 布局控制台 → 布局页 → 编辑器 → 我的应用），
     只有停在“我的应用”首页时才交还给原生退出，避免一按返回就整个退出。 */
  function maskVisible(id) { var n = $(id); return n && !n.classList.contains('hidden'); }
  window.__rtSystemBack = function () {
    // 1) 各种模态弹窗
    if (maskVisible('colorMask')) { closeColor(null); return true; }
    if (maskVisible('cloudCreateMask')) { closeCloudCreate(); return true; }
    if (maskVisible('cloudManageMask')) { $('cloudManageMask').classList.add('hidden'); return true; }
    if (maskVisible('blocklyDialogMask')) { $('bdCancel').click(); return true; }
    if (maskVisible('confirmMask')) { var cc = $('confirmCancel'); if (cc) cc.click(); return true; }
    if (maskVisible('modalMask')) { hideModal(); return true; }
    if (maskVisible('exportMask')) { $('exportMask').classList.add('hidden'); return true; }
    if (maskVisible('settingsMask')) { $('settingsMask').classList.add('hidden'); return true; }
    // 2) 积木：下拉/齿轮设置框/分类浮层
    if (state.view === 'blocks' && state.ws) {
      var flyoutOpen = false;
      try { var fl = state.ws.getFlyout && state.ws.getFlyout(); flyoutOpen = !!(fl && fl.isVisible && fl.isVisible()); } catch (e) {}
      if (flyoutOpen) {
        try { state.ws.hideChaff(); } catch (e) {}
        try { state.ws.closeMutatorBubbles && state.ws.closeMutatorBubbles(); } catch (e) {}
        try { var tb = state.ws.getToolbox && state.ws.getToolbox(); if (tb && tb.clearSelection) tb.clearSelection(); } catch (e) {}
        return true;
      }
    }
    // 3) 顶栏/布局页的下拉菜单
    if ($('screenMenu') && !$('screenMenu').classList.contains('hidden')) { closeMenus(); return true; }
    if ($('moreMenu') && !$('moreMenu').classList.contains('hidden')) { closeMenus(); return true; }
    if ($('layPageMenu') && !$('layPageMenu').classList.contains('hidden')) { closeMenus(); return true; }
    // 4) 拖动布局：先收控制台，再退出布局页
    if (state.inLayout) {
      if ($('laySheet') && $('laySheet').classList.contains('open')) { closeSheet(); return true; }
      closeLayout(); return true;
    }
    // 5) 编辑器内：返回“我的应用”
    if (!$('viewEditor').classList.contains('hidden')) { showHome(); return true; }
    // 6) 已在首页：交还给原生（退出 App）
    return false;
  };
  // 顶部页面下拉按钮文案
  function updateLayPageBtn() {
    var b = $('layPageBtn'); if (b) b.textContent = (curScreen().title || curScreen().id) + ' ▾';
  }

  /* ---------------- 拖动布局视图 ---------------- */
  var layout = { dragId: null };
  function validN(v) { return typeof v === 'number' && isFinite(v); }
  /* 参考“设计画布”逻辑尺寸（兜底）。真机进入拖动布局时会按【本机实际可用宽高比】捕获一份
     project.design（与运行时壳避让状态栏/导航栏后的可用区完全一致），编辑器布局与运行时都用它，
     做到上下左右严格对齐、底部不再莫名留缝。 */
  var DESIGN = { portrait: { w: 390, h: 827 }, landscape: { w: 827, h: 390 } };
  function designSize() {
    var o = curOrient();
    var base = o === 'landscape' ? DESIGN.landscape : DESIGN.portrait;
    var p = state.project && state.project.design;
    if (p && p.orientation === o &&
        validN(p.w) && validN(p.h) && p.w >= 240 && p.h >= 240) {
      return { w: Math.round(p.w), h: Math.round(p.h) };
    }
    return base;
  }
  // 依据布局页真实可用区（原生已按系统栏/挖孔留白）捕获设计画布尺寸；返回是否发生变化
  function captureDesign() {
    if (!state.inLayout || !state.project) return false;
    var vw = window.innerWidth, vh = window.innerHeight;
    if (!(vw > 50) || !(vh > 50)) return false;
    var landscape = curOrient() === 'landscape';
    if (landscape ? !(vw > vh) : !(vh > vw)) return false;   // 方向还没转到位，不捕获
    var w, h;
    if (landscape) { h = 390; w = Math.round(390 * vw / vh); }
    else { w = 390; h = Math.round(390 * vh / vw); }
    w = Math.max(280, Math.min(w, 1600)); h = Math.max(320, Math.min(h, 1600));
    var p = state.project.design;
    if (p && p.orientation === curOrient() && p.w === w && p.h === h) return false;
    state.project.design = { orientation: curOrient(), w: w, h: h };
    autosave();
    return true;
  }
  function stageScale() { var k = parseFloat($('layStage') && $('layStage').dataset.scale); return isFinite(k) && k > 0 ? k : 1; }
  // 舞台固定为设计逻辑尺寸，再用 transform 等比缩放适配可用区域（坐标仍是设计像素，与运行时一致）
  function fitStage() {
    var wrap = document.querySelector('#viewLayout .lay-stage-wrap'), stage = $('layStage');
    if (!wrap || !stage || !state.inLayout) return;
    if (wrap.clientWidth < 2 || wrap.clientHeight < 2) return;   // 旋转动画中容器还没好，等 resize
    var changed = captureDesign();                              // 用真机可用区刷新设计画布尺寸
    var landscape = curOrient() === 'landscape';
    stage.classList.toggle('portrait', !landscape);
    stage.classList.toggle('landscape', landscape);
    var d = designSize();
    // 舞台直接铺满外层可用区，不缩放、不留空白
    stage.style.width = wrap.clientWidth + 'px';
    stage.style.height = wrap.clientHeight + 'px';
    stage.dataset.scale = 1;
    stage.style.transform = 'none';
    stage.style.transformOrigin = 'top left';
    if (changed) renderLayStage();                              // 画布尺寸变化后重新摆放所有组件
  }
  function renderLayout() {
    if (!$('viewLayout')) return;
    fitStage();
    var sheet = $('laySheet');
    sheet.classList.remove('open');                       // 进入时默认收起，仅 FAB 展开
    $('viewLayout').classList.remove('console-open');
    $('layFab').classList.add('hidden');
    updateLayPageBtn();
    renderLayStage();
    renderLaySheet();
  }
  // 顶部页面下拉按钮文案（旧的横向滑动页签已移除，统一走下拉）
  // 绝对定位但未填宽高时的“纯类型默认尺寸”，必须与 runtime.js 的 defaultBox 完全一致
  function defaultSize(c) {
    switch (c.type) {
      case 'button': return { w: 220, h: 48 };
      case 'input': return { w: 220, h: 52 };
      case 'list': return { w: 240, h: 170 };
      case 'image': return { w: 160, h: 120 };
      case 'switch': return { w: 220, h: 40 };
      case 'checkbox': return { w: 220, h: 40 };
      case 'slider': return { w: 220, h: 40 };
      case 'progress': return { w: 220, h: 12 };
      case 'video': return { w: 240, h: 135 };
      case 'audio': return { w: 280, h: 44 };
      case 'web': return { w: 320, h: 240 };
      case 'text': return { w: 220, h: 40 };
      default: return { w: 200, h: 44 };
    }
  }
  function layVisual(c) {
    var d = document.createElement('div');
    var txt = c.type === 'button' ? (c.text || '按钮')
      : c.type === 'input' ? (c.hint || '请输入')
      : c.type === 'text' ? (c.value || '文字')
      : c.type === 'switch' ? (c.text || '开关')
      : c.type === 'checkbox' ? (c.text || '复选项')
      : c.type === 'slider' ? ''
      : c.type === 'progress' ? ''
      : c.type === 'image' ? ''
      : (c.type === 'video' || c.type === 'audio' || c.type === 'web') ? (c.name || (TYPE_META[c.type] && TYPE_META[c.type].label) || '控件')
      : ((c.items && c.items[0]) || '列表');
    if (c.type === 'list') {
      (c.items || []).slice(0, 4).forEach(function (it) { var r = el('div', 'li-row', it || ' '); d.appendChild(r); });
    } else if (c.type === 'image' && c.src) {
      var im = el('img'); im.src = c.src; d.appendChild(im);
    } else if (c.type === 'video' || c.type === 'audio' || c.type === 'web') {
      d.className = 'lv-media';
      var mico = el('span', 'lv-media-ico', c.type === 'video' ? '▶' : (c.type === 'audio' ? '♪' : 'W'));
      d.appendChild(mico);
      d.appendChild(el('span', 'lv-media-tx', txt));
    } else if (c.type === 'switch') {
      d.className = 'lv-row lv-between';
      d.appendChild(el('span', 'lv-label', txt));
      var sw = el('div', 'lv-sw' + (c.checked ? ' on' : '')); sw.appendChild(el('i', 'lv-knob')); d.appendChild(sw);
    } else if (c.type === 'checkbox') {
      d.className = 'lv-row';
      var ck = el('div', 'lv-ck' + (c.checked ? ' on' : ''), '✓'); d.appendChild(ck);
      d.appendChild(el('span', 'lv-label', txt));
    } else if (c.type === 'slider') {
      d.className = 'lv-rng-wrap';
      var pct = Math.max(0, Math.min(100, ((validN(c.value) ? c.value : 0) - (c.min || 0)) / ((c.max || 100) - (c.min || 0) || 1) * 100));
      var rt = el('div', 'lv-rng'); var rk = el('i', 'lv-rng-knob'); rk.style.left = pct + '%'; rt.appendChild(rk); d.appendChild(rt);
    } else if (c.type === 'progress') {
      d.className = 'lv-prog-wrap';
      var pmax = c.max || 100, pv = Math.max(0, Math.min(pmax, validN(c.value) ? c.value : 0));
      var pf = el('div', 'lv-prog'); var pff = el('i', 'lv-prog-fill'); pff.style.width = (pmax ? (pv / pmax * 100) : 0) + '%'; if (c.bg) pff.style.background = c.bg;
      pf.appendChild(pff); d.appendChild(pf);
    } else d.textContent = txt;
    if (validN(c.fs)) d.style.fontSize = c.fs + 'px';
    if (c.color) d.style.color = c.color;
    if (c.bg && c.type !== 'progress' && c.type !== 'slider' && c.type !== 'switch' && c.type !== 'checkbox') d.style.background = c.bg;
    if (validN(c.radius)) d.style.borderRadius = c.radius + 'px';
    if (c.bold) d.style.fontWeight = '700';
    if (c.align) d.style.textAlign = c.align;
    if (validN(c.opacity)) d.style.opacity = (Math.max(0, Math.min(100, c.opacity)) / 100).toFixed(3);
    return d;
  }
  var layRenderToken = 0;
  function renderLayStage() {
    var sc = curScreen(), stage = $('layStage'), flow = $('layFlow');
    // 清掉旧的可拖动项，保留 flow
    Array.prototype.slice.call(stage.querySelectorAll('.litem')).forEach(function (n) { n.remove(); });
    flow.innerHTML = '';
    var dsz = designSize();
    // 1) 隐藏 flow 复刻运行时 #flow：只有“自动排列”组件占位（绝对定位组件在运行时不占流，
    //    这里也绝不能占位，否则后续自动组件的 Y 坐标会与运行时不一致）
    var mirrors = {};
    sc.components.forEach(function (c) {
      var isAbs = validN(c.x) || validN(c.y);
      if (isAbs) return;
      var m = layVisual(c);
      // 保留 layVisual 自带的 lv-* 布局类（开关/复选/滑块/进度的横向布局靠它），再追加镜像类
      m.classList.add('lmirror', 't-' + c.type);
      var ds = defaultSize(c);
      m.style.width = (validN(c.w) ? c.w : dsz.w - 32) + 'px';
      if (c.type === 'list') {
        // 列表：显式高度优先（与运行时 c.h 一致）；未设时按行高 48 撑开，空列表 56
        m.style.minHeight = (validN(c.h) ? c.h : ((c.items && c.items.length) ? 48 * c.items.length : 56)) + 'px';
      } else if (c.type === 'text') {
        m.style.minHeight = (validN(c.h) ? c.h : 28) + 'px';
      } else {
        m.style.minHeight = (validN(c.h) ? c.h : ds.h) + 'px';
      }
      flow.appendChild(m); mirrors[c.id] = m;
    });
    // 2) 等一帧布局完成后放置项（坐标/尺寸都是设计像素，与运行时一一对应）。
    //    用 token 保证多次调度（fitStage/旋转/属性变更）只有最后一次提交，杜绝幽灵节点。
    var token = ++layRenderToken;
    requestAnimationFrame(function () {
      if (token !== layRenderToken) return;
      var sr = stage.getBoundingClientRect(), k = stageScale();
      if (sr.width < 2 || !(k > 0)) { setTimeout(renderLayStage, 60); return; }   // 舞台还没布局好，稍后重试
      Array.prototype.slice.call(stage.querySelectorAll('.litem')).forEach(function (n) { n.remove(); });
      sc.components.slice().reverse().forEach(function (c) {
        var item = el('div', 'litem t-' + c.type + (c.id === state.selectedCompId ? ' sel' : '') + (c.visible === false ? ' is-hidden' : ''));
        item.dataset.id = c.id;
        var visual = layVisual(c);
        // 把视觉样式（字号/颜色/背景/圆角/加粗/对齐/透明度）从中间节点带到可拖动项，避免预览丢样式
        var vs = visual.style;
        ['fontSize', 'color', 'background', 'borderRadius', 'fontWeight', 'textAlign', 'opacity'].forEach(function (p) { if (vs[p]) item.style[p] = vs[p]; });
        while (visual.firstChild) item.appendChild(visual.firstChild);
        item.appendChild(el('span', 'li-tag', compName(c) + (c.visible === false ? '（已隐藏）' : '')));
        var ds = defaultSize(c);
        var auto = mirrors[c.id], ar = auto ? auto.getBoundingClientRect() : null;
        var arx = ar ? (ar.left - sr.left) / k : 0, ary = ar ? (ar.top - sr.top) / k : 0;
        var arw = ar ? ar.width / k : ds.w, arh = ar ? ar.height / k : ds.h;
        var isAbs = validN(c.x) || validN(c.y);
        var x, y, w, h;
        if (isAbs) {
          // 绝对定位：原点=画布边框(0,0)，与运行时 #screen 一致；缺省轴按 0（画布边缘）
          x = validN(c.x) ? c.x : 0; y = validN(c.y) ? c.y : 0;
          w = validN(c.w) ? c.w : ds.w; h = validN(c.h) ? c.h : ds.h;
        } else {
          // 自动排列：完全采用镜像测量，保证和运行时一致
          x = arx; y = ary; w = arw; h = arh;
        }
        item.style.left = Math.round(x) + 'px'; item.style.top = Math.round(y) + 'px';
        item.style.width = Math.round(w) + 'px'; item.style.height = Math.round(Math.max(h, c.type === 'text' ? 24 : 8)) + 'px';
        if (validN(c.radius)) item.style.borderRadius = c.radius + 'px';
        bindLitemDrag(item, c);
        stage.appendChild(item);
      });
    });
  }
  function bindLitemDrag(item, c) {
    var sx = 0, sy = 0, ox = 0, oy = 0, moved = false, active = false, pid = null;
    var wasAuto = !(validN(c.x) || validN(c.y));   // 自动排列组件被拖后转绝对定位，但保持当前形状不变
    function down(e) {
      try { item.setPointerCapture(e.pointerId); } catch (err) {}
      pid = e.pointerId; sx = e.clientX; sy = e.clientY;
      ox = parseFloat(item.style.left) || 0; oy = parseFloat(item.style.top) || 0;
      moved = false; active = true; item.classList.add('dragging'); e.preventDefault();
    }
    function move(e) {
      if (!active || e.pointerId !== pid) return;
      var dx = e.clientX - sx, dy = e.clientY - sy;
      if (Math.abs(dx) > 4 || Math.abs(dy) > 4) {
        if (!moved && wasAuto) {
          // 关键：开始自由拖动的瞬间，把屏幕上所有“自动排列”控件按当前画面位置/尺寸一次性固化为
          // 绝对定位（含被拖控件自己）。这样拖走其中一个时，其余控件原地不动、不再突然补位；
          // 运行时所有控件都按同一组坐标渲染，与现在所见完全一致。
          var stage0 = $('layStage'), sr0 = stage0.getBoundingClientRect(), k0 = stageScale();
          var byId = {};
          Array.prototype.forEach.call(stage0.querySelectorAll('.litem'), function (n) { byId[n.dataset.id] = n; });
          curScreen().components.forEach(function (cp) {
            if (validN(cp.x) || validN(cp.y)) return;          // 已是绝对定位，保持
            var n = byId[cp.id]; if (!n) return;
            var r = n.getBoundingClientRect();
            cp.x = Math.round((r.left - sr0.left) / k0);
            cp.y = Math.round((r.top - sr0.top) / k0);
            cp.w = Math.round(r.width / k0);
            cp.h = Math.round(r.height / k0);
          });
          wasAuto = false;
        }
        moved = true;
      }
      if (!moved) return;
      var k = stageScale(), stageEl = $('layStage');
      var sw = stageEl.offsetWidth, sh = stageEl.offsetHeight;   // 按舞台实际尺寸限制，拖不出舞台
      var nx = Math.max(0, Math.min(sw - item.offsetWidth, ox + dx / k));
      var ny = Math.max(0, Math.min(sh - item.offsetHeight, oy + dy / k));
      item.style.left = Math.round(nx) + 'px'; item.style.top = Math.round(ny) + 'px';
      e.preventDefault();
    }
    function up(e) {
      if (!active || (e && e.pointerId !== pid)) return;
      active = false; pid = null; item.classList.remove('dragging');
      if (moved) {
        c.x = Math.round(parseFloat(item.style.left)); c.y = Math.round(parseFloat(item.style.top));
        state.selectedCompId = c.id;
        $('layFab').classList.remove('hidden');
        autosave();
        // 该组件已脱离自动流，其余自动组件会在运行时重新排列；重排舞台让预览立刻与运行时一致
        renderLayStage();
        renderLaySheet();
        return;
      }
      state.selectedCompId = c.id;
      Array.prototype.forEach.call($('layStage').querySelectorAll('.litem'), function (n) { n.classList.toggle('sel', n.dataset.id === c.id); });
      renderLaySheet();
      // 只选中、不自动弹出控制台；由右下角 FAB 手动展开
      $('layFab').classList.remove('hidden');
    }
    item.addEventListener('pointerdown', down);
    item.addEventListener('pointermove', move);
    item.addEventListener('pointerup', up);
    item.addEventListener('pointercancel', up);
  }
  function renderLaySheet() {
    var c = selectedComp(), title = $('laySheetTitle'), body = $('laySheetBody');
    title.textContent = c ? compName(c) : '未选中组件';
    body.innerHTML = '';
    if (!c) return;
    fillPropFields(body, c, function () {
      // 改属性后：标题同步、舞台实时更新（不重建选中态）
      title.textContent = compName(c);
      renderLayStage();
    }, function () { renderLayStage(); renderLaySheet(); });
  }
  function openSheet() {
    if (!selectedComp()) return;
    $('laySheet').classList.add('open');
    $('viewLayout').classList.add('console-open');
    $('layFab').classList.add('hidden');
    requestAnimationFrame(fitStage);
  }
  function closeSheet() {
    $('laySheet').classList.remove('open');
    $('viewLayout').classList.remove('console-open');
    $('layFab').classList.toggle('hidden', !selectedComp());
    requestAnimationFrame(fitStage);
  }
  function bindLayoutChrome() {
    // 左上角返回编辑器（按钮已删，用系统返回手势）
    var lb = $('layBack'); if (lb) lb.addEventListener('click', closeLayout);
    // 右下角 FAB：点击才展开控制台
    $('layFab').addEventListener('click', function () { renderLaySheet(); openSheet(); });
    // 控制台右上角 ✕ 收起
    $('laySheetClose').addEventListener('click', closeSheet);
    // 顶部页面下拉：切换/新建/删除页面
    var pb = $('layPageBtn');
    if (pb) pb.addEventListener('click', function (e) {
      e.stopPropagation(); buildLayPageMenu(); toggleMenu($('layPageMenu'), pb);
    });
  }
  function buildLayPageMenu() {
    var menu = $('layPageMenu'); menu.innerHTML = '';
    var list = el('div', 'menu-list');           // 页面很多时仅此处滚动，操作行常驻
    state.project.screens.forEach(function (s) {
      var b = el('button', 'menu-item' + (s.id === state.curScreenId ? ' on' : ''), (s.title || s.id));
      b.addEventListener('click', function () { closeMenus(); switchScreen(s.id); });
      list.appendChild(b);
    });
    menu.appendChild(list);
    var sep = el('div', 'menu-sep'); menu.appendChild(sep);
    var add = el('button', 'menu-item', '＋ 新建页面');
    add.addEventListener('click', function () { closeMenus(); addScreen(); });
    var del = el('button', 'menu-item danger', '删除当前页面');
    del.addEventListener('click', function () { closeMenus(); deleteScreen(); });
    menu.appendChild(add); menu.appendChild(del);
  }

  /* ---------------- 弹层 ---------------- */
  var snackTimer = null;
  function snack(msg) {
    var bar = $('snackbar'); if (!bar) return;
    bar.textContent = msg; bar.classList.add('show');
    clearTimeout(snackTimer);
    snackTimer = setTimeout(function () { bar.classList.remove('show'); }, 2600);
  }
  function modal(title, body, okText, onOk) {
    $('modalTitle').textContent = title;
    $('modalBody').innerHTML = '';
    if (typeof body === 'string') $('modalBody').textContent = body; else $('modalBody').appendChild(body);
    var ok = $('modalOk');
    if (okText) { ok.classList.remove('hidden'); ok.textContent = okText; ok.onclick = onOk; } else ok.classList.add('hidden');
    var ex = $('modalExtra'); ex.classList.add('hidden'); ex.onclick = null; ex.textContent = '备用';
    $('modalMask').classList.remove('hidden');
  }
  /** 配置左下角备用按钮 */
  function modalExtra(text, fn) {
    var ex = $('modalExtra');
    ex.textContent = text; ex.onclick = fn; ex.classList.remove('hidden');
  }
  function hideModal() { $('modalMask').classList.add('hidden'); }

  /* ---------------- 顶栏下拉菜单（popover） ---------------- */
  function closeMenus() {
    ['screenMenu', 'moreMenu', 'layPageMenu', 'runMenu'].forEach(function (id) { var m = $(id); if (m) m.classList.add('hidden'); });
  }
  function positionMenu(menu, anchor) {
    var r = anchor.getBoundingClientRect();
    var mw = menu.offsetWidth || 200, mh = menu.offsetHeight || 120;
    var vw = window.innerWidth, vh = window.innerHeight, gap = 8;
    // 水平：默认与按钮左对齐，溢出则右对齐，再整体钳制进视口
    var left = r.left;
    if (left + mw > vw - gap) left = r.right - mw;
    left = Math.max(gap, Math.min(left, vw - mw - gap));
    // 垂直：优先在按钮下方，下方不够则翻到上方
    var top = r.bottom + 4;
    if (top + mh > vh - gap) top = Math.max(gap, r.top - mh - 4);
    menu.style.right = 'auto';
    menu.style.left = Math.round(left) + 'px';
    menu.style.top = Math.round(top) + 'px';
  }
  function toggleMenu(menu, anchor) {
    var willOpen = menu.classList.contains('hidden');
    closeMenus();
    if (willOpen) {
      // 先以不可见状态参与布局以便测量尺寸，定位后再显现，避免一帧错位/溢出
      menu.style.visibility = 'hidden';
      menu.classList.remove('hidden');
      positionMenu(menu, anchor);
      menu.style.visibility = '';
    }
  }
  function buildScreenMenu() {
    var list = $('screenMenuList'); list.innerHTML = '';
    state.project.screens.forEach(function (s) {
      var b = el('button', 'menu-item' + (s.id === state.curScreenId ? ' on' : ''), (s.title || s.id));
      b.addEventListener('click', function () { closeMenus(); switchScreen(s.id); });
      list.appendChild(b);
    });
  }

  /* ---------------- 设置（主题色 / 明暗） ---------------- */
  function buildSettings() {
    var th = getTheme(), seedRow = $('seedRow'); seedRow.innerHTML = '';
    SEEDS.forEach(function (s) {
      var b = el('button', 'seed-swatch' + (s[0].toLowerCase() === th.seed.toLowerCase() ? ' on' : ''));
      b.style.background = s[0]; b.title = s[1]; b.type = 'button';
      b.addEventListener('click', function () { var t = getTheme(); t.seed = s[0]; saveTheme(t); applyTheme(); buildSettings(); });
      seedRow.appendChild(b);
    });
    Array.prototype.forEach.call($('modeSeg').children, function (b) {
      b.classList.toggle('on', b.getAttribute('data-mode') === th.mode);
      b.onclick = function () { var t = getTheme(); t.mode = b.getAttribute('data-mode'); saveTheme(t); applyTheme(); buildSettings(); };
    });
  }
  function openSettings() { buildSettings(); $('settingsMask').classList.remove('hidden'); }

  /* ---------------- 运行 / 导出 ----------------
     mode: 'start' = 从第一个页面（工程起始页）运行；'current' = 从编辑器当前打开的页面运行 */
  // 运行方式（由 ▾ 菜单选择，决定主按钮点下去怎么跑）；持久化记住用户习惯
  var RUN_MODE_KEY = '__bb_run_mode_v1';
  function getRunMode() {
    var m = 'start';
    try { m = localStorage.getItem(RUN_MODE_KEY) || 'start'; } catch (e) {}
    return m === 'current' ? 'current' : 'start';
  }
  function setRunMode(m) {
    state.runMode = (m === 'current' ? 'current' : 'start');
    try { localStorage.setItem(RUN_MODE_KEY, state.runMode); } catch (e) {}
    applyRunMode();
    snack(state.runMode === 'current' ? '运行方式：当前页面运行' : '运行方式：从头开始运行');
  }
  function applyRunMode() {
    state.runMode = getRunMode();
    var cur = state.runMode === 'current';
    var ico = $('runMainIco'); if (ico) ico.textContent = cur ? '▶' : '⏮';
    var btn = $('btnRun'); if (btn) btn.title = cur ? '当前页面运行' : '从头开始运行';
    var a = $('runFromStart'), b = $('runCurrent');
    if (a) a.classList.toggle('on', !cur);
    if (b) b.classList.toggle('on', cur);
  }
  function onRun(mode) {
    var p = buildOutput();      // 内部已 saveCurrentWs，把当前积木写回工程
    persist();                  // 关键：跳转前把工程（含积木）写入 localStorage，返回重载后不丢
    try { localStorage.setItem('__previewProject', JSON.stringify(p)); } catch (e) {}
    // 记住运行前所在页（设计/积木）与所在页面，试运行 history.back 重载后恢复到原处
    try {
      localStorage.setItem('__previewReturnView', state.view || 'design');
      localStorage.setItem('__previewReturnScreen', state.curScreenId || '');
      if (mode === 'current') localStorage.setItem('__previewStartScreen', state.curScreenId || '');
      else localStorage.removeItem('__previewStartScreen');
    } catch (e) {}
    // 记住运行前积木视口，试运行返回后恢复，避免积木整体移位
    try {
      if (state.ws) {
        localStorage.setItem('__previewViewport', JSON.stringify({ x: state.ws.scrollX, y: state.ws.scrollY, scale: state.ws.scale }));
      }
    } catch (e) {}
    // 试运行与导出壳保持一致：显示系统栏并按其留白，这样预览/导出/拖动布局三者的可用区完全相同
    if (window.Native && Native.setLayoutChrome) Native.setLayoutChrome(true);
    if (window.Native && Native.setOrientation) Native.setOrientation(p.orientation || 'portrait');
    location.href = 'runtime.html';
  }

  /* ---------------- 检查更新：读取内置 SeaTable“更新”表，选版本下载安装 ---------------- */
  var UPDATE_CFG = {
    server: 'https://cloud.seatable.cn',
    uuid: '5ded0202-5402-4176-bde2-69a5f7c14af6',
    token: 'fb7817a1d4f5da4e951a354afef60c16ec7e397e',
    table: '更新'
  };
  var updateRows = [], updateSel = -1;
  async function openUpdateDialog() {
    $('updateMask').classList.remove('hidden');
    $('updateStatus').textContent = '正在检查更新…';
    $('updateList').innerHTML = '';
    updateRows = []; updateSel = -1;
    $('updateGo').disabled = true;
    try {
      var d = await editorCloudHttp('GET', UPDATE_CFG.server + '/api/v2.1/dtable/app-access-token/', null, UPDATE_CFG.token);
      if (!d || !d.access_token) throw new Error('鉴权失败');
      var gateway = (d.dtable_server || UPDATE_CFG.server + '/api-gateway/').replace(/\/+$/, '');
      var uuid = d.dtable_uuid || UPDATE_CFG.uuid;
      var resp = await editorCloudHttp('GET', gateway + '/api/v2/dtables/' + uuid + '/rows/?table_name=' + encodeURIComponent(UPDATE_CFG.table), null, d.access_token);
      var list = (resp && resp.rows) || [];
      list.reverse();   // 云表顺序 1A 2B 3C，界面倒序显示成 1C 2B 3A
      updateRows = list;
      if (!list.length) { $('updateStatus').textContent = '暂无更新包'; return; }
      $('updateStatus').textContent = '选择要安装的版本：';
      list.forEach(function (r, i) {
        var ver = r['0000'] || ('版本 ' + (i + 1));
        var files = r['etRB'] || [];
        var fname = files[0] ? files[0].name : '';
        var item = el('div', 'upd-item');
        item.appendChild(el('span', 'upd-ver', ver));
        item.appendChild(el('span', 'upd-file', fname));
        item.addEventListener('click', function () {
          updateSel = i;
          Array.prototype.forEach.call($('updateList').children, function (n) { n.classList.remove('sel'); });
          item.classList.add('sel');
          $('updateGo').disabled = false;
        });
        $('updateList').appendChild(item);
      });
    } catch (e) {
      $('updateStatus').textContent = '检查失败：' + (e.message || '网络错误');
    }
  }
  async function doUpdate() {
    if (updateSel < 0) return;
    var r = updateRows[updateSel] || {};
    var files = r['etRB'] || [];
    if (!files[0] || !files[0].url) { snack('该版本没有安装包'); return; }
    var url = files[0].url, name = files[0].name || ('update_' + Date.now() + '.apk');
    $('updateGo').disabled = true;
    try {
      // 附件 url 形如 .../asset/<uuid>/files/2026-09/xxx.apk，取出 /asset/<uuid>/ 之后的 file_path
      var m = url.match(/\/asset\/[^/]+\/(.+)$/);
      var filePath = m ? m[1] : '';
      if (!filePath) throw new Error('无法解析文件路径');
      // 用 app Token 换临时直链（seafhttp/files/...），否则直接 GET 只会下到登录页 HTML
      $('updateStatus').textContent = '正在获取下载地址…';
      var enc = encodeURI(decodeURIComponent(filePath));   // 保留 / 分隔符，只编码文件名部分
      var linkResp = await editorCloudHttp('GET', UPDATE_CFG.server + '/api/v2.1/dtable/app-download-link/?path=' + enc, null, UPDATE_CFG.token);
      var direct = linkResp && linkResp.download_link;
      if (!direct) throw new Error('未取得下载链接');
      $('updateStatus').textContent = '正在下载安装包…';
      window.__updCid = 'upd_' + Date.now();
      Native.downloadApk(window.__updCid, direct, name);
    } catch (e) {
      $('updateStatus').textContent = '下载失败：' + (e.message || '网络错误');
      $('updateGo').disabled = false;
    }
  }

  var exportIcon = null;
  function openExport() {
    var p = buildOutput();
    var total = p.screens.reduce(function (a, s) { return a + s.components.length; }, 0);
    if (total === 0) { modal('无法导出', '请先添加至少一个组件。'); return; }
    exportIcon = p.icon || null;
    $('expVersion').value = p.version || '1.0';
    renderIconPreview();
    $('exportMask').classList.remove('hidden');
  }
  function renderIconPreview() {
    var pv = $('iconPreview');
    if (exportIcon) { pv.style.backgroundImage = 'url(' + exportIcon + ')'; pv.textContent = ''; }
    else { pv.style.backgroundImage = ''; pv.textContent = ($('appName').value || '我').slice(0, 1); }
  }
  function doExport() {
    var p = buildOutput();
    p.version = ($('expVersion').value || '1.0').trim();
    p.icon = exportIcon;
    state.project.version = p.version; state.project.icon = exportIcon;
    saveCurrentWs(true); persist();   // 导出前确保积木与工程已落盘
    $('exportMask').classList.add('hidden');
    if (!window.Native || !Native.exportApk) { modal('导出说明', '需要在安卓 App 内运行才能生成 APK。'); return; }
    modal('正在生成', '正在编译并签名 APK，请稍候…');
    $('modalOk').classList.add('hidden');
    Native.exportApk(JSON.stringify(p), p.appName, p.orientation || 'portrait', exportIcon || '', p.version);
  }
  window.EditorApp = {
    onExportResult: function (ok, path, err, downloadUri) {
      if (ok) {
        var fname = path.split('/').pop();
        var box = el('div');
        var line = el('div', 'dim'); line.style.wordBreak = 'break-all';
        line.textContent = '已保存到手机「下载/FAST/' + fname + '」。点「安装」直接安装；若失败，可点「打开下载目录」手动点 APK 安装。';
        box.appendChild(line);
        modal('导出成功', box, '安装', function () {
          try { Native.installApk(path, downloadUri || ''); } catch (e) {}
          hideModal();
        });
        modalExtra('打开下载目录', function () {
          if (window.Native && Native.openDownloadFolder) Native.openDownloadFolder();
          else modal('安装方式', '请用系统「文件管理」进入 下载/FAST 目录，点击该 APK 安装。', '知道了', hideModal);
        });
      } else modal('导出失败', err || '未知错误');
    },
    // 本地上传视频/音频完成：原生把文件拷入私有目录后回调文件名，把它记成组件的 media:// 引用
    onMediaPicked: function (name) {
      if (!name) { snack('未选择文件或选择失败'); return; }
      var cid = state.pendingMediaCompId; state.pendingMediaCompId = null;
      if (!cid) return;
      var found = null, screens = (state.project && state.project.screens) || state.screens || [];
      screens.forEach(function (s) { (s.components || []).forEach(function (c) { if (c.id === cid) found = c; }); });
      if (!found) return;
      found.src = 'media://' + name;
      autosave(); renderPropPanel(); renderCompList();
      snack('已添加本地文件：' + name);
    },
    // 检查更新：APK 下载完成，准备调系统安装器
    onApkDownloaded: function (cbId, path, err) {
      if (err) { var st = $('updateStatus'); if (st) st.textContent = '下载失败：' + err; var g = $('updateGo'); if (g) g.disabled = false; return; }
      var st = $('updateStatus'); if (st) st.textContent = '下载完成，准备安装…';
      try { if (window.Native && Native.installApk) Native.installApk(path, ''); } catch (e) {}
      setTimeout(function () { var m = $('updateMask'); if (m) m.classList.add('hidden'); }, 500);
    }
  };

  /* ---------------- 初始化 ---------------- */
  function init() {
    if (window.Native && Native.setOrientation) Native.setOrientation('landscape');
    $('btnNewApp').addEventListener('click', createItem);
    $('createGo').addEventListener('click', confirmCreate);
    $('createCancel').addEventListener('click', closeCreate);
    $('newAppName').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); if (!this.value.trim()) return; confirmCreate(); }
      if (e.key === 'Escape') { e.preventDefault(); closeCreate(); }
    });
    $('newAppName').addEventListener('input', function () {
      syncCreateBtn();
      if ((this.value || '').trim()) { var b2 = this.closest('.m3-outlined'); if (b2) b2.classList.remove('err'); }
    });
    Array.prototype.forEach.call(document.querySelectorAll('#newOrient .ori'), function (b) {
      b.addEventListener('click', function () { setNewOrient(b.getAttribute('data-orient')); });
    });
    $('createMask').addEventListener('click', function (e) { if (e.target === this) closeCreate(); });
    // M3 描边输入框：焦点/有内容时标签上浮（用类名兜底部分 WebView :focus 伪类不灵敏）
    Array.prototype.forEach.call(document.querySelectorAll('.m3-outlined .m3-input'), function (inp) {
      var box = inp.closest('.m3-outlined');
      function syncFilled() { box.classList.toggle('filled', !!(inp.value && inp.value.length)); }
      inp.addEventListener('focus', function () { box.classList.add('focused'); });
      inp.addEventListener('blur', function () { box.classList.remove('focused'); });
      inp.addEventListener('input', syncFilled);
      syncFilled();
    });
    $('btnHome').addEventListener('click', showHome);
    $('btnHelp').addEventListener('click', openHelp);
    $('btnHelpBack').addEventListener('click', showHome);
    $('btnUpdate').addEventListener('click', openUpdateDialog);
    $('updateCancel').addEventListener('click', function () { $('updateMask').classList.add('hidden'); });
    $('updateGo').addEventListener('click', doUpdate);
    $('appName').addEventListener('input', function () { state.project && (state.project.appName = this.value); autosave(); });
    // 运行：▾ 菜单只负责“选择运行方式”（从头/当前页面），选中后主按钮切换为该方式；真正运行由主按钮触发
    $('btnRun').addEventListener('click', function () { closeMenus(); onRun(state.runMode || 'start'); });
    $('btnRunCaret').addEventListener('click', function (e) {
      e.stopPropagation(); toggleMenu($('runMenu'), $('runSplit'));
    });
    $('runFromStart').addEventListener('click', function () { setRunMode('start'); closeMenus(); });
    $('runCurrent').addEventListener('click', function () { setRunMode('current'); closeMenus(); });
    applyRunMode();
    $('btnExport').addEventListener('click', openExport);
    $('tabDesign').addEventListener('click', function () { showView('design'); });
    $('tabBlocks').addEventListener('click', function () { showView('blocks'); });
    $('btnLayout').addEventListener('click', openLayout);
    $('modalCancel').addEventListener('click', hideModal);
    $('btnSettings').addEventListener('click', openSettings);
    $('settingsClose').addEventListener('click', function () { $('settingsMask').classList.add('hidden'); });
    $('viewHome').addEventListener('scroll', function () { $('homeHead').classList.toggle('scrolled', this.scrollTop > 4); });

    Array.prototype.forEach.call(document.querySelectorAll('[data-add]'), function (btn) {
      btn.addEventListener('click', function () { addComponent(btn.getAttribute('data-add')); });
    });
    Array.prototype.forEach.call(document.querySelectorAll('#moreOrient .orientbtn'), function (b) {
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        curScreen().orientation = b.getAttribute('data-orient'); syncOrientSeg(); autosave();
        if (state.inLayout) { renderLayout(); requestAnimationFrame(fitStage); }   // 实时切换舞台竖/横
      });
    });
    Array.prototype.forEach.call(document.querySelectorAll('#moreStatusBar .orientbtn'), function (b) {
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        curScreen().showStatusBar = b.getAttribute('data-sb') === 'yes'; syncOrientSeg(); autosave();
      });
    });
    $('morePageTitle').addEventListener('input', function () { curScreen().title = this.value; renderTabs(); autosave(); });

    // 顶栏「页面 ▾」菜单
    $('btnScreenMenu').addEventListener('click', function (e) {
      e.stopPropagation(); buildScreenMenu(); toggleMenu($('screenMenu'), $('btnScreenMenu'));
    });
    $('menuAddScreen').addEventListener('click', function () { closeMenus(); addScreen(); });
    $('menuDelScreen').addEventListener('click', function () { closeMenus(); deleteScreen(); });
    // 顶栏「更多 ▾」菜单（页面名 / 屏幕方向）
    $('btnMore').addEventListener('click', function (e) {
      e.stopPropagation();
      $('morePageTitle').value = curScreen().title || '';
      syncOrientSeg();
      toggleMenu($('moreMenu'), $('btnMore'));
    });
    // 点击菜单外部或滚动时收起菜单
    document.addEventListener('click', function (e) {
      if (e.target.closest('.popover') || e.target.closest('.screen-menu') || e.target.closest('.caret') || e.target.closest('.lay-page-pick')) return;
      closeMenus();
    });
    window.addEventListener('resize', function () { closeMenus(); if (state.inLayout) { requestAnimationFrame(fitStage); setTimeout(fitStage, 120); } });
    window.addEventListener('orientationchange', function () {
      if (state.inLayout) { requestAnimationFrame(fitStage); setTimeout(fitStage, 200); setTimeout(fitStage, 500); }
    });

    // 拖动布局视图的控制台/开关/页面菜单
    bindLayoutChrome();
    // M3 自定义取色器
    bindColorPicker();
    // 云表格创建/管理 + Blockly 输入弹窗 M3 化
    bindCloudUi();
    bindBlocklyDialogUi();

    // 点设计区空白处关闭属性栏
    $('viewDesign').addEventListener('click', onTap(function (e) {
      if (e.target.closest('.compcard,.proppanel,.design-left')) return;
      if (state.selectedCompId) { state.selectedCompId = null; renderCompList(); }
    }));

    // 导出弹窗
    $('exportCancel').addEventListener('click', function () { $('exportMask').classList.add('hidden'); });
    $('exportGo').addEventListener('click', doExport);
    $('btnPickIcon').addEventListener('click', function () { $('iconFile').click(); });
    $('btnClearIcon').addEventListener('click', function () { exportIcon = null; renderIconPreview(); });
    $('iconFile').addEventListener('change', function () {
      pickImage(this, function (url) { exportIcon = url; renderIconPreview(); });
      this.value = '';
    });

    // 从运行预览返回：恢复编辑器横屏、全屏沉浸与画布尺寸
    window.addEventListener('pageshow', function () {
      if (window.Native && Native.setLayoutChrome) Native.setLayoutChrome(false);
      if (window.Native && Native.setOrientation) Native.setOrientation('landscape');
      requestWsResize();
    });
    // 正常进入编辑器（含从试运行 history.back 重载）：复位为横屏全屏沉浸
    if (window.Native && Native.setLayoutChrome) Native.setLayoutChrome(false);
    if (window.Native && Native.setOrientation) Native.setOrientation('landscape');

    renderHome();

    // 从运行预览返回（WebView 通常会重载本页）：自动回到刚才编辑的工程，而不是停在首页
    try {
      var openId = localStorage.getItem(OPEN_KEY);
      if (openId && loadStore().items.some(function (x) { return x.id === openId; })) {
        openItem(openId);
      }
    } catch (e) {}
  }

  document.addEventListener('DOMContentLoaded', init);
})();
