# 积木编程（BlockBuilder）工程构建说明 v1.3

一个可在安卓手机上「拖积木做 App、并离线导出可安装 APK」的应用。纯本地、不联网、无账号。

> v1.3 变更：编辑器全屏沉浸（IMMERSIVE_STICKY 隐藏状态栏/导航栏，SHORT_EDGES 适配挖孔，仅对挖孔留白）；
> 直装改为把一次性副本 `files/install_stage.apk` 交给安装器，原件永久保留在 `files/export/`（部分 ROM 会清理它拿到的源文件）；
> 积木任何变更自动落盘、运行/导出前强制 persist（修复试运行返回后积木丢失）；坐标/样式参数逐个独立生效且对 NaN 免疫；
> 支持删除页面；试运行用右下角圆形悬浮停止键替代底部整条。

## 一、整体架构（双壳 + 编辑器）

- **编辑器 APK**（包名 `com.doubao.blockbuilder`，恒横屏）：
  - 首页「我的 App」：多作品本地管理（新建/打开/复制/删除，localStorage 键 `__bb_projects_v2`）。
  - Blockly 积木编辑器（`assets/www`）。
  - 内嵌两个运行时壳：`assets/shell.apk`（竖屏作品）、`assets/shell-land.apk`（横屏作品）。
  - 内嵌签名密钥 `assets/signkey.p12`（密码 doubao123）。
- **运行时壳**：与编辑器共用同一套 Java/前端；启动发现 `assets/project.json` 即运行该作品。
  - 清单中包名 `com.doubao.rt.a00000`、应用名 20 个 `X`、版本号 `0.00` 均为待替换值。
- **导出原理**（`Exporter.java`，全部手机本地完成）：
  1. 按作品方向选竖/横壳；
  2. `AxmlRewriter.java` 重建二进制 Manifest 的字符串池，**任意长度**替换包名/应用名/版本号（不再需要等长锚点）；
  3. 写入用户 `assets/project.json`；自定义图标按 mipmap 密度缩放替换 `ic_launcher.png`；
  4. `Exporter.packApk` 手写规范 ZIP：`resources.arsc` 与已压缩二进制资源 STORED 且 4 字节对齐，
     其余 DEFLATED，本地头写全 CRC/大小、**无 bit3 数据描述符**（最大化各 ROM 安装器兼容性）；
  5. 官方 apksig 做 v1+v2+v3 重签名，随后**在设备端用 ApkVerifier 自检**，不通过直接报错，
     绝不把坏包交给系统安装器（否则只会得到含糊的“安装包已损坏”）。

### 签名材料（重要）
设备端**不解析 PKCS12**（部分安卓系统的 KeyStore 读不了高版本 JDK 生成的 p12 加密算法）：
- `assets/signkey.pk8`：PKCS#8 私钥 DER，KeyFactory("RSA") 直接加载；
- `assets/signcert.pem`：X.509 证书 PEM，CertificateFactory 直接加载；
- `assets/signkey.p12`：只用于本机构建编辑器（apksigner CLI）。
更换签名钥匙时三份必须一起换。

```
proj/
├─ build.sh                  一键构建（aapt2/javac/d8/zipalign/apksigner，无需 Gradle/AndroidX）
├─ AndroidManifest.xml       编辑器清单（fullSensor，方向由代码请求为横屏；FileProvider）
├─ shell/AndroidManifest.xml    竖屏壳清单（portrait）
├─ shell-land/AndroidManifest.xml 横屏壳清单（landscape）
├─ src/com/doubao/blockbuilder/
│  ├─ MainActivity.java      唯一 Activity：编辑器全屏沉浸+挖孔适配（作品保留浅色状态栏）、
│  │                          方向切换、WebView 文件选择、系统返回键交运行时、直装用一次性副本、编辑器/壳双形态
│  ├─ AxmlRewriter.java      二进制 AXML 字符串池重建（任意长度替换）
│  ├─ Exporter.java          导出：选壳/改写/图标/规范 ZIP/apksig 签名
│  └─ SimpleFileProvider.java content:// FileProvider（调起安装器，不依赖 AndroidX）
├─ assets/www/               前端：editor.* / runtime.* / blocks.js / blockly/
├─ shell_assets/project.json 壳占位资产
└─ res/mipmap-*/             编辑器与壳共用的默认图标
```

## 二、构建依赖

1. **JDK 17**（必须含 javac，不能只有 JRE）。
2. **Android build-tools 33.0.2**：`aapt2 / d8 / zipalign / apksigner / lib/apksigner.jar / lib/d8.jar`。
3. **Android platform android-33**：`android.jar`。

脚本默认相对路径（可改 `build.sh` 顶部）：

```
work/
├─ proj/
└─ sdk/
   ├─ bt/android-13/   -> build-tools 33.0.2 目录
   └─ pt/android-13/android.jar
```

## 三、一键构建

```bash
cd proj && bash build.sh
```

产物 `out/积木编程.apk`。流程：aapt2 编译图标 → javac → d8（含 apksig）→ 分别构建竖/横壳
（未签名，导出时重签）→ 构建编辑器并 zipalign + apksigner 签名 → 自检。

约束（踩过的坑，勿回退）：
- d8 不能加 `--no-desugaring`（apksig 含 Java8 invokedynamic，minApi24 需脱糖）。
- `resources.arsc` 必须 STORED 且 4 字节对齐；壳必须带真实 res（空资源表 packageCount=0 在部分 ROM 判损坏）。
- 导出 ZIP 不使用数据描述符（bit3=0），本地头写全 CRC/压缩后大小/原始大小。
- Blockly 10 的 `blockly.min.js` 是全量 bundle，不要再叠加 blocks/javascript 压缩包。
- 编辑器清单不要锁死方向（fullSensor），由 `setRequestedOrientation` 控制：编辑器横屏、预览跟随作品。

## 四、PC 等价验证导出流程（无需真机）

`sim/`（不随 APK 发布）下的 `ExportSim2` 直接调用真实的 `Exporter.readEntries/packApk`
与 `AxmlRewriter`，再用 apksig 签名；随后用 `apksigner verify --min-sdk-version 21`、
`aapt2 dump badging/xmltree`、`zipalign -c -p 4` 校验。前端用 puppeteer-core + 系统 Chromium
跑 `test_ui.js`（横屏编辑器三栏、属性/坐标、积木渲染、运行时样式与交互）。

## 五、版本与兼容

- minSdk 24（Android 7.0），targetSdk 30。
- 系统栏纯色（非 edge-to-edge），网页内容始终在系统栏安全区内，状态栏区域不显示内容。
- 作品方向由工程设置决定（默认竖屏），预览与导出一致；编辑器始终横屏。
