package com.doubao.blockbuilder;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * 同一个 Activity 服务两种形态：
 *  - shell（导出的作品）：assets 存在 project.json，直接进运行时；
 *  - editor（编辑器）：无 project.json，进入编辑器。
 * 不做 edge-to-edge：WebView 始终布局在系统栏安全区内，状态栏/导航栏区域不显示任何网页内容，
 * 系统栏使用纯色背景。
 */
public class MainActivity extends Activity {

    private WebView web;
    private boolean shellMode;
    private boolean currentShowSB = true;
    private boolean layoutChrome = false;
    private String embeddedProject;
    private final Handler main = new Handler(Looper.getMainLooper());
    private ValueCallback<Uri[]> filePathCallback;
    private static final int REQ_FILE = 5173;
    private static final int REQ_MEDIA = 5174;
    private String pendingMediaKind;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        shellMode = false;
        embeddedProject = null;
        try {
            byte[] data = readAll(getAssets().open("project.json"));
            String p = new String(data, "UTF-8");
            if (p != null && p.contains("screens")) { shellMode = true; embeddedProject = p; }
        } catch (Exception ignore) {}

        int bgColor = shellMode ? Color.parseColor("#F7F6FA") : Color.WHITE;
        if (shellMode) {
            try {
                org.json.JSONObject jo = new org.json.JSONObject(embeddedProject);
                org.json.JSONArray ss = jo.optJSONArray("screens");
                if (ss != null && ss.length() > 0) {
                    org.json.JSONObject s0 = ss.getJSONObject(0);
                    String o = s0.optString("orientation", "portrait");
                    setRequestedOrientation("landscape".equals(o)
                            ? ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                            : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                }
            } catch (Exception ignore) {}
        }
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 28) {
            // 关键：横屏默认会在挖孔那条边留黑边，SHORT_EDGES 让窗口铺到挖孔两侧
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            w.setAttributes(lp);
        }
        getWindow().getDecorView().setBackgroundColor(bgColor);
        if (!shellMode) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            enterImmersive(); // 编辑器像横屏游戏一样全屏隐藏状态栏/导航栏
        } else {
            applyShellBars();
        }

        web = new WebView(this);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        web.setWebChromeClient(new WebChromeClient() {
            // 支持 <input type=file> 选择图标/图片
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (filePathCallback != null) { filePathCallback.onReceiveValue(null); }
                filePathCallback = cb;
                Intent it = params.createIntent();
                try { startActivityForResult(it, REQ_FILE); }
                catch (Exception e) { filePathCallback = null; Toast.makeText(MainActivity.this,
                        "无法打开文件选择", Toast.LENGTH_SHORT).show(); return false; }
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new NativeBridge(), "Native");
        // 避让区（状态栏/导航栏/挖孔）显示该底色，而不是黑色
        web.setBackgroundColor(bgColor);

        setContentView(web);
        applySafeInsets(web);
        if (shellMode) web.loadUrl("file:///android_asset/www/runtime.html");
        else web.loadUrl("file:///android_asset/www/editor.html");
    }

    /**
     * 编辑器：全屏沉浸（像横屏游戏），隐藏状态栏与导航栏，内容铺到物理边缘；
     * 仅靠内边距避让挖孔摄像头（见 applySafeInsets）。
     */
    private void enterImmersive() {
        final View decor = getWindow().getDecorView();
        Runnable r = new Runnable() { @Override public void run() {
            int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decor.setSystemUiVisibility(flags);
            if (Build.VERSION.SDK_INT >= 30) {
                android.view.WindowInsetsController c = decor.getWindowInsetsController();
                if (c != null) {
                    c.hide(android.view.WindowInsets.Type.systemBars());
                    c.setSystemBarsBehavior(
                            android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            }
        }};
        main.post(r);
    }

    /** 导出的作品：系统栏保持可见，浅底 + 深色图标 */
    private void applyShellBars() {
        main.post(new Runnable() { @Override public void run() {
            View decor = getWindow().getDecorView();
            int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            if (Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 27) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            decor.setSystemUiVisibility(flags);
        }});
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && !shellMode && !layoutChrome) enterImmersive();
        // 运行时壳：焦点回来时按当前页面设置重设系统栏，保证隐藏通知栏后长期隐藏
        if (hasFocus && shellMode) {
            applyStatusBar(currentShowSB);
        }
    }
    private void applyStatusBar(final boolean show) {
        main.post(new Runnable() { @Override public void run() {
            try {
                View decor = getWindow().getDecorView();
                int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
                if (Build.VERSION.SDK_INT >= 27) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                if (!show) {
                    flags |= View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
                } else if (Build.VERSION.SDK_INT >= 26) {
                    flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                }
                decor.setSystemUiVisibility(flags);
            } catch (Exception ignore) {}
        }});
    }

    /** 系统深浅色切换时通知前端（前端处于“跟随系统”才换肤） */
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        try {
            boolean dark = (newConfig.uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
            if (web != null) evalJs("window.__onSystemThemeChanged&&window.__onSystemThemeChanged(" + dark + ")");
        } catch (Exception ignore) {}
    }

    /**
     * 用 WindowInsets 给 WebView 设内边距：
     *  - 编辑器全屏沉浸，系统栏已隐藏，只避让挖孔摄像头（避免 UI 压到镜头）；
     *  - 作品避让系统栏 + 挖孔。内边距区域由 WebView 底色填充，消除黑边。
     */
    private void applySafeInsets(final View v) {
        v.setFitsSystemWindows(false);
        v.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public android.view.WindowInsets onApplyWindowInsets(View view,
                                                                          android.view.WindowInsets in) {
                int l, t, r, b;
                if (Build.VERSION.SDK_INT >= 30) {
                    // 舞台始终铺满整个屏幕：状态栏、导航栏都只是浮层，内容伸到它们下面
                    // （开/关通知栏、有无导航栏，舞台大小位置完全一致）
                    int typeMask = android.view.WindowInsets.Type.displayCutout();
                    android.graphics.Insets si = in.getInsets(typeMask);
                    l = si.left; t = si.top; r = si.right; b = 0;
                } else {
                    l = in.getSystemWindowInsetLeft();
                    t = 0;   // 不避让状态栏
                    r = in.getSystemWindowInsetRight();
                    b = 0;   // 不避让导航栏
                }
                view.setPadding(l, t, r, b);
                return in;
            }
        });
        v.requestApplyInsets();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE) {
            if (filePathCallback == null) return;
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri u = data.getData();
                if (u != null) result = new Uri[]{ u };
            }
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
        if (requestCode == REQ_MEDIA) {
            final String kind = pendingMediaKind; pendingMediaKind = null;
            if (resultCode != RESULT_OK || data == null || data.getData() == null) {
                evalJs("window.EditorApp&&EditorApp.onMediaPicked&&EditorApp.onMediaPicked('')");
                return;
            }
            final Uri src = data.getData();
            new Thread(new Runnable() {
                public void run() {
                    try {
                        String mime = null;
                        try { mime = getContentResolver().getType(src); } catch (Throwable ignore) {}
                        String ext = (kind != null && kind.equals("audio")) ? ".mp3" : ".mp4";
                        if (mime != null) {
                            String m = mime.toLowerCase();
                            if (m.contains("mpeg") || m.contains("mp3")) ext = ".mp3";
                            else if (m.contains("wav")) ext = ".wav";
                            else if (m.contains("ogg")) ext = ".ogg";
                            else if (m.contains("webm")) ext = ".webm";
                            else if (m.contains("quicktime") || m.contains("mp4")) ext = ".mp4";
                        }
                        java.io.File dir = new java.io.File(getFilesDir(), "media"); dir.mkdirs();
                        String name = (kind != null ? kind : "media") + "_" + System.currentTimeMillis() + ext;
                        java.io.File dst = new java.io.File(dir, name);
                        byte[] bytes = readAll(getContentResolver().openInputStream(src));
                        java.io.FileOutputStream out = new java.io.FileOutputStream(dst);
                        out.write(bytes); out.close();
                        evalJs("window.EditorApp&&EditorApp.onMediaPicked&&EditorApp.onMediaPicked(" + jsStr(name) + ")");
                    } catch (Throwable e) {
                        evalJs("window.EditorApp&&EditorApp.onMediaPicked&&EditorApp.onMediaPicked('')");
                    }
                }
            }).start();
        }
    }

    private static byte[] readAll(InputStream is) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
        is.close();
        return bo.toByteArray();
    }

    /** 复制文件并强制落盘（fsync），保证交给安装器的副本完整 */
    private static void copyFile(java.io.File src, java.io.File dst) throws Exception {
        java.io.FileInputStream in = new java.io.FileInputStream(src);
        java.io.FileOutputStream out = new java.io.FileOutputStream(dst);
        try {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.flush(); out.getFD().sync();
        } finally { in.close(); out.close(); }
    }

    class NativeBridge {

        @JavascriptInterface
        public String getMode() { return shellMode ? "shell" : "editor"; }

        @JavascriptInterface
        public String getProject() { return shellMode ? embeddedProject : null; }

        /** 前端请求屏幕方向：portrait / landscape；布局页保持与运行时一致的系统栏，其余编辑器界面全屏沉浸 */
        @JavascriptInterface
        public void setOrientation(final String mode) {
            main.post(new Runnable() { @Override public void run() {
                try {
                    if ("portrait".equals(mode))
                        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                    else if ("landscape".equals(mode))
                        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                } catch (Exception ignore) {}
                if (!shellMode && !layoutChrome) enterImmersive();
            }});
        }

        /** 运行作品时按页面设置是否显示通知栏（状态栏）。show=false 隐藏状态栏，保留导航栏 */
        @JavascriptInterface
        public void setStatusBar(final boolean show) {
            currentShowSB = show;
            applyStatusBar(show);
        }

        /**
         * 进入/退出“拖动布局”全屏页时切换系统栏风格：
         *  on  = 与导出作品(壳)完全一致：状态栏/导航栏可见、透明、浅色图标，并让 WebView
         *        按系统栏+挖孔留白。这样布局页的可用区宽高、边距与实际运行完全相同（修复底部对不齐）。
         *  off = 恢复编辑器的全屏沉浸。
         */
        @JavascriptInterface
        public void setLayoutChrome(final boolean on) {
            main.post(new Runnable() { @Override public void run() {
                try {
                    layoutChrome = on;
                    if (on) applyShellBars(); else enterImmersive();
                    if (web != null) applySafeInsets(web);
                } catch (Exception ignore) {}
            }});
        }

        @JavascriptInterface
        public void setStatusBarStyle(String mode) { /* 由模式决定，保留接口兼容 */ }

        /** 系统当前是否深色模式（供前端“跟随系统”可靠判断，部分 WebView 不回传 prefers-color-scheme） */
        @JavascriptInterface
        public boolean isSystemDark() {
            try {
                int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
                return mode == Configuration.UI_MODE_NIGHT_YES;
            } catch (Exception e) { return false; }
        }

        /** 震动指定毫秒（震动积木用） */
        @JavascriptInterface
        public void vibrate(final long ms) {
            main.post(new Runnable() { @Override public void run() {
                try {
                    Vibrator vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                    if (vib == null || !vib.hasVibrator()) return;
                    long m = Math.max(1, Math.min(ms, 3000));
                    if (Build.VERSION.SDK_INT >= 26)
                        vib.vibrate(VibrationEffect.createOneShot(m, VibrationEffect.DEFAULT_AMPLITUDE));
                    else vib.vibrate(m);
                } catch (Exception ignore) {}
            }});
        }

        @JavascriptInterface
        public void exportApk(final String projectJson, final String appName,
                              final String orientation, final String iconDataUrl,
                              final String version) {
            new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        String path = Exporter.export(MainActivity.this, projectJson, appName,
                                orientation, iconDataUrl, version);
                        // 每次导出都直接在公共「下载/FAST」落一份，并拿到系统 MediaStore 的 content:// 地址
                        String dlUri = null;
                        try { dlUri = persistToDownload(new java.io.File(path)); } catch (Throwable ignore) {}
                        evalJs("window.EditorApp&&EditorApp.onExportResult(true," + jsStr(path) + ",'',"
                                + (dlUri == null ? "null" : jsStr(dlUri)) + ")");
                    } catch (final Throwable e) {
                        String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                        evalJs("window.EditorApp&&EditorApp.onExportResult(false,''," + jsStr(msg) + ",null)");
                    }
                }
            }).start();
        }

        /**
         * 调起系统安装器。优先用公共下载目录的系统 MediaStore content://（系统 Provider 拥有，
         * 任何安装器都能稳定读取）；否则退回应用私有副本 + 自有 FileProvider。
         * 并向所有能处理安装的包显式授予读权限，修复 ColorOS 等安装器跨进程读不到文件而报“包损坏”。
         */
        @JavascriptInterface
        public void installApk(final String path, final String downloadUri) {
            new Thread(new Runnable() { @Override public void run() {
                Uri uri = null;
                try {
                    if (path != null && path.startsWith("content://")) uri = Uri.parse(path);
                    if (downloadUri != null && downloadUri.startsWith("content://")) uri = Uri.parse(downloadUri);
                    if (uri == null) {
                        java.io.File master = new java.io.File(path);
                        if (!master.exists() || master.length() < 10000) {
                            toast("安装文件不存在或不完整，请重新导出"); return;
                        }
                        // 交给安装器的是一次性副本，避免部分 ROM 安装结束后清掉原件
                        java.io.File stage = new java.io.File(getFilesDir(), "install_stage.apk");
                        copyFile(master, stage);
                        uri = SimpleFileProvider.uriFor(stage);
                    }
                    final Uri target = uri;
                    main.post(new Runnable() { @Override public void run() { launchInstaller(target); } });
                } catch (final Exception e) {
                    toast("无法调起安装：" + e.getMessage());
                }
            }}).start();
        }

        /** 下载指定 URL 的安装包到私有目录，完成后回调 EditorApp.onApkDownloaded(cbId, 本地路径, 错误) */
        @JavascriptInterface
        public void downloadApk(final String cbId, final String url, final String saveName) {
            new Thread(new Runnable() { @Override public void run() {
                try {
                    java.io.File dir = new java.io.File(getFilesDir(), "downloads"); dir.mkdirs();
                    String name = (saveName == null || saveName.trim().isEmpty()) ? "update.apk" : saveName;
                    name = name.replaceAll("[\\\\/:*?\"<>|]+", "_");
                    if (!name.toLowerCase().endsWith(".apk")) name += ".apk";
                    java.io.File dst = new java.io.File(dir, name);
                    java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                    c.setRequestMethod("GET"); c.setInstanceFollowRedirects(true); c.setConnectTimeout(15000); c.setReadTimeout(60000);
                    // 关键：禁用 gzip，避免下到未解压的压缩字节；用 UA 避免被拒
                    c.setRequestProperty("Accept-Encoding", "identity");
                    c.setRequestProperty("User-Agent", "FAST-Update/1.0");
                    long expect = c.getContentLengthLong();
                    InputStream is = c.getInputStream();
                    java.io.FileOutputStream os = new java.io.FileOutputStream(dst);
                    byte[] buf = new byte[8192]; int n; long got = 0;
                    while ((n = is.read(buf)) > 0) { os.write(buf, 0, n); got += n; }
                    os.close(); is.close(); c.disconnect();
                    // 大小校验：与服务器 Content-Length 必须一致，否则视为损坏
                    if (expect > 0 && got != expect) {
                        dst.delete();
                        evalJs("window.EditorApp&&EditorApp.onApkDownloaded(" + jsStr(cbId) + ",'',"
                                + jsStr("下载不完整(期望" + expect + "实际" + got + ")，请重试") + ")");
                        return;
                    }
                    // 校验确实是 APK（ZIP 魔数 PK\x03\x04），避免下到错误页/重定向页导致“安装包损坏”
                    java.io.FileInputStream chk = new java.io.FileInputStream(dst);
                    int b0 = chk.read(), b1 = chk.read(), b2 = chk.read(), b3 = chk.read(); chk.close();
                    if (b0 != 'P' || b1 != 'K' || b2 != 3 || b3 != 4) {
                        dst.delete();
                        evalJs("window.EditorApp&&EditorApp.onApkDownloaded(" + jsStr(cbId) + ",'',"
                                + jsStr("下载到的不是有效安装包(可能链接已过期)，请重试") + ")");
                        return;
                    }
                    // 与导出 APK 完全相同的落盘方式：写入公共 Download/FAST（MediaStore），
                    // 返回系统 content:// 地址，安装器可稳定读取（私有 FileProvider 偶发装不上）
                    String contentUri = null;
                    try { contentUri = persistToDownload(dst); } catch (Throwable t) { contentUri = null; }
                    final String cbPath = (contentUri != null) ? contentUri : dst.getAbsolutePath();
                    evalJs("window.EditorApp&&EditorApp.onApkDownloaded(" + jsStr(cbId) + ","
                            + jsStr(cbPath) + ",'')");
                } catch (final Throwable e) {
                    evalJs("window.EditorApp&&EditorApp.onApkDownloaded(" + jsStr(cbId) + ",'',"
                            + jsStr(e.getMessage() == null ? "下载失败" : e.getMessage()) + ")");
                }
            }}).start();
        }

        /** 直接跳转到公共「下载/FAST」目录，让用户用系统文件管理器点 APK 安装（直装失败时的兜底通道） */
        @JavascriptInterface
        public void openDownloadFolder() {
            main.post(new Runnable() { @Override public void run() {
                Intent opened = openDocDir("primary:Download/FAST");
                if (opened == null) opened = openDocDir("primary:Download");
                if (opened == null) {
                    try {
                        Intent it = new Intent(Intent.ACTION_GET_CONTENT);
                        it.setType("application/vnd.android.package-archive");
                        it.addCategory(Intent.CATEGORY_OPENABLE);
                        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(Intent.createChooser(it, "选择安装包").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Exception e) {
                        toast("请打开系统「文件管理」，进入 下载/FAST 目录点击安装");
                    }
                }
            }});
        }

        /** 分享 FAST 作品文件（.fast，本质 JSON）：写入私有 shared 目录后用系统分享面板发出 */
        @JavascriptInterface
        public void shareProject(final String json, final String fileName) {
            new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        java.io.File dir = new java.io.File(getFilesDir(), "shared");
                        if (!dir.exists()) dir.mkdirs();
                        String safe = fileName == null ? "FAST作品.fast"
                                : fileName.replaceAll("[\\\\/:*?\"<>|\\r\\n\\t]", "_").trim();
                        if (safe.isEmpty()) safe = "FAST作品.fast";
                        if (!safe.toLowerCase().endsWith(".fast")) safe = safe + ".fast";
                        final java.io.File f = new java.io.File(dir, safe);
                        java.io.FileOutputStream fos = new java.io.FileOutputStream(f);
                        try { fos.write(json.getBytes("UTF-8")); fos.flush(); fos.getFD().sync(); } finally { fos.close(); }
                        main.post(new Runnable() { @Override public void run() { launchShare(f); } });
                    } catch (final Exception e) {
                        main.post(new Runnable() { @Override public void run() { toast("分享失败：" + e.getMessage()); } });
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public void toast(final String text) {
            main.post(new Runnable() { @Override public void run() {
                Toast.makeText(MainActivity.this, text, Toast.LENGTH_SHORT).show();
            }});
        }

        /** 选择本地视频/音频：由原生弹出系统选择器，选完拷入 filesDir/media，再回调 onMediaPicked(文件名) */
        @JavascriptInterface
        public void pickMedia(final String kind) {
            main.post(new Runnable() { public void run() {
                pendingMediaKind = (kind != null && kind.equals("audio")) ? "audio" : "video";
                Intent it = new Intent(Intent.ACTION_GET_CONTENT);
                it.setType(pendingMediaKind.equals("audio") ? "audio/*" : "video/*");
                it.addCategory(Intent.CATEGORY_OPENABLE);
                try {
                    startActivityForResult(Intent.createChooser(it, "选择" + (pendingMediaKind.equals("audio") ? "音频" : "视频")), REQ_MEDIA);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "无法打开文件选择", Toast.LENGTH_SHORT).show();
                }
            }});
        }

        /** 把工程里的 media:// 引用解析成可播放地址：编辑器私有目录优先，否则用导出 APK 的 assets */
        @JavascriptInterface
        public String mediaUrl(String name) {
            if (name == null) return "";
            if (name.indexOf('/') >= 0 || name.indexOf('\\') >= 0 || name.indexOf("..") >= 0) return "";
            java.io.File f = new java.io.File(getFilesDir(), "media/" + name);
            if (f.exists()) return "file://" + f.getAbsolutePath();
            return "file:///android_asset/media/" + name;
        }

        @JavascriptInterface
        public void exitApp() {
            main.post(new Runnable() { @Override public void run() { finish(); } });
        }

        /**
         * 通用异步 HTTP 请求（云列表等积木使用）。WebView 直连受 CORS 限制
         * （例如 SeaTable api-gateway 会返回重复 Access-Control-Allow-Origin 头，浏览器直接拒绝），
         * 原生 HttpURLConnection 不受此限制。结果通过 window.__nativeHttpResolve(id, json) 回调。
         */
        @JavascriptInterface
        public void httpRequest(final String cbId, final String method, final String url,
                                final String headersJson, final String body) {
            new Thread(new Runnable() { @Override public void run() {
                java.io.OutputStream out = null; java.io.InputStream in = null;
                try {
                    java.net.HttpURLConnection conn =
                            (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(20000);
                    conn.setRequestMethod(method == null ? "GET" : method.toUpperCase());
                    conn.setDoInput(true);
                    org.json.JSONObject headers = (headersJson == null || headersJson.length() == 0)
                            ? new org.json.JSONObject() : new org.json.JSONObject(headersJson);
                    java.util.Iterator<String> keys = headers.keys();
                    while (keys.hasNext()) {
                        String k = keys.next();
                        String v = headers.optString(k);
                        if (k != null && v != null) conn.setRequestProperty(k, v);
                    }
                    if (body != null && body.length() > 0) {
                        conn.setDoOutput(true);
                        out = conn.getOutputStream();
                        out.write(body.getBytes("UTF-8"));
                        out.flush();
                    }
                    int code = conn.getResponseCode();
                    in = (code >= 200 && code < 400) ? conn.getInputStream() : conn.getErrorStream();
                    ByteArrayOutputStream buf = new ByteArrayOutputStream();
                    if (in != null) { byte[] chunk = new byte[4096]; int n; while ((n = in.read(chunk)) > 0) buf.write(chunk, 0, n); }
                    org.json.JSONObject result = new org.json.JSONObject();
                    result.put("status", code);
                    result.put("body", new String(buf.toByteArray(), "UTF-8"));
                    postHttpResult(cbId, result.toString());
                } catch (Exception e) {
                    try {
                        org.json.JSONObject result = new org.json.JSONObject();
                        result.put("error", e.getMessage() == null ? "网络请求失败" : e.getMessage());
                        postHttpResult(cbId, result.toString());
                    } catch (Exception ignore) {}
                } finally {
                    try { if (out != null) out.close(); } catch (Exception ignore) {}
                    try { if (in != null) in.close(); } catch (Exception ignore) {}
                }
            }}).start();
        }
    }

    /** 子线程 HTTP 结果回到 JS（JSON 字符串安全转义） */
    private void postHttpResult(final String cbId, final String json) {
        main.post(new Runnable() { @Override public void run() {
            if (web == null) return;
            String script = "window.__nativeHttpResolve&&window.__nativeHttpResolve("
                    + org.json.JSONObject.quote(cbId) + "," + org.json.JSONObject.quote(json) + ");";
            web.evaluateJavascript(script, null);
        }});
    }

    /**
     * 把导出的 APK 直接写入公共「下载/FAST」目录（用户可见、可用文件管理器直接安装）。
     * Android10+ 走 MediaStore（免权限），同名先删旧再写新，避免出现 (1) 副本；低版本直接写公共目录。
     */
    @SuppressWarnings("unused")
    private String persistToDownload(java.io.File src) throws Exception {
        final String fname = src.getName();
        byte[] bytes = readFile(src);
        if (Build.VERSION.SDK_INT >= 29) {
            android.content.ContentResolver cr = getContentResolver();
            android.net.Uri base = android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            try {
                android.database.Cursor cur = cr.query(base, new String[]{android.provider.BaseColumns._ID},
                        android.provider.MediaStore.MediaColumns.DISPLAY_NAME + "=? AND "
                                + android.provider.MediaStore.MediaColumns.RELATIVE_PATH + "=?",
                        new String[]{fname, "Download/FAST/"}, null);
                if (cur != null) {
                    while (cur.moveToNext()) {
                        long id = cur.getLong(0);
                        cr.delete(android.content.ContentUris.withAppendedId(base, id), null, null);
                    }
                    cur.close();
                }
            } catch (Exception ignore) {}
            android.content.ContentValues cv = new android.content.ContentValues();
            cv.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fname);
            cv.put(android.provider.MediaStore.MediaColumns.MIME_TYPE,
                    "application/vnd.android.package-archive");
            cv.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "Download/FAST");
            cv.put(android.provider.MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = cr.insert(base, cv);
            if (uri == null) throw new IllegalStateException("无法写入下载目录");
            java.io.OutputStream os = cr.openOutputStream(uri);
            try { os.write(bytes); os.flush(); } finally { os.close(); }
            cv.clear();
            cv.put(android.provider.MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(uri, cv, null, null);
            // 返回系统 MediaStore 的 content:// 地址：系统 Provider 拥有，安装器可稳定读取
            return uri.toString();
        } else {
            java.io.File dir = new java.io.File(
                    android.os.Environment.getExternalStoragePublicDirectory(
                            android.os.Environment.DIRECTORY_DOWNLOADS), "FAST");
            if (!dir.exists()) dir.mkdirs();
            java.io.File dst = new java.io.File(dir, fname);
            java.io.FileOutputStream fos = new java.io.FileOutputStream(dst);
            try { fos.write(bytes); fos.flush(); fos.getFD().sync(); } finally { fos.close(); }
            return null; // API28 及以下走 FileProvider 私有副本安装，避免 file:// 暴露异常
        }
    }

    private static final String APK_MIME = "application/vnd.android.package-archive";

    /** 调起系统安装器，并向所有可处理安装的包显式授予该 Uri 读权限（跨进程授权，兼容 ColorOS 等） */
    private void launchInstaller(Uri uri) {
        try {
            Intent probe = new Intent(Intent.ACTION_VIEW).setDataAndType(uri, APK_MIME);
            try {
                java.util.List<android.content.pm.ResolveInfo> targets =
                        getPackageManager().queryIntentActivities(probe,
                                android.content.pm.PackageManager.MATCH_DEFAULT_ONLY);
                for (android.content.pm.ResolveInfo ri : targets) {
                    try { grantUriPermission(ri.activityInfo.packageName, uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignore) {}
                }
            } catch (Exception ignore) {}
            Intent it = new Intent(Intent.ACTION_VIEW);
            it.setDataAndType(uri, APK_MIME);
            it.addCategory(Intent.CATEGORY_DEFAULT);
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(it);
        } catch (Exception e) {
            Toast.makeText(this, "无法调起安装：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /**
     * 用系统分享面板把作品文件（.fast）发出去。
     * 关键兼容（微信/QQ）：
     *  - MIME 用 *\/*（微信文件发送只接受通配类型，application/json 时微信往往不显示或发送失败）；
     *  - 通过 ClipData 携带 Uri，读权限随数据授予最终选中的目标（比仅对枚举结果授权更稳，含微信）；
     *  - 再对所有可接收应用显式授予一次读权限（ColorOS/部分 ROM 需要）。
     */
    private void launchShare(java.io.File f) {
        try {
            Uri uri = SimpleFileProvider.uriFor(f);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("*/*");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_TITLE, f.getName());
            send.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try {
                send.setClipData(android.content.ClipData.newUri(getContentResolver(), f.getName(), uri));
            } catch (Exception ignore) {}
            int qf = android.content.pm.PackageManager.MATCH_DEFAULT_ONLY;
            try { qf |= android.content.pm.PackageManager.MATCH_ALL; } catch (Throwable ignore) {}
            try {
                java.util.List<android.content.pm.ResolveInfo> targets =
                        getPackageManager().queryIntentActivities(send, qf);
                for (android.content.pm.ResolveInfo ri : targets) {
                    try { grantUriPermission(ri.activityInfo.packageName, uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignore) {}
                }
            } catch (Exception ignore) {}
            Intent chooser = Intent.createChooser(send, "分享 FAST 作品");
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(chooser);
        } catch (Exception e) {
            Toast.makeText(this, "无法分享：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /** 用系统 DocumentsUI 打开指定 documentId 的目录；失败返回 null 以便逐级兜底 */
    private Intent openDocDir(String documentId) {
        try {
            Uri uri = android.provider.DocumentsContract.buildDocumentUri(
                    "com.android.externalstorage.documents", documentId);
            Intent it = new Intent(Intent.ACTION_VIEW);
            it.setDataAndType(uri, android.provider.DocumentsContract.Document.MIME_TYPE_DIR);
            it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(it);
            return it;
        } catch (Exception e) {
            return null;
        }
    }

    private static byte[] readFile(java.io.File f) throws Exception {
        java.io.FileInputStream fis = new java.io.FileInputStream(f);
        try {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n;
            while ((n = fis.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        } finally { fis.close(); }
    }

    private void evalJs(final String js) {
        main.post(new Runnable() { @Override public void run() { web.evaluateJavascript(js, null); } });
    }

    static String jsStr(String s) {
        if (s == null) return "''";
        StringBuilder sb = new StringBuilder("'");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\': sb.append("\\\\"); break;
                case '\'': sb.append("\\'"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        return sb.append("'").toString();
    }

    /** 系统返回键：先交给运行时处理（页面出栈），运行时不处理再走默认 */
    @Override
    public void onBackPressed() {
        if (web != null) {
            web.evaluateJavascript(
                "(function(){try{return window.__rtSystemBack?window.__rtSystemBack():'false';}catch(e){return 'false';}})();",
                new ValueCallback<String>() {
                    @Override public void onReceiveValue(String value) {
                        if (!"true".equals(value)) MainActivity.super.onBackPressed();
                    }
                });
        } else super.onBackPressed();
    }
}
