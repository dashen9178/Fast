package com.doubao.blockbuilder;
import com.android.apksig.ApkSigner;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;

/**
 * PC 端等价复刻设备导出流水线（Exporter.export 的无 Android 依赖版本）：
 * 读壳 -> AxmlRewriter 改包名/应用名/版本 -> arsc 包名同步 -> 注入 assets/project.json
 *        -> Exporter.packApk 标准 ZIP -> apksig v1+v2+v3 签名。
 * 用法：DemoBuild <shell.apk> <project.json> <appName> <version> <signkey.pk8> <signcert.pem> <out.apk>
 */
public class DemoBuild {
  static byte[] readAll(File f) throws Exception {
    ByteArrayOutputStream bo = new ByteArrayOutputStream();
    FileInputStream in = new FileInputStream(f);
    byte[] b = new byte[8192]; int n;
    while ((n = in.read(b)) > 0) bo.write(b, 0, n);
    in.close();
    return bo.toByteArray();
  }

  static void sign(File in, File out, File pk8, File pem) throws Exception {
    byte[] keyDer = readAll(pk8);
    PrivateKey pk = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(keyDer));
    CertificateFactory cf = CertificateFactory.getInstance("X.509");
    Collection<? extends java.security.cert.Certificate> cs =
        cf.generateCertificates(new ByteArrayInputStream(readAll(pem)));
    List<X509Certificate> chain = new ArrayList<>();
    for (java.security.cert.Certificate c : cs) chain.add((X509Certificate) c);
    ApkSigner.SignerConfig sc = new ApkSigner.SignerConfig.Builder("CERT", pk, chain).build();
    new ApkSigner.Builder(Collections.singletonList(sc))
        .setInputApk(in).setOutputApk(out)
        .setMinSdkVersion(24)
        .setV1SigningEnabled(true).setV2SigningEnabled(true).setV3SigningEnabled(true)
        .setOtherSignersSignaturesPreserved(false).build().sign();
  }

  static String suffix(String name) {
    long h = 1125899906842597L;
    for (int i = 0; i < name.length(); i++) h = 31 * h + name.charAt(i);
    h = Math.abs(h);
    String s = Long.toString(h, 36);
    while (s.length() < 6) s = "0" + s;
    return s.substring(s.length() - 6);
  }

  public static void main(String[] a) throws Exception {
    File shell = new File(a[0]);
    byte[] project = readAll(new File(a[1]));
    String appName = a[2];
    String ver = a[3];
    File pk8 = new File(a[4]), pem = new File(a[5]), out = new File(a[6]);

    String npkg = "com.doubao.rt." + suffix(appName);
    LinkedHashMap<String, byte[]> e = Exporter.readEntries(shell);
    LinkedHashMap<String, String> repl = new LinkedHashMap<>();
    repl.put(Exporter.OLD_PACKAGE, npkg);
    repl.put(Exporter.LABEL_ANCHOR, appName);
    repl.put(Exporter.VERSION_ANCHOR, ver);
    e.put("AndroidManifest.xml", AxmlRewriter.replace(e.get("AndroidManifest.xml"), repl));
    byte[] arsc = e.get("resources.arsc");
    if (arsc != null) e.put("resources.arsc", Exporter.rewriteArscPackage(arsc, npkg));
    e.put("assets/project.json", project);

    File un = new File(out.getParentFile(), "unsigned_" + out.getName());
    Exporter.packApk(e, un);
    sign(un, out, pk8, pem);
    un.delete();
    System.out.println("built " + out.getName() + " pkg=" + npkg + " bytes=" + out.length()
        + " projectBytes=" + project.length);
  }
}
