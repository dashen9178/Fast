package com.doubao.blockbuilder;
import com.android.apksig.ApkSigner;
import java.io.*;
import java.security.*;
import java.security.cert.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;

public class ExportSim {
  static byte[] readAll(File f) throws Exception {
    ByteArrayOutputStream bo=new ByteArrayOutputStream(); FileInputStream in=new FileInputStream(f);
    byte[] b=new byte[8192]; int n; while((n=in.read(b))>0)bo.write(b,0,n); in.close(); return bo.toByteArray();
  }
  static void sign(File in, File out, File pk8, File pem) throws Exception {
    byte[] keyDer=readAll(pk8);
    PrivateKey pk=KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(keyDer));
    CertificateFactory cf=CertificateFactory.getInstance("X.509");
    Collection<? extends java.security.cert.Certificate> cs=cf.generateCertificates(new ByteArrayInputStream(readAll(pem)));
    List<X509Certificate> chain=new ArrayList<>(); for(java.security.cert.Certificate c:cs) chain.add((X509Certificate)c);
    ApkSigner.SignerConfig sc=new ApkSigner.SignerConfig.Builder("CERT",pk,chain).build();
    new ApkSigner.Builder(Collections.singletonList(sc)).setInputApk(in).setOutputApk(out)
      .setMinSdkVersion(24).setV1SigningEnabled(true).setV2SigningEnabled(true).setV3SigningEnabled(true)
      .setOtherSignersSignaturesPreserved(false).build().sign();
  }
  static File build(File shell, File pk8, File pem, String appName, String ver, File out) throws Exception {
    LinkedHashMap<String,byte[]> e=Exporter.readEntries(shell);
    String npkg="com.doubao.rt."+suffix(appName);
    LinkedHashMap<String,String> repl=new LinkedHashMap<>();
    repl.put(Exporter.OLD_PACKAGE,npkg); repl.put(Exporter.LABEL_ANCHOR,appName); repl.put(Exporter.VERSION_ANCHOR,ver);
    e.put("AndroidManifest.xml", AxmlRewriter.replace(e.get("AndroidManifest.xml"),repl));
    byte[] arsc=e.get("resources.arsc"); if(arsc!=null) e.put("resources.arsc",Exporter.rewriteArscPackage(arsc,npkg));
    e.put("assets/project.json",("{\"appName\":\""+appName+"\",\"screens\":[{\"id\":\"s1\",\"components\":[]}]}").getBytes("UTF-8"));
    File un=new File(out.getParentFile(),"unsigned_"+out.getName());
    Exporter.packApk(e,un); sign(un,out,pk8,pem); un.delete();
    System.out.println("built "+out.getName()+" pkg="+npkg+" bytes="+out.length());
    return out;
  }
  static String suffix(String name){long h=1125899906842597L;for(int i=0;i<name.length();i++)h=31*h+name.charAt(i);h=Math.abs(h);String s=Long.toString(h,36);while(s.length()<6)s="0"+s;return s.substring(s.length()-6);}
  public static void main(String[] a) throws Exception {
    File assets=new File(a[0]), outdir=new File(a[1]); outdir.mkdirs();
    build(new File(assets,"shell.apk"),new File(assets,"signkey.pk8"),new File(assets,"signcert.pem"),"我的待办","2.5",new File(outdir,"todo.apk"));
    build(new File(assets,"shell-land.apk"),new File(assets,"signkey.pk8"),new File(assets,"signcert.pem"),"横屏测试","1.0",new File(outdir,"land.apk"));
  }
}
